"""Project matching recommendations."""

from __future__ import annotations

from typing import Dict, List


class ProjectMatcher:
    def suggest_projects(self, *, interests: List[str], skill_scores: Dict[str, float]) -> List[str]:
        suggestions = []
        for interest in interests:
            level = "advanced" if skill_scores.get(interest, 0.0) >= 0.8 else "practice"
            suggestions.append(f"{level}:{interest}:project")
        return suggestions
