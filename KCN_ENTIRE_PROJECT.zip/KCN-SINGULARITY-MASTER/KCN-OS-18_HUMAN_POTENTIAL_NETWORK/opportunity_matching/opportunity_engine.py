"""Opportunity definitions and matching engine."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class Opportunity:
    title: str
    organization: str
    required_skills: Dict[str, float]
    opportunity_type: str
    opportunity_id: str = field(default_factory=lambda: f"KCN-OPP-{uuid4().hex[:12].upper()}")


@dataclass(frozen=True)
class OpportunityMatch:
    opportunity_id: str
    user_id: str
    match_score: float
    missing_skills: List[str]


class OpportunityEngine:
    def __init__(self) -> None:
        self._opportunities: Dict[str, Opportunity] = {}

    def add(self, *, title: str, organization: str, required_skills: Dict[str, float], opportunity_type: str) -> Opportunity:
        opportunity = Opportunity(title=title, organization=organization, required_skills=required_skills, opportunity_type=opportunity_type)
        self._opportunities[opportunity.opportunity_id] = opportunity
        return opportunity

    def match(self, *, user_id: str, skill_scores: Dict[str, float]) -> List[OpportunityMatch]:
        matches: List[OpportunityMatch] = []
        for opportunity in self._opportunities.values():
            if not opportunity.required_skills:
                score = 1.0
                missing: List[str] = []
            else:
                ratios = []
                missing = []
                for skill, required in opportunity.required_skills.items():
                    current = skill_scores.get(skill, 0.0)
                    if current < required:
                        missing.append(skill)
                    ratios.append(min(1.0, current / required) if required else 1.0)
                score = sum(ratios) / len(ratios)
            matches.append(OpportunityMatch(opportunity_id=opportunity.opportunity_id, user_id=user_id, match_score=round(score, 3), missing_skills=missing))
        return sorted(matches, key=lambda item: item.match_score, reverse=True)
