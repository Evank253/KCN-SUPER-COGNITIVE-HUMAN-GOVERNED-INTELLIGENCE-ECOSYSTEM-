"""Talent matching utilities."""

from __future__ import annotations

from typing import Dict, List


class TalentMatcher:
    def rank_candidates(self, *, candidate_scores: Dict[str, Dict[str, float]], required_skills: Dict[str, float]) -> List[tuple[str, float]]:
        ranked = []
        for user_id, scores in candidate_scores.items():
            if not required_skills:
                ranked.append((user_id, 1.0))
                continue
            match = sum(min(1.0, scores.get(skill, 0.0) / required) for skill, required in required_skills.items()) / len(required_skills)
            ranked.append((user_id, round(match, 3)))
        return sorted(ranked, key=lambda item: item[1], reverse=True)
