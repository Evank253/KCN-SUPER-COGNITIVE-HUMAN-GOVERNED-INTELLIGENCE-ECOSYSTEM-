"""Career navigation recommendations."""

from __future__ import annotations

from typing import Dict, List


class CareerNavigator:
    def recommend_growth_path(self, *, current_scores: Dict[str, float], target_role_skills: Dict[str, float]) -> List[str]:
        gaps = [skill for skill, required in target_role_skills.items() if current_scores.get(skill, 0.0) < required]
        return sorted(gaps, key=lambda skill: target_role_skills[skill] - current_scores.get(skill, 0.0), reverse=True)
