"""Opportunity matching exports."""

from .opportunity_engine import Opportunity, OpportunityEngine, OpportunityMatch
from .talent_matching import TalentMatcher
from .career_navigation import CareerNavigator
from .project_matching import ProjectMatcher

__all__ = ["Opportunity", "OpportunityEngine", "OpportunityMatch", "TalentMatcher", "CareerNavigator", "ProjectMatcher"]
