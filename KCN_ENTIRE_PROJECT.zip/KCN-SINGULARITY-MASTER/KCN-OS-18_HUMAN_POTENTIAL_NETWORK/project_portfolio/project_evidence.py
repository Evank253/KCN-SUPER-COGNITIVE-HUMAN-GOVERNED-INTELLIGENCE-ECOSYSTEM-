"""Project evidence for portfolios."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import List
from uuid import uuid4


@dataclass(frozen=True)
class ProjectEvidence:
    project_id: str
    user_id: str
    artifacts: List[str]
    skills: List[str]
    evidence_hash: str
    evidence_id: str = field(default_factory=lambda: f"KCN-PROJEVID-{uuid4().hex[:12].upper()}")


class ProjectEvidenceBuilder:
    def create(self, *, project_id: str, user_id: str, artifacts: List[str], skills: List[str]) -> ProjectEvidence:
        payload = {"project_id": project_id, "user_id": user_id, "artifacts": sorted(artifacts), "skills": sorted(skills)}
        evidence_hash = "sha256:" + hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        return ProjectEvidence(project_id=project_id, user_id=user_id, artifacts=artifacts, skills=skills, evidence_hash=evidence_hash)
