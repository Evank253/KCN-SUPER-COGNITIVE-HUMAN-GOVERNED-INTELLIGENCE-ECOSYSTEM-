"""Portfolio builder for verified project evidence."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class Portfolio:
    user_id: str
    title: str
    project_ids: List[str]
    credential_ids: List[str]
    portfolio_id: str = field(default_factory=lambda: f"KCN-PORT-{uuid4().hex[:12].upper()}")


class PortfolioBuilder:
    def build(self, *, user_id: str, title: str, project_ids: List[str], credential_ids: List[str]) -> Portfolio:
        return Portfolio(user_id=user_id, title=title, project_ids=project_ids, credential_ids=credential_ids)
