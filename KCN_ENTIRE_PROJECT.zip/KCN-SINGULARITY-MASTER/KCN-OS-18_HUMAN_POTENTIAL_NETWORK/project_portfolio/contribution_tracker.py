"""Contribution tracking for project portfolios."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class ContributionRecord:
    project_id: str
    contributor_id: str
    role: str
    contribution_percent: float
    contribution_id: str = field(default_factory=lambda: f"KCN-CONTRIB-{uuid4().hex[:12].upper()}")


class ContributionTracker:
    def __init__(self) -> None:
        self._records: List[ContributionRecord] = []

    def add(self, *, project_id: str, contributor_id: str, role: str, contribution_percent: float) -> ContributionRecord:
        record = ContributionRecord(project_id=project_id, contributor_id=contributor_id, role=role, contribution_percent=contribution_percent)
        self._records.append(record)
        return record

    def project_split(self, project_id: str) -> Dict[str, float]:
        split: Dict[str, float] = {}
        for record in self._records:
            if record.project_id == project_id:
                split[record.contributor_id] = split.get(record.contributor_id, 0.0) + record.contribution_percent
        return split
