"""Reputation profile derived from verified work."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ReputationProfile:
    user_id: str
    verified_projects: int
    verified_credentials: int
    collaboration_score: float
    reputation_score: float


class ReputationProfileBuilder:
    def build(self, *, user_id: str, verified_projects: int, verified_credentials: int, collaboration_score: float) -> ReputationProfile:
        score = min(1.0, (verified_projects * 0.08) + (verified_credentials * 0.1) + (collaboration_score * 0.4))
        return ReputationProfile(
            user_id=user_id,
            verified_projects=verified_projects,
            verified_credentials=verified_credentials,
            collaboration_score=collaboration_score,
            reputation_score=round(score, 3),
        )
