from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from credential_system import BadgeGenerator, CertificateManager, DigitalCredentialIssuer, VerificationRecordStore
from project_portfolio import ContributionTracker, PortfolioBuilder, ProjectEvidenceBuilder, ReputationProfileBuilder


class TestCredentials(unittest.TestCase):
    def test_credential_badge_portfolio_and_reputation(self) -> None:
        credential = DigitalCredentialIssuer().issue(
            user_id="user-1",
            skill="cad_design",
            level="intermediate",
            issuer="KCN Human Potential Network",
            evidence_ids=["KCN-EVID-001"],
        )
        self.assertTrue(credential.credential_hash.startswith("sha256:"))

        manager = CertificateManager()
        manager.add(credential)
        self.assertEqual(manager.list_for_user("user-1")[0].credential_id, credential.credential_id)

        badge = BadgeGenerator().generate(
            user_id="user-1",
            badge_type="skill",
            title="CAD Design Verified",
            evidence_ref=credential.credential_id,
        )
        self.assertEqual(badge.evidence_ref, credential.credential_id)

        verification = VerificationRecordStore().add(
            subject_id=credential.credential_id,
            verifier="assurance-engine",
            status="VERIFIED",
        )
        self.assertEqual(verification.status, "VERIFIED")

        project_evidence = ProjectEvidenceBuilder().create(
            project_id="project:smart-home",
            user_id="user-1",
            artifacts=["artifact:cad-model"],
            skills=["cad_design"],
        )
        self.assertTrue(project_evidence.evidence_hash.startswith("sha256:"))

        tracker = ContributionTracker()
        tracker.add(project_id="project:smart-home", contributor_id="user-1", role="designer", contribution_percent=75.0)
        self.assertEqual(tracker.project_split("project:smart-home")["user-1"], 75.0)

        portfolio = PortfolioBuilder().build(
            user_id="user-1",
            title="Verified Design Portfolio",
            project_ids=["project:smart-home"],
            credential_ids=[credential.credential_id],
        )
        self.assertEqual(portfolio.credential_ids, [credential.credential_id])

        reputation = ReputationProfileBuilder().build(
            user_id="user-1",
            verified_projects=3,
            verified_credentials=2,
            collaboration_score=0.8,
        )
        self.assertGreater(reputation.reputation_score, 0.7)


if __name__ == "__main__":
    unittest.main()
