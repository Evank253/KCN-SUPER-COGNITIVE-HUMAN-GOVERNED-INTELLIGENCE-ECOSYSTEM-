from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from integrity_layer import AchievementHasher, CredentialAuditor, EvidenceChain, FraudDetector


class TestIntegrity(unittest.TestCase):
    def test_achievement_hashing_evidence_chain_audit_and_fraud_detection(self) -> None:
        achievement = {
            "user_id": "user-1",
            "title": "CAD Challenge Complete",
            "evidence": "KCN-EVID-001",
        }
        achievement_hash = AchievementHasher().hash_achievement(achievement)
        self.assertTrue(achievement_hash.startswith("sha256:"))

        chain = EvidenceChain()
        e1 = chain.append(subject_id="user-1", action="EVIDENCE_SUBMITTED", evidence_hash=achievement_hash)
        e2 = chain.append(subject_id="user-1", action="CREDENTIAL_ISSUED", evidence_hash="sha256:abc")
        self.assertEqual(e2.previous_hash, e1.chain_hash)
        self.assertTrue(chain.verify())

        audit_findings = CredentialAuditor().audit(
            {
                "credential_hash": "sha256:123",
                "evidence_ids": ["KCN-EVID-001"],
                "status": "ACTIVE",
            }
        )
        self.assertEqual(audit_findings, [])

        flagged = FraudDetector().flag_claims(
            claims=[
                {"evidence_hash": "sha256:duplicate", "verification_status": "VERIFIED"},
                {"evidence_hash": "sha256:duplicate", "verification_status": "VERIFIED"},
                {"verification_status": "UNKNOWN"},
            ]
        )
        self.assertEqual(len(flagged), 2)


if __name__ == "__main__":
    unittest.main()
