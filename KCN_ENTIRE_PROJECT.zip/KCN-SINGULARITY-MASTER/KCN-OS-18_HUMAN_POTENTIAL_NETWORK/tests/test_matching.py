from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from connectors import TrustConnector
from mentorship_network import CommunitySupport, ExpertNetwork, MentorMatcher, PeerLearning
from opportunity_matching import CareerNavigator, OpportunityEngine, ProjectMatcher, TalentMatcher


class TestMatching(unittest.TestCase):
    def test_opportunity_talent_career_project_and_mentorship_matching(self) -> None:
        engine = OpportunityEngine()
        opportunity = engine.add(
            title="Robotics design internship",
            organization="KCN Labs",
            required_skills={"cad_design": 0.7, "programming": 0.6},
            opportunity_type="internship",
        )
        matches = engine.match(user_id="user-1", skill_scores={"cad_design": 0.8, "programming": 0.3})
        self.assertEqual(matches[0].opportunity_id, opportunity.opportunity_id)
        self.assertIn("programming", matches[0].missing_skills)

        ranked = TalentMatcher().rank_candidates(
            candidate_scores={
                "user-1": {"cad_design": 0.8, "programming": 0.3},
                "user-2": {"cad_design": 0.9, "programming": 0.9},
            },
            required_skills={"cad_design": 0.7, "programming": 0.6},
        )
        self.assertEqual(ranked[0][0], "user-2")

        gaps = CareerNavigator().recommend_growth_path(
            current_scores={"cad_design": 0.8, "programming": 0.3},
            target_role_skills={"cad_design": 0.7, "programming": 0.6},
        )
        self.assertEqual(gaps, ["programming"])

        projects = ProjectMatcher().suggest_projects(interests=["cad_design"], skill_scores={"cad_design": 0.8})
        self.assertEqual(projects, ["advanced:cad_design:project"])

        mentors = MentorMatcher().match(
            learner_needs=["programming"],
            mentor_expertise={"mentor-1": ["cad_design"], "mentor-2": ["programming", "robotics"]},
        )
        self.assertEqual(mentors[0][0], "mentor-2")

        expert_network = ExpertNetwork()
        expert = expert_network.register(name="Robotics Expert", expertise=["robotics", "programming"])
        self.assertEqual(expert_network.find("robotics")[0].expert_id, expert.expert_id)

        group = PeerLearning().form_group(learners_by_skill={"programming": ["user-1", "user-3"]}, skill="programming")
        self.assertEqual(len(group), 2)
        self.assertEqual(CommunitySupport().route_question(topic="programming")["moderation"], "enabled")

        connector = TrustConnector(handler=lambda operation, payload: {"operation": operation, "trusted": True, "payload": payload})
        response = connector.send("verify_profile", {"user_id": "user-1"})
        self.assertTrue(response.accepted)
        self.assertTrue(response.payload["trusted"])


if __name__ == "__main__":
    unittest.main()
