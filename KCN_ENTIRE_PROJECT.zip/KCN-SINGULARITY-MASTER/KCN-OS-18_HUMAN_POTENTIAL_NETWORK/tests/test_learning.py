from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from education_engine import AdaptiveLearningEngine, CurriculumBuilder, InstructorAssistant, LearningPlatform


class TestLearning(unittest.TestCase):
    def test_learning_goal_curriculum_and_adaptive_recommendation(self) -> None:
        platform = LearningPlatform()
        goal = platform.create_goal(user_id="user-1", title="Build robotic vehicle", target_skills=["cad", "electronics", "programming"])
        a1 = platform.add_activity(goal_id=goal.goal_id, title="CAD basics", skill="cad")
        platform.add_activity(goal_id=goal.goal_id, title="Electronics intro", skill="electronics")
        platform.complete_activity(a1.activity_id)
        self.assertEqual(platform.progress(goal.goal_id), 0.5)

        curriculum = CurriculumBuilder().build(title="Robotic Vehicle Path", skills=goal.target_skills)
        self.assertEqual(len(curriculum.modules), 3)

        recommendations = AdaptiveLearningEngine().recommend_next(
            skill_scores={"cad": 0.8, "electronics": 0.4},
            target_skills=goal.target_skills,
        )
        self.assertEqual(recommendations, ["electronics", "programming"])

        guidance = InstructorAssistant().generate_guidance(
            learner_name="Creator One",
            weak_skills=recommendations,
            strengths=["cad"],
        )
        self.assertIn("project-based", guidance["recommendation"])


if __name__ == "__main__":
    unittest.main()
