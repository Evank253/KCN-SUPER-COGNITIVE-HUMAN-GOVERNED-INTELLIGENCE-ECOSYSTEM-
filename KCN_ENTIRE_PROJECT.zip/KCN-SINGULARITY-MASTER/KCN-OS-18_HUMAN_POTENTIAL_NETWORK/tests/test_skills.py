from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from capability_graph import CapabilityPredictor, ExperienceMapper, GrowthTracker, HumanSkillGraph
from challenge_system import ChallengeGenerator, PerformanceAnalyzer, SkillTestRunner, SimulationTaskBuilder
from skill_verification import CompetencyScoring, EvidenceValidator, SkillAssessment


class TestSkills(unittest.TestCase):
    def test_evidence_assessment_competency_and_capability_graph(self) -> None:
        evidence = EvidenceValidator().submit(
            user_id="user-1",
            skill="cybersecurity_fundamentals",
            evidence_type="project",
            description="Completed defensive security lab and wrote remediation report.",
            references=["project:security-lab-001"],
        )
        verified = EvidenceValidator().validate(evidence)
        self.assertEqual(verified.verification_status, "VERIFIED")
        self.assertTrue(verified.evidence_hash.startswith("sha256:"))

        assessment = SkillAssessment().assess(
            user_id="user-1",
            skill="cybersecurity_fundamentals",
            rubric_scores={"concepts": 0.9, "practice": 0.8, "documentation": 0.85},
        )
        self.assertEqual(assessment.level, "advanced")

        competency = CompetencyScoring().calculate(
            skill="cybersecurity_fundamentals",
            assessment_score=assessment.score,
            evidence_verified=True,
            challenge_passed=True,
        )
        self.assertEqual(competency.confidence, "High")

        graph = HumanSkillGraph()
        node = graph.upsert_skill(
            user_id="user-1",
            skill=competency.skill,
            score=competency.score,
            evidence_refs=[verified.evidence_id],
        )
        self.assertEqual(graph.skills_for_user("user-1")[0].node_id, node.node_id)
        self.assertGreater(graph.profile_score("user-1"), 0.8)

        experience = ExperienceMapper().map_project(
            user_id="user-1",
            project_id="project:security-lab-001",
            skills=["cybersecurity_fundamentals"],
            contribution_summary="Performed defensive audit and remediation planning.",
        )
        self.assertIn("cybersecurity_fundamentals", experience.skills)

        growth = GrowthTracker()
        growth.record(user_id="user-1", skill="cybersecurity_fundamentals", previous_score=0.5, new_score=competency.score)
        self.assertGreater(growth.trajectory("user-1")["cybersecurity_fundamentals"], 0)

        readiness = CapabilityPredictor().predict_readiness(
            current_scores={"cybersecurity_fundamentals": competency.score},
            required_scores={"cybersecurity_fundamentals": 0.8},
        )
        self.assertEqual(readiness, 1.0)

    def test_challenge_and_performance_analysis(self) -> None:
        challenge = ChallengeGenerator().generate_for_skill("cad_design")
        self.assertIn("artifact", " ".join(challenge.requirements))
        task = SimulationTaskBuilder().build(skill="cad_design", scenario="model a bracket", success_metric="passes stress check")
        self.assertEqual(task.skill, "cad_design")
        score = SkillTestRunner().score_submission(rubric={"accuracy": 0.8, "documentation": 0.7})
        report = PerformanceAnalyzer().analyze(scores={"accuracy": score, "documentation": 0.7, "speed": 0.9})
        self.assertIn("speed", report["strengths"])


if __name__ == "__main__":
    unittest.main()
