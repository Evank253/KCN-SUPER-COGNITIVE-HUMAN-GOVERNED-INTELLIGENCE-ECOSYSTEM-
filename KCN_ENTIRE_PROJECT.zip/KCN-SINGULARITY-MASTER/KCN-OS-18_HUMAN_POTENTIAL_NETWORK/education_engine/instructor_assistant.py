"""Instructor assistant summaries for learning plans."""

from __future__ import annotations

from typing import Dict, List


class InstructorAssistant:
    def generate_guidance(self, *, learner_name: str, weak_skills: List[str], strengths: List[str]) -> Dict[str, object]:
        return {
            "learner": learner_name,
            "strengths": strengths,
            "focus_areas": weak_skills,
            "recommendation": "Use project-based practice and submit evidence for verification.",
        }
