"""Learning platform primitives for KCN Human Potential Network."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Iterable, List, Optional
from uuid import uuid4


@dataclass(frozen=True)
class LearningGoal:
    user_id: str
    title: str
    target_skills: List[str]
    goal_id: str = field(default_factory=lambda: f"KCN-GOAL-{uuid4().hex[:12].upper()}")
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    status: str = "ACTIVE"


@dataclass(frozen=True)
class LearningActivity:
    goal_id: str
    title: str
    skill: str
    difficulty: str
    activity_id: str = field(default_factory=lambda: f"KCN-ACTIVITY-{uuid4().hex[:12].upper()}")
    completed: bool = False


class LearningPlatform:
    """Tracks learning goals and activities."""

    def __init__(self) -> None:
        self._goals: Dict[str, LearningGoal] = {}
        self._activities: Dict[str, LearningActivity] = {}

    def create_goal(self, *, user_id: str, title: str, target_skills: Iterable[str]) -> LearningGoal:
        goal = LearningGoal(user_id=user_id, title=title, target_skills=sorted(set(target_skills)))
        self._goals[goal.goal_id] = goal
        return goal

    def add_activity(self, *, goal_id: str, title: str, skill: str, difficulty: str = "beginner") -> LearningActivity:
        if goal_id not in self._goals:
            raise KeyError(f"unknown goal: {goal_id}")
        activity = LearningActivity(goal_id=goal_id, title=title, skill=skill, difficulty=difficulty)
        self._activities[activity.activity_id] = activity
        return activity

    def complete_activity(self, activity_id: str) -> LearningActivity:
        activity = self._activities.get(activity_id)
        if activity is None:
            raise KeyError(f"unknown activity: {activity_id}")
        completed = LearningActivity(**{**activity.__dict__, "completed": True})
        self._activities[activity_id] = completed
        return completed

    def activities_for_goal(self, goal_id: str) -> List[LearningActivity]:
        return [item for item in self._activities.values() if item.goal_id == goal_id]

    def progress(self, goal_id: str) -> float:
        activities = self.activities_for_goal(goal_id)
        if not activities:
            return 0.0
        completed = len([item for item in activities if item.completed])
        return completed / len(activities)
