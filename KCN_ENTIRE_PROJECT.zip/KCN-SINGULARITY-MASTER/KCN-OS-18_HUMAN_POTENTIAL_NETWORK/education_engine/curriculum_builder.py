"""Curriculum builder for evidence-based learning paths."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, List
from uuid import uuid4


@dataclass(frozen=True)
class CurriculumModule:
    title: str
    skill: str
    level: str
    outcomes: List[str]


@dataclass(frozen=True)
class Curriculum:
    title: str
    modules: List[CurriculumModule]
    curriculum_id: str = field(default_factory=lambda: f"KCN-CURRICULUM-{uuid4().hex[:12].upper()}")


class CurriculumBuilder:
    def build(self, *, title: str, skills: Iterable[str], starting_level: str = "beginner") -> Curriculum:
        modules = [
            CurriculumModule(
                title=f"{skill.replace('_', ' ').title()} Foundations",
                skill=skill,
                level=starting_level,
                outcomes=[f"Explain {skill}", f"Complete a practical {skill} challenge", f"Produce evidence for {skill}"],
            )
            for skill in skills
        ]
        return Curriculum(title=title, modules=modules)
