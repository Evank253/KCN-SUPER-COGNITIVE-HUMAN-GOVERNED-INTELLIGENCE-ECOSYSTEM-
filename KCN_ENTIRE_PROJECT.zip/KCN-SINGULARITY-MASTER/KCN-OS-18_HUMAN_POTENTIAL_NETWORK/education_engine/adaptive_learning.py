"""Adaptive learning recommendation logic."""

from __future__ import annotations

from typing import Dict, List


class AdaptiveLearningEngine:
    """Recommends next skills based on current scores."""

    def recommend_next(self, *, skill_scores: Dict[str, float], target_skills: List[str]) -> List[str]:
        missing = [skill for skill in target_skills if skill not in skill_scores]
        weak = [skill for skill, score in skill_scores.items() if skill in target_skills and score < 0.70]
        return sorted(set(missing + weak))

    def difficulty_for_score(self, score: float) -> str:
        if score < 0.35:
            return "beginner"
        if score < 0.70:
            return "intermediate"
        return "advanced"
