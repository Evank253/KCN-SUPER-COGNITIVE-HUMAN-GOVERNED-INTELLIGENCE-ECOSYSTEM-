"""Skill test scoring for generated challenges."""

from __future__ import annotations

from typing import Dict


class SkillTestRunner:
    def score_submission(self, *, rubric: Dict[str, float]) -> float:
        if not rubric:
            return 0.0
        return round(sum(max(0.0, min(1.0, value)) for value in rubric.values()) / len(rubric), 3)
