"""Simulation-backed challenge tasks."""

from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4


@dataclass(frozen=True)
class SimulationTask:
    skill: str
    scenario: str
    success_metric: str
    task_id: str = field(default_factory=lambda: f"KCN-SIMTASK-{uuid4().hex[:12].upper()}")


class SimulationTaskBuilder:
    def build(self, *, skill: str, scenario: str, success_metric: str) -> SimulationTask:
        return SimulationTask(skill=skill, scenario=scenario, success_metric=success_metric)
