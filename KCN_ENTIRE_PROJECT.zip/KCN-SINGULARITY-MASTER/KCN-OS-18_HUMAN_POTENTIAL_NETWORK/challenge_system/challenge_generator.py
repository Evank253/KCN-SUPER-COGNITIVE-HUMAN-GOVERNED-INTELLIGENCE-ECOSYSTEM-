"""Challenge generation for skills."""

from __future__ import annotations

from skill_verification.practical_challenges import PracticalChallenge, PracticalChallengeFactory


class ChallengeGenerator:
    def __init__(self) -> None:
        self.factory = PracticalChallengeFactory()

    def generate_for_skill(self, skill: str, difficulty: str = "intermediate") -> PracticalChallenge:
        return self.factory.create(skill=skill, difficulty=difficulty)
