"""Performance analysis for challenges."""

from __future__ import annotations

from typing import Dict, List


class PerformanceAnalyzer:
    def analyze(self, *, scores: Dict[str, float]) -> Dict[str, object]:
        weak = [name for name, score in scores.items() if score < 0.65]
        strong = [name for name, score in scores.items() if score >= 0.85]
        average = sum(scores.values()) / len(scores) if scores else 0.0
        return {"average": round(average, 3), "strengths": strong, "improvement_areas": weak}
