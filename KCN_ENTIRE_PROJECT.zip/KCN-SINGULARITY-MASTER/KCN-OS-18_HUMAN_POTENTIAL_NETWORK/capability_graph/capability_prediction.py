"""Simple capability prediction from skill trajectory."""

from __future__ import annotations

from typing import Dict


class CapabilityPredictor:
    def predict_readiness(self, *, current_scores: Dict[str, float], required_scores: Dict[str, float]) -> float:
        if not required_scores:
            return 1.0
        readiness = []
        for skill, required in required_scores.items():
            current = current_scores.get(skill, 0.0)
            readiness.append(min(1.0, current / required) if required > 0 else 1.0)
        return round(sum(readiness) / len(readiness), 3)
