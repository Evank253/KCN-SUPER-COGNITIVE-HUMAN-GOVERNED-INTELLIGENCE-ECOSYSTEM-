"""Map experiences to capability evidence."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List
from uuid import uuid4


@dataclass(frozen=True)
class ExperienceMap:
    user_id: str
    project_id: str
    skills: List[str]
    contribution_summary: str
    experience_id: str = field(default_factory=lambda: f"KCN-EXP-{uuid4().hex[:12].upper()}")


class ExperienceMapper:
    def map_project(self, *, user_id: str, project_id: str, skills: List[str], contribution_summary: str) -> ExperienceMap:
        return ExperienceMap(user_id=user_id, project_id=project_id, skills=sorted(set(skills)), contribution_summary=contribution_summary)
