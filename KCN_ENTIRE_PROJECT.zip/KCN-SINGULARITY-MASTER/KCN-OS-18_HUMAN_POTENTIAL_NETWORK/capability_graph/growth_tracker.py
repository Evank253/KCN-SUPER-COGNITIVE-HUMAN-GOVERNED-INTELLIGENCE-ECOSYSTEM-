"""Growth tracking for capability profiles."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class GrowthRecord:
    user_id: str
    skill: str
    previous_score: float
    new_score: float
    record_id: str = field(default_factory=lambda: f"KCN-GROWTH-{uuid4().hex[:12].upper()}")
    recorded_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class GrowthTracker:
    def __init__(self) -> None:
        self._records: List[GrowthRecord] = []

    def record(self, *, user_id: str, skill: str, previous_score: float, new_score: float) -> GrowthRecord:
        record = GrowthRecord(user_id=user_id, skill=skill, previous_score=previous_score, new_score=new_score)
        self._records.append(record)
        return record

    def trajectory(self, user_id: str) -> Dict[str, float]:
        growth: Dict[str, float] = {}
        for record in self._records:
            if record.user_id == user_id:
                growth[record.skill] = growth.get(record.skill, 0.0) + (record.new_score - record.previous_score)
        return {skill: round(delta, 3) for skill, delta in growth.items()}
