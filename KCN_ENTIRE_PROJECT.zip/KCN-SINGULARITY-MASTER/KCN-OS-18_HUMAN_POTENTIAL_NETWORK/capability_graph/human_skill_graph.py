"""Human capability graph."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class SkillNode:
    user_id: str
    skill: str
    score: float
    evidence_refs: List[str]
    node_id: str = field(default_factory=lambda: f"KCN-SKILLNODE-{uuid4().hex[:12].upper()}")


class HumanSkillGraph:
    def __init__(self) -> None:
        self._nodes: Dict[str, SkillNode] = {}
        self._by_user: Dict[str, List[str]] = defaultdict(list)

    def upsert_skill(self, *, user_id: str, skill: str, score: float, evidence_refs: List[str]) -> SkillNode:
        existing = next((self._nodes[node_id] for node_id in self._by_user[user_id] if self._nodes[node_id].skill == skill), None)
        node_id = existing.node_id if existing else f"KCN-SKILLNODE-{uuid4().hex[:12].upper()}"
        node = SkillNode(node_id=node_id, user_id=user_id, skill=skill, score=max(0.0, min(1.0, score)), evidence_refs=evidence_refs)
        self._nodes[node.node_id] = node
        if node.node_id not in self._by_user[user_id]:
            self._by_user[user_id].append(node.node_id)
        return node

    def skills_for_user(self, user_id: str) -> List[SkillNode]:
        return sorted([self._nodes[node_id] for node_id in self._by_user.get(user_id, [])], key=lambda item: item.skill)

    def profile_score(self, user_id: str) -> float:
        skills = self.skills_for_user(user_id)
        if not skills:
            return 0.0
        return round(sum(skill.score for skill in skills) / len(skills), 3)
