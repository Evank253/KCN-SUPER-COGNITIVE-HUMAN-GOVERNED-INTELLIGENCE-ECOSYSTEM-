"""Fraud detection heuristics for evidence and credentials."""

from __future__ import annotations

from typing import Dict, List


class FraudDetector:
    def flag_claims(self, *, claims: List[Dict[str, object]]) -> List[Dict[str, object]]:
        flagged = []
        seen_hashes = set()
        for claim in claims:
            evidence_hash = claim.get("evidence_hash")
            reasons = []
            if not evidence_hash:
                reasons.append("missing evidence hash")
            elif evidence_hash in seen_hashes:
                reasons.append("duplicate evidence hash")
            seen_hashes.add(evidence_hash)
            if claim.get("verification_status") not in {"VERIFIED", "PENDING", "NEEDS_REVIEW"}:
                reasons.append("unknown verification status")
            if reasons:
                flagged.append({"claim": claim, "reasons": reasons})
        return flagged
