"""Credential audit checks."""

from __future__ import annotations

from typing import Dict, List


class CredentialAuditor:
    def audit(self, credential: Dict[str, object]) -> List[str]:
        findings: List[str] = []
        if not credential.get("credential_hash"):
            findings.append("missing credential hash")
        if not credential.get("evidence_ids"):
            findings.append("missing evidence references")
        if credential.get("status") == "REVOKED":
            findings.append("credential revoked")
        return findings
