"""Hash achievements for tamper-evident records."""

from __future__ import annotations

import hashlib
import json


class AchievementHasher:
    def hash_achievement(self, achievement: dict) -> str:
        canonical = json.dumps(achievement, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canonical.encode()).hexdigest()
