"""Evidence hash chain for Human Potential records."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import List, Optional
from uuid import uuid4


@dataclass(frozen=True)
class EvidenceChainEntry:
    subject_id: str
    action: str
    evidence_hash: str
    entry_id: str = field(default_factory=lambda: f"KCN-ECHAIN-{uuid4().hex[:12].upper()}")
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    previous_hash: Optional[str] = None
    chain_hash: str = ""


class EvidenceChain:
    def __init__(self) -> None:
        self._entries: List[EvidenceChainEntry] = []

    def append(self, *, subject_id: str, action: str, evidence_hash: str) -> EvidenceChainEntry:
        previous_hash = self._entries[-1].chain_hash if self._entries else None
        base = EvidenceChainEntry(subject_id=subject_id, action=action, evidence_hash=evidence_hash, previous_hash=previous_hash)
        chain_hash = self._hash(base)
        entry = EvidenceChainEntry(**{**asdict(base), "chain_hash": chain_hash})
        self._entries.append(entry)
        return entry

    def verify(self) -> bool:
        previous_hash = None
        for entry in self._entries:
            if entry.previous_hash != previous_hash:
                return False
            if entry.chain_hash != self._hash(EvidenceChainEntry(**{**asdict(entry), "chain_hash": ""})):
                return False
            previous_hash = entry.chain_hash
        return True

    def entries(self) -> List[EvidenceChainEntry]:
        return list(self._entries)

    @staticmethod
    def _hash(entry: EvidenceChainEntry) -> str:
        payload = asdict(entry)
        payload["chain_hash"] = ""
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canonical.encode()).hexdigest()
