"""Digital credential issuing for verified skills."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List
from uuid import uuid4


@dataclass(frozen=True)
class DigitalCredential:
    user_id: str
    skill: str
    level: str
    issuer: str
    evidence_ids: List[str]
    credential_id: str = field(default_factory=lambda: f"KCN-CRED-{uuid4().hex[:12].upper()}")
    issued_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    credential_hash: str = ""
    status: str = "ACTIVE"


class DigitalCredentialIssuer:
    def issue(self, *, user_id: str, skill: str, level: str, issuer: str, evidence_ids: List[str]) -> DigitalCredential:
        payload = {"user_id": user_id, "skill": skill, "level": level, "issuer": issuer, "evidence_ids": sorted(evidence_ids)}
        credential_hash = "sha256:" + hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        return DigitalCredential(user_id=user_id, skill=skill, level=level, issuer=issuer, evidence_ids=evidence_ids, credential_hash=credential_hash)
