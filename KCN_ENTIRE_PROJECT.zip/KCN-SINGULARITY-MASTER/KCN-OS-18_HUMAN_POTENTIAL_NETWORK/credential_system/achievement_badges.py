"""Achievement badges for skills, projects, and milestones."""

from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4


@dataclass(frozen=True)
class AchievementBadge:
    user_id: str
    badge_type: str
    title: str
    evidence_ref: str
    badge_id: str = field(default_factory=lambda: f"KCN-BADGE-{uuid4().hex[:12].upper()}")


class BadgeGenerator:
    def generate(self, *, user_id: str, badge_type: str, title: str, evidence_ref: str) -> AchievementBadge:
        return AchievementBadge(user_id=user_id, badge_type=badge_type, title=title, evidence_ref=evidence_ref)
