"""Certificate registry."""

from __future__ import annotations

from typing import Dict, List, Optional

from .digital_credentials import DigitalCredential


class CertificateManager:
    def __init__(self) -> None:
        self._credentials: Dict[str, DigitalCredential] = {}

    def add(self, credential: DigitalCredential) -> DigitalCredential:
        self._credentials[credential.credential_id] = credential
        return credential

    def get(self, credential_id: str) -> Optional[DigitalCredential]:
        return self._credentials.get(credential_id)

    def list_for_user(self, user_id: str) -> List[DigitalCredential]:
        return [credential for credential in self._credentials.values() if credential.user_id == user_id]

    def revoke(self, credential_id: str) -> DigitalCredential:
        credential = self._credentials.get(credential_id)
        if credential is None:
            raise KeyError(f"unknown credential: {credential_id}")
        revoked = DigitalCredential(**{**credential.__dict__, "status": "REVOKED"})
        self._credentials[credential_id] = revoked
        return revoked
