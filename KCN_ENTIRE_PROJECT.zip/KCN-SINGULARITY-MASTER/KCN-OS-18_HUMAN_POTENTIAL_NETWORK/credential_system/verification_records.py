"""Verification records for credentials and badges."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from uuid import uuid4


@dataclass(frozen=True)
class VerificationRecord:
    subject_id: str
    verifier: str
    status: str
    notes: str
    record_id: str = field(default_factory=lambda: f"KCN-VERIFY-{uuid4().hex[:12].upper()}")
    verified_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class VerificationRecordStore:
    def __init__(self) -> None:
        self.records: list[VerificationRecord] = []

    def add(self, *, subject_id: str, verifier: str, status: str, notes: str = "") -> VerificationRecord:
        record = VerificationRecord(subject_id=subject_id, verifier=verifier, status=status, notes=notes)
        self.records.append(record)
        return record
