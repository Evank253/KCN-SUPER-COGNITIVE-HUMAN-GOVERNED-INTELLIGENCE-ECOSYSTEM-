"""Peer learning group formation."""

from __future__ import annotations

from typing import Dict, List


class PeerLearning:
    def form_group(self, *, learners_by_skill: Dict[str, List[str]], skill: str, max_size: int = 5) -> List[str]:
        return learners_by_skill.get(skill, [])[:max_size]
