"""Community support routing."""

from __future__ import annotations

from typing import Dict


class CommunitySupport:
    def route_question(self, *, topic: str) -> Dict[str, str]:
        return {"topic": topic, "channel": f"community:{topic}", "moderation": "enabled"}
