"""Expert network registry."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class ExpertProfile:
    name: str
    expertise: List[str]
    expert_id: str = field(default_factory=lambda: f"KCN-EXPERT-{uuid4().hex[:12].upper()}")


class ExpertNetwork:
    def __init__(self) -> None:
        self._experts: Dict[str, ExpertProfile] = {}

    def register(self, *, name: str, expertise: List[str]) -> ExpertProfile:
        expert = ExpertProfile(name=name, expertise=expertise)
        self._experts[expert.expert_id] = expert
        return expert

    def find(self, skill: str) -> List[ExpertProfile]:
        return [expert for expert in self._experts.values() if skill in expert.expertise]
