"""Mentor matching by expertise overlap."""

from __future__ import annotations

from typing import Dict, List


class MentorMatcher:
    def match(self, *, learner_needs: List[str], mentor_expertise: Dict[str, List[str]]) -> List[tuple[str, int]]:
        needs = set(learner_needs)
        ranked = [(mentor_id, len(needs.intersection(skills))) for mentor_id, skills in mentor_expertise.items()]
        return [item for item in sorted(ranked, key=lambda pair: pair[1], reverse=True) if item[1] > 0]
