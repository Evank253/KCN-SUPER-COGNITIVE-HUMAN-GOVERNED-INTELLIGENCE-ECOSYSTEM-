"""Competency scoring combines assessment, evidence, and challenge outcomes."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CompetencyScore:
    skill: str
    score: float
    confidence: str


class CompetencyScoring:
    def calculate(self, *, skill: str, assessment_score: float, evidence_verified: bool, challenge_passed: bool) -> CompetencyScore:
        score = assessment_score * 0.5
        score += 0.25 if evidence_verified else 0.0
        score += 0.25 if challenge_passed else 0.0
        score = max(0.0, min(1.0, score))
        confidence = "High" if score >= 0.8 else "Medium" if score >= 0.55 else "Low"
        return CompetencyScore(skill=skill, score=round(score, 3), confidence=confidence)
