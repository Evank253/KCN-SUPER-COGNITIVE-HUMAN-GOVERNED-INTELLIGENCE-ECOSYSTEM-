"""Skill assessment records and scoring."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict
from uuid import uuid4


@dataclass(frozen=True)
class SkillAssessmentResult:
    user_id: str
    skill: str
    score: float
    level: str
    assessment_id: str = field(default_factory=lambda: f"KCN-ASSESS-{uuid4().hex[:12].upper()}")


class SkillAssessment:
    def assess(self, *, user_id: str, skill: str, rubric_scores: Dict[str, float]) -> SkillAssessmentResult:
        if not rubric_scores:
            raise ValueError("rubric_scores cannot be empty")
        score = sum(max(0.0, min(1.0, value)) for value in rubric_scores.values()) / len(rubric_scores)
        if score >= 0.85:
            level = "advanced"
        elif score >= 0.65:
            level = "intermediate"
        else:
            level = "beginner"
        return SkillAssessmentResult(user_id=user_id, skill=skill, score=round(score, 3), level=level)
