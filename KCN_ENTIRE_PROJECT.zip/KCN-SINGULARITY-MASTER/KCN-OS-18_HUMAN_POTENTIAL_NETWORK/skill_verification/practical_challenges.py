"""Practical challenge definitions for evidence-based skills."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List
from uuid import uuid4


@dataclass(frozen=True)
class PracticalChallenge:
    skill: str
    title: str
    requirements: List[str]
    difficulty: str
    challenge_id: str = field(default_factory=lambda: f"KCN-CHAL-{uuid4().hex[:12].upper()}")


class PracticalChallengeFactory:
    def create(self, *, skill: str, difficulty: str = "intermediate") -> PracticalChallenge:
        return PracticalChallenge(
            skill=skill,
            title=f"Demonstrate {skill.replace('_', ' ').title()}",
            difficulty=difficulty,
            requirements=[
                "submit a working artifact",
                "document method and decisions",
                "include verification evidence",
            ],
        )
