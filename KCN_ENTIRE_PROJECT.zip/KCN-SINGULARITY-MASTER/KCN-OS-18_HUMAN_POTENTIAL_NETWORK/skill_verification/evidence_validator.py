"""Evidence validation for skill verification."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class EvidenceRecord:
    user_id: str
    skill: str
    evidence_type: str
    description: str
    references: List[str]
    evidence_id: str = field(default_factory=lambda: f"KCN-EVID-{uuid4().hex[:12].upper()}")
    evidence_hash: str = ""
    submitted_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    verification_status: str = "PENDING"


class EvidenceValidator:
    REQUIRED_REFERENCE_PREFIXES = ("artifact:", "project:", "assessment:", "challenge:")

    def submit(self, *, user_id: str, skill: str, evidence_type: str, description: str, references: List[str]) -> EvidenceRecord:
        payload = {
            "user_id": user_id,
            "skill": skill,
            "evidence_type": evidence_type,
            "description": description,
            "references": sorted(references),
        }
        evidence_hash = "sha256:" + hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        return EvidenceRecord(
            user_id=user_id,
            skill=skill,
            evidence_type=evidence_type,
            description=description,
            references=references,
            evidence_hash=evidence_hash,
        )

    def validate(self, evidence: EvidenceRecord) -> EvidenceRecord:
        has_valid_reference = any(ref.startswith(self.REQUIRED_REFERENCE_PREFIXES) for ref in evidence.references)
        status = "VERIFIED" if has_valid_reference and evidence.description else "NEEDS_REVIEW"
        return EvidenceRecord(**{**evidence.__dict__, "verification_status": status})
