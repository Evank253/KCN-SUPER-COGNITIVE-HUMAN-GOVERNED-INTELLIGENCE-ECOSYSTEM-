"""ComplianceConnector integration adapter."""

from __future__ import annotations

from .base_connector import BaseConnector


class ComplianceConnector(BaseConnector):
    def __init__(self, handler=None) -> None:
        super().__init__(name="ComplianceConnector", handler=handler)
