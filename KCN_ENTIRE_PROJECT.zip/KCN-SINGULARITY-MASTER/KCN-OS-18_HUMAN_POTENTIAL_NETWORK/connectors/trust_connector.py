"""TrustConnector integration adapter."""

from __future__ import annotations

from .base_connector import BaseConnector


class TrustConnector(BaseConnector):
    def __init__(self, handler=None) -> None:
        super().__init__(name="TrustConnector", handler=handler)
