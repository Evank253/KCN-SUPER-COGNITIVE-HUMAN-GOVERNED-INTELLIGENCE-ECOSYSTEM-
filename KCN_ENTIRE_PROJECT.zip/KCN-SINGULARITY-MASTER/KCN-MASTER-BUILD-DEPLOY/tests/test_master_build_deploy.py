from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class TestMasterBuildDeploy(unittest.TestCase):
    def test_manifest_and_registries_exist(self):
        for rel in [
            "kcn_master_manifest.json",
            "repo_placement_map.json",
            "tools/test_registry.json",
            "benchmarks/benchmark_registry.json",
            "tools/deployment_profile.json",
            "tools/capability_taxonomy.json",
        ]:
            self.assertTrue((ROOT / rel).exists(), rel)

    def test_build_script(self):
        proc = subprocess.run([sys.executable, "build_kcn_master.py"], cwd=ROOT, text=True, capture_output=True)
        self.assertEqual(proc.returncode, 0, proc.stderr + proc.stdout)
        report = json.loads((ROOT / "reports" / "master_build_report.json").read_text())
        self.assertTrue(report["passed"])

    def test_deploy_dry_run(self):
        proc = subprocess.run([sys.executable, "deploy_kcn_local.py", "--dry-run"], cwd=ROOT, text=True, capture_output=True)
        self.assertEqual(proc.returncode, 0, proc.stderr + proc.stdout)
        report = json.loads((ROOT / "reports" / "local_deployment_plan.json").read_text())
        self.assertFalse(report["executed_deployment"])

    def test_handoff_verification_script(self):
        proc = subprocess.run([sys.executable, "verify_handoff_package.py"], cwd=ROOT, text=True, capture_output=True)
        self.assertEqual(proc.returncode, 0, proc.stderr + proc.stdout)
        report = json.loads((ROOT / "reports" / "handoff_verification.json").read_text())
        self.assertTrue(report["passed"])


if __name__ == "__main__":
    unittest.main()
