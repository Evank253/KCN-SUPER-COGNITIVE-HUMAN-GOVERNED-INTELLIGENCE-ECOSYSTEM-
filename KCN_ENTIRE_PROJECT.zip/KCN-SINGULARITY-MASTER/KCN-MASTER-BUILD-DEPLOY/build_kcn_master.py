#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
KCN_ROOT = ROOT.parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)


def sha256_file(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    manifest = json.loads((ROOT / "kcn_master_manifest.json").read_text())
    components = []
    missing = []
    for comp in manifest["target_system_components"]:
        path = (KCN_ROOT / comp["path"]).resolve()
        exists = path.exists()
        if not exists:
            missing.append(comp["path"])
        file_count = len([p for p in path.rglob("*") if p.is_file()]) if exists and path.is_dir() else (1 if exists else 0)
        components.append({"path": comp["path"], "role": comp["role"], "exists": exists, "file_count": file_count})
    build = {
        "build_id": "KCN-MASTER-BUILD-001",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "components": components,
        "missing": missing,
        "passed": not missing,
    }
    (REPORTS / "master_build_report.json").write_text(json.dumps(build, indent=2, sort_keys=True))
    md = "# KCN Master Build Report\n\n| Component | Role | Exists | Files |\n|---|---|---|---:|\n"
    for c in components:
        md += f"| `{c['path']}` | {c['role']} | {c['exists']} | {c['file_count']} |\n"
    md += f"\nPassed: **{build['passed']}**\n"
    (REPORTS / "master_build_report.md").write_text(md)
    print(json.dumps({"passed": build["passed"], "missing": missing}, indent=2))
    return 0 if build["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
