#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HOME = ROOT.parents[1]
HANDOFF = HOME / "KCN_HANDOFF_PACKAGE"
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    target = HANDOFF / "KCN_TARGET_SYSTEM.zip"
    testing = HANDOFF / "KCN_TESTING_SYSTEM.zip"
    checks = {
        "handoff_exists": HANDOFF.exists(),
        "target_zip_exists": target.exists(),
        "testing_zip_exists": testing.exists(),
        "checksums_exists": (HANDOFF / "CHECKSUMS.sha256").exists(),
    }
    hashes = {}
    if target.exists():
        hashes["KCN_TARGET_SYSTEM.zip"] = sha(target)
    if testing.exists():
        hashes["KCN_TESTING_SYSTEM.zip"] = sha(testing)
    report = {"checks": checks, "hashes": hashes, "passed": all(checks.values())}
    (REPORTS / "handoff_verification.json").write_text(json.dumps(report, indent=2, sort_keys=True))
    print(json.dumps(report, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
