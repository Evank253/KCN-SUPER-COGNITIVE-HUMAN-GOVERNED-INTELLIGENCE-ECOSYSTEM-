#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REGISTRY = json.loads((ROOT / "tools" / "test_registry.json").read_text())
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)


def run_entry(entry: dict) -> dict:
    cwd = (ROOT / entry["cwd"]).resolve()
    started = datetime.now(timezone.utc).isoformat()
    if not cwd.exists():
        return {"name": entry["name"], "cwd": str(cwd), "returncode": 127, "passed": False, "started_at": started, "completed_at": datetime.now(timezone.utc).isoformat(), "stdout": "", "stderr": "cwd missing"}
    proc = subprocess.run(entry["cmd"], cwd=cwd, text=True, capture_output=True)
    return {
        "name": entry["name"],
        "cwd": str(cwd),
        "cmd": entry["cmd"],
        "returncode": proc.returncode,
        "passed": proc.returncode == 0,
        "started_at": started,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "stdout": proc.stdout[-4000:],
        "stderr": proc.stderr[-4000:],
    }


def main() -> int:
    results = [run_entry(entry) for entry in REGISTRY["tests"]]
    summary = {
        "run_id": "KCN-MASTER-TEST-RUN",
        "total": len(results),
        "passed": len([r for r in results if r["passed"]]),
        "failed": len([r for r in results if not r["passed"]]),
        "results": results,
    }
    (REPORTS / "master_test_report.json").write_text(json.dumps(summary, indent=2, sort_keys=True))
    md = "# KCN Master Test Report\n\n| Suite | Result | Return Code |\n|---|---|---:|\n"
    for r in results:
        md += f"| {r['name']} | {'PASS' if r['passed'] else 'FAIL'} | {r['returncode']} |\n"
    md += f"\nTotal: {summary['total']}  Passed: {summary['passed']}  Failed: {summary['failed']}\n"
    (REPORTS / "master_test_report.md").write_text(md)
    print(json.dumps({"total": summary["total"], "passed": summary["passed"], "failed": summary["failed"]}, indent=2))
    return 0 if summary["failed"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
