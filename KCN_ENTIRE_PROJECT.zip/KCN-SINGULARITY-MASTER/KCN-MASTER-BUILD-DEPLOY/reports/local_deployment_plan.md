# KCN Local Deployment Plan

Profile: `local_dry_run`

Dry run: `True`

Public deployment executed: `False`

Human approval required for production release.
