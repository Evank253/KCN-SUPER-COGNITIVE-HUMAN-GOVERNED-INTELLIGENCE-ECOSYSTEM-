#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description="Create or run a local KCN deployment profile.")
    parser.add_argument("--dry-run", action="store_true", help="Only generate deployment report; do not run containers.")
    parser.add_argument("--profile", default="local_dry_run")
    args = parser.parse_args()
    profile_data = json.loads((ROOT / "tools" / "deployment_profile.json").read_text())
    profile = profile_data["profiles"].get(args.profile)
    if not profile:
        raise SystemExit(f"unknown profile: {args.profile}")
    report = {
        "deployment_id": "KCN-LOCAL-DEPLOYMENT-PLAN-001",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "profile": args.profile,
        "dry_run": args.dry_run,
        "actions": [
            "validate target system modules",
            "run master tests",
            "run benchmark campaigns",
            "create preview deployment profile",
            "require human approval before public production deployment"
        ],
        "profile_settings": profile,
        "executed_deployment": False,
        "note": "This scaffold intentionally defaults to dry-run style deployment planning. Public deployment requires explicit human approval and production infrastructure configuration."
    }
    (REPORTS / "local_deployment_plan.json").write_text(json.dumps(report, indent=2, sort_keys=True))
    md = f"# KCN Local Deployment Plan\n\nProfile: `{args.profile}`\n\nDry run: `{args.dry_run}`\n\nPublic deployment executed: `False`\n\nHuman approval required for production release.\n"
    (REPORTS / "local_deployment_plan.md").write_text(md)
    print(json.dumps({"profile": args.profile, "dry_run": args.dry_run, "executed_deployment": False}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
