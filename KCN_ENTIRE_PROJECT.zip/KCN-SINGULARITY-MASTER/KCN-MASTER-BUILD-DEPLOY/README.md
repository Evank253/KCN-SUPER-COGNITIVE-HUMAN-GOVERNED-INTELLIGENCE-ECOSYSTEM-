# KCN Master Build & Deploy Kit

This folder is the master repo assembly, testing, benchmarking, and deployment control kit for the current KCN ecosystem.

It organizes KCN as a governed cognitive AI creation ecosystem with:

- intelligence runtime
- research and knowledge discovery
- world modeling and simulation
- Vibe Director human intent layer
- Live Deployment Layer
- Human AI companion / augmentation integration
- governance and human approval boundaries
- cyber defense / digital immune principles
- internal benchmark campaigns
- external evaluation campaigns
- evidence, audit, hashes, manifests, and reproducibility records

## Important boundary

This kit does **not** prove AGI or ASI. It packages the architecture, runtime scaffolds, testing systems, evaluation campaigns, and deployment scripts needed to continue generating evidence.

## Fast commands

From the KCN repo root:

```bash
cd KCN-SINGULARITY-MASTER/KCN-MASTER-BUILD-DEPLOY
python run_all_tests.py
python run_all_benchmarks.py
python build_kcn_master.py
python deploy_kcn_local.py --dry-run
```

## Main files

```text
KCN-MASTER-BUILD-DEPLOY/
├── kcn_master_manifest.json          # master component registry
├── repo_placement_map.json           # where each package belongs in the repo
├── build_kcn_master.py               # validates structure and creates build report
├── deploy_kcn_local.py               # local dry-run/deploy profile generator
├── run_all_tests.py                  # runs all known test suites
├── run_all_benchmarks.py             # runs all known benchmark/evaluation campaigns
├── verify_handoff_package.py         # validates handoff zips/checksums
├── benchmarks/
│   ├── benchmark_registry.json       # internal + external benchmark campaign registry
│   └── evidence_ladder.json          # evidence maturity ladder
├── tools/
│   ├── test_registry.json            # test suite command registry
│   ├── deployment_profile.json       # local/container/k8s profile
│   └── capability_taxonomy.json      # KCN capability map
├── deploy/
│   ├── docker/docker-compose.kcn-master.yml
│   └── kubernetes/kcn-master-namespaces.yaml
└── tests/
    └── test_master_build_deploy.py
```

## Intended repo separation

```text
KCN_TARGET_SYSTEM
  = KCN modules being evaluated and deployed

KCN_TESTING_SYSTEM
  = independent-style evaluator, benchmark campaigns, evidence generators

KCN-MASTER-BUILD-DEPLOY
  = master orchestration layer for building, testing, benchmarking, packaging, and deployment
```
