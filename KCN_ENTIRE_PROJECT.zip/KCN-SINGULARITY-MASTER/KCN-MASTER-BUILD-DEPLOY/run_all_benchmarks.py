#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REGISTRY = json.loads((ROOT / "benchmarks" / "benchmark_registry.json").read_text())
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)


def run_cmd(entry: dict, key: str = "cmd") -> dict | None:
    if key not in entry:
        return None
    cwd = (ROOT / entry["cwd"]).resolve()
    if not cwd.exists():
        return {"cmd": entry[key], "returncode": 127, "stdout": "", "stderr": f"cwd missing: {cwd}"}
    proc = subprocess.run(entry[key], cwd=cwd, text=True, capture_output=True)
    return {"cmd": entry[key], "returncode": proc.returncode, "stdout": proc.stdout[-4000:], "stderr": proc.stderr[-4000:]}


def main() -> int:
    results = []
    for entry in REGISTRY["benchmarks"]:
        started = datetime.now(timezone.utc).isoformat()
        primary = run_cmd(entry, "cmd")
        post = run_cmd(entry, "post_cmd")
        passed = bool(primary and primary["returncode"] == 0 and (post is None or post["returncode"] == 0))
        results.append({"name": entry["name"], "evidence_level": entry.get("evidence_level"), "passed": passed, "started_at": started, "completed_at": datetime.now(timezone.utc).isoformat(), "primary": primary, "post": post})
    summary = {"total": len(results), "passed": len([r for r in results if r["passed"]]), "failed": len([r for r in results if not r["passed"]]), "results": results}
    (REPORTS / "master_benchmark_report.json").write_text(json.dumps(summary, indent=2, sort_keys=True))
    md = "# KCN Master Benchmark Report\n\n| Campaign | Evidence Level | Result |\n|---|---|---|\n"
    for r in results:
        md += f"| {r['name']} | {r['evidence_level']} | {'PASS' if r['passed'] else 'FAIL'} |\n"
    md += f"\nTotal: {summary['total']}  Passed: {summary['passed']}  Failed: {summary['failed']}\n"
    (REPORTS / "master_benchmark_report.md").write_text(md)
    print(json.dumps({"total": summary["total"], "passed": summary["passed"], "failed": summary["failed"]}, indent=2))
    return 0 if summary["failed"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
