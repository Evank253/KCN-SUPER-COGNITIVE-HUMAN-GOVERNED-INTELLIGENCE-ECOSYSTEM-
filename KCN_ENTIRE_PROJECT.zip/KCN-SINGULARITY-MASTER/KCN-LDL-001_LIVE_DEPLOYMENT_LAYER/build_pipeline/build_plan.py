from __future__ import annotations
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class BuildPlan:
    spec_id: str
    build_steps: list[str]
    artifact_type: str = "web_application"
    build_id: str = field(default_factory=lambda: f"KCN-BUILD-{uuid4().hex[:12].upper()}")

class BuildPlanner:
    def create_plan(self, build_spec: dict) -> BuildPlan:
        steps = ["install dependencies", "compile/build", "run tests", "generate preview", "run security checks"]
        return BuildPlan(spec_id=build_spec.get("spec_id", "unknown"), build_steps=steps)
