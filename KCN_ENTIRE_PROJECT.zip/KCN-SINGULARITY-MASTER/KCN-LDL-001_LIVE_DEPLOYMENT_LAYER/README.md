# KCN-LDL-001 — Live Deployment Layer

The KCN Live Deployment Layer turns approved Vibe Director build specifications into previewable and deployable application releases.

## Core Flow

```text
Build Specification
  ↓
Build Pipeline
  ↓
Preview Environment
  ↓
Testing + Security Gates
  ↓
Human Approval
  ↓
Deploy / Revise / Rollback
```

## Boundary

The system may generate builds and previews automatically, but public production deployment requires explicit human approval.
