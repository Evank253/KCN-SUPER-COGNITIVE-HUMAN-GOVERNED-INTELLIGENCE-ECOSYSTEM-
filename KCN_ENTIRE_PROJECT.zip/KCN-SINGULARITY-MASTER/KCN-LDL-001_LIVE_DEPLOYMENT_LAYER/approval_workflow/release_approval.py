from __future__ import annotations
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class ReleaseApproval:
    build_id: str
    approved: bool
    approver: str
    approval_id: str = field(default_factory=lambda: f"KCN-RELEASE-APPROVAL-{uuid4().hex[:12].upper()}")

class ReleaseApprovalWorkflow:
    def record(self, *, build_id: str, approved: bool, approver: str) -> ReleaseApproval:
        return ReleaseApproval(build_id, approved, approver)
