import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from live_deployment_layer import LiveDeploymentLayer
from rollback_system.version_control import VersionControl

class TestLiveDeployment(unittest.TestCase):
    def test_preview_and_approved_deploy(self):
        ldl=LiveDeploymentLayer(); p=ldl.preview({'spec_id':'spec1'})
        self.assertTrue(p['preview'].url.endswith(p['build_plan'].build_id))
        d=ldl.deploy_if_approved(build_id=p['build_plan'].build_id, artifact_path='/tmp/artifact', approver='human', approved=True)
        self.assertTrue(d['deployed'])
    def test_reject_without_approval(self):
        ldl=LiveDeploymentLayer(); d=ldl.deploy_if_approved(build_id='b1', artifact_path='/tmp/a', approver='human', approved=False)
        self.assertFalse(d['deployed'])
    def test_version_control(self):
        vc=VersionControl(); vc.commit(build_id='b1',version='0.1'); v=vc.commit(build_id='b2',version='0.2')
        self.assertEqual(vc.rollback_target().version,'0.1')
if __name__=='__main__': unittest.main()
