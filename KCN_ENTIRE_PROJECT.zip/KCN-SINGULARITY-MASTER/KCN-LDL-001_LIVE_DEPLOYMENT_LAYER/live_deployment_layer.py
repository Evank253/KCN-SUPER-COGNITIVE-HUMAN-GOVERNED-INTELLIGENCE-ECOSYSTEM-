from __future__ import annotations
from build_pipeline.build_plan import BuildPlanner
from preview_environment.preview_manager import PreviewManager
from akiis_integration.akiis_connector import AKIISConnector
from approval_workflow.release_approval import ReleaseApprovalWorkflow
from security_gates.release_gate import ReleaseGate
from hosting_adapters.self_hosted import SelfHostedAdapter

class LiveDeploymentLayer:
    def preview(self, build_spec: dict) -> dict:
        plan = BuildPlanner().create_plan(build_spec)
        preview = PreviewManager().create_preview(build_id=plan.build_id)
        return {"build_plan": plan, "preview": preview}
    def deploy_if_approved(self, *, build_id: str, artifact_path: str, approver: str, approved: bool) -> dict:
        eval_result = AKIISConnector().evaluate_release(build_id=build_id)
        approval = ReleaseApprovalWorkflow().record(build_id=build_id, approved=approved, approver=approver)
        gate = ReleaseGate().evaluate(tests_passed=eval_result['tests_passed'], security_score=eval_result['security_score'], performance_score=eval_result['performance_score'], approval=approval.approved)
        if not gate['passed']:
            return {"deployed": False, "gate": gate, "approval_id": approval.approval_id}
        deployment = SelfHostedAdapter().deploy(build_id=build_id, artifact_path=artifact_path)
        return {"deployed": True, "gate": gate, "deployment": deployment, "approval_id": approval.approval_id}
