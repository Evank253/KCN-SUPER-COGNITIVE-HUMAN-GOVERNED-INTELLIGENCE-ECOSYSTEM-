from __future__ import annotations

class HostingAdapter:
    name = "base"
    def deploy(self, *, build_id: str, artifact_path: str) -> dict:
        return {"accepted": False, "reason": "base adapter cannot deploy", "build_id": build_id}
