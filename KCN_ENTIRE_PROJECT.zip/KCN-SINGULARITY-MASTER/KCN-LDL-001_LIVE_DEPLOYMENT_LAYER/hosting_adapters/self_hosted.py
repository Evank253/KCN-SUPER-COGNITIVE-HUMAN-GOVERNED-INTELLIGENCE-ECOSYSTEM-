from __future__ import annotations
from .base import HostingAdapter

class SelfHostedAdapter(HostingAdapter):
    name = "self_hosted"
    def deploy(self, *, build_id: str, artifact_path: str) -> dict:
        return {"accepted": True, "provider": self.name, "build_id": build_id, "url": f"https://apps.kcn.local/{build_id}", "artifact_path": artifact_path}
