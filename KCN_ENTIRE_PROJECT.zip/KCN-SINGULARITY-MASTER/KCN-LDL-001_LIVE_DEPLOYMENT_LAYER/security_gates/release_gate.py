from __future__ import annotations

class ReleaseGate:
    def evaluate(self, *, tests_passed: bool, security_score: float, performance_score: float, approval: bool) -> dict:
        passed = tests_passed and security_score >= 0.8 and performance_score >= 0.75 and approval
        return {"passed": passed, "tests_passed": tests_passed, "security_score": security_score, "performance_score": performance_score, "approval": approval}
