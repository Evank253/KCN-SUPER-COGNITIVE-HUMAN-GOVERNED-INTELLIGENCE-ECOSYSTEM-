from __future__ import annotations
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class ReleaseVersion:
    build_id: str
    version: str
    status: str
    release_id: str = field(default_factory=lambda: f"KCN-RELEASE-{uuid4().hex[:12].upper()}")

class VersionControl:
    def __init__(self): self.versions=[]
    def commit(self, *, build_id: str, version: str) -> ReleaseVersion:
        r=ReleaseVersion(build_id, version, "COMMITTED"); self.versions.append(r); return r
    def rollback_target(self) -> ReleaseVersion | None:
        return self.versions[-2] if len(self.versions)>=2 else None
