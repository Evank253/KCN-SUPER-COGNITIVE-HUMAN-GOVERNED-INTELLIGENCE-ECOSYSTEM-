from __future__ import annotations
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class PreviewEnvironment:
    build_id: str
    url: str
    isolated: bool = True
    preview_id: str = field(default_factory=lambda: f"KCN-PREVIEW-{uuid4().hex[:12].upper()}")

class PreviewManager:
    def create_preview(self, *, build_id: str) -> PreviewEnvironment:
        return PreviewEnvironment(build_id=build_id, url=f"https://preview.kcn.local/{build_id}")
