"""Outcome analyzer."""

class OutcomeAnalyzer:
    def analyze(self, *, predicted: float, observed: float) -> dict:
        error = abs(predicted - observed)
        return {"error": round(error, 4), "supports_model": error <= 0.1}
