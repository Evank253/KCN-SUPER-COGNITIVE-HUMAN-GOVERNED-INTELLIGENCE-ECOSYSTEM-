"""Experiment design helper."""

class ExperimentDesigner:
    def design(self, *, independent_variable: str, dependent_variable: str, controls: list[str]) -> dict:
        return {"independent_variable": independent_variable, "dependent_variable": dependent_variable, "controls": controls}
