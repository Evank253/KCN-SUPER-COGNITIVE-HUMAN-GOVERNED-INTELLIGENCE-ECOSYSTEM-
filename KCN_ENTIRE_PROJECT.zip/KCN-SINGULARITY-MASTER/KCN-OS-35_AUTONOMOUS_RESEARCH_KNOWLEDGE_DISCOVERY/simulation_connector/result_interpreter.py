"""Result interpretation."""

class ResultInterpreter:
    def interpret(self, *, supports_model: bool) -> str:
        return "SUPPORTS_HYPOTHESIS" if supports_model else "REVISE_HYPOTHESIS"
