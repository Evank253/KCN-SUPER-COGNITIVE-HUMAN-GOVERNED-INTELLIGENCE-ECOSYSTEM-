"""Simulation planning."""

class SimulationPlanner:
    def plan(self, *, hypothesis: str, variables: list[str]) -> dict:
        return {"hypothesis": hypothesis, "variables": variables, "simulation_required": bool(variables)}
