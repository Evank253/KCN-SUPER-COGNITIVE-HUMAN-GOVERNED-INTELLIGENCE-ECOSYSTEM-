"""Information extraction."""

class InformationExtractor:
    def extract_claims(self, *, text: str) -> list[str]:
        parts = [p.strip() for p in text.replace('?', '.').replace('!', '.').split('.')]
        return [p for p in parts if len(p.split()) >= 3]
