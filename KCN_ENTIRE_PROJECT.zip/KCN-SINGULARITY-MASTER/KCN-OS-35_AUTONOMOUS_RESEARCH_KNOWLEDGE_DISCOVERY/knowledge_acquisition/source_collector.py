"""Source collection."""
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class SourceRecord:
    title: str
    uri: str
    source_type: str
    source_id: str = field(default_factory=lambda: f"KCN-SOURCE-{uuid4().hex[:12].upper()}")

class SourceCollector:
    def collect(self, *, title: str, uri: str, source_type: str = "document") -> SourceRecord:
        return SourceRecord(title=title, uri=uri, source_type=source_type)
