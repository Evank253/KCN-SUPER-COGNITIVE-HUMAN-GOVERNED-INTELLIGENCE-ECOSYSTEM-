"""Document analysis."""

class DocumentAnalyzer:
    def analyze(self, *, text: str) -> dict:
        words = [w.strip('.,!?;:').lower() for w in text.split() if w.strip('.,!?;:')]
        return {"word_count": len(words), "unique_terms": len(set(words)), "summary": text[:160]}
