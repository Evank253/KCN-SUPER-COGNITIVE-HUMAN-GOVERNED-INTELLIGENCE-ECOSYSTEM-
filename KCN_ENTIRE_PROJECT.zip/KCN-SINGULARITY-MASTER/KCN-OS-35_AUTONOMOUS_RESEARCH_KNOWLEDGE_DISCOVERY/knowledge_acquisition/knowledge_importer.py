"""Knowledge importer."""
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class ImportedKnowledge:
    claim: str
    source_id: str
    confidence: float
    knowledge_id: str = field(default_factory=lambda: f"KCN-KNOWLEDGE-{uuid4().hex[:12].upper()}")

class KnowledgeImporter:
    def import_claim(self, *, claim: str, source_id: str, confidence: float) -> ImportedKnowledge:
        return ImportedKnowledge(claim=claim, source_id=source_id, confidence=max(0.0, min(1.0, confidence)))
