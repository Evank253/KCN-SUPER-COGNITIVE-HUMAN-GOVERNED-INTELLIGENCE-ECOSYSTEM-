"""Relationship mapper."""
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class Relationship:
    source: str
    target: str
    relationship_type: str
    relationship_id: str = field(default_factory=lambda: f"KCN-REL-{uuid4().hex[:12].upper()}")

class RelationshipMapper:
    def relate(self, *, source: str, target: str, relationship_type: str) -> Relationship:
        return Relationship(source=source, target=target, relationship_type=relationship_type)
