"""Knowledge graph updates."""
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class KnowledgeUpdate:
    knowledge_id: str
    approved: bool
    update_id: str = field(default_factory=lambda: f"KCN-KG-UPDATE-{uuid4().hex[:12].upper()}")

class KnowledgeUpdates:
    def create(self, *, knowledge_id: str, approved: bool) -> KnowledgeUpdate:
        return KnowledgeUpdate(knowledge_id=knowledge_id, approved=approved)
