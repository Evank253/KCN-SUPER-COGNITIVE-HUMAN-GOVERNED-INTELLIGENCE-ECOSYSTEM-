"""Concept network."""

class ConceptNetwork:
    def __init__(self) -> None:
        self.concepts: set[str] = set()
    def add(self, concept: str) -> str:
        self.concepts.add(concept)
        return concept
