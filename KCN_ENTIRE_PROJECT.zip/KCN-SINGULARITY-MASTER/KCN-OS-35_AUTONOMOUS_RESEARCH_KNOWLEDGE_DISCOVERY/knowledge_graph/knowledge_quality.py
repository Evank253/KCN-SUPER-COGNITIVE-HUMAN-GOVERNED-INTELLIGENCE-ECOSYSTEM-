"""Knowledge quality scoring."""

class KnowledgeQuality:
    def score(self, *, confidence: float, review_approved: bool, provenance_present: bool) -> float:
        return round(max(0.0, min(1.0, confidence * 0.6 + (0.25 if review_approved else 0) + (0.15 if provenance_present else 0))), 3)
