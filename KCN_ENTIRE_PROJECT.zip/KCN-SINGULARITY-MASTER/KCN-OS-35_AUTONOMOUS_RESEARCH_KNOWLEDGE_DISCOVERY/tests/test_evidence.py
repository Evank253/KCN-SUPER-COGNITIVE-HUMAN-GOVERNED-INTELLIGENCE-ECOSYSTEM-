from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

from evidence_intelligence import ClaimVerifier, EvidenceValidator, ProvenanceTracker, SourceReliability
from synthesis_engine import ConceptMapper, ContradictionDetector, InsightGenerator, KnowledgeSynthesizer

class TestEvidence(unittest.TestCase):
    def test_evidence_validation_and_synthesis(self):
        reliability=SourceReliability().score(reputation=.9, recency=.8, citation_quality=.9)
        self.assertGreater(reliability, .85)
        evidence=EvidenceValidator().validate(source_score=reliability, evidence_strength=.9, reproducibility=.8)
        self.assertEqual(evidence["status"], "SUPPORTED")
        self.assertEqual(ClaimVerifier().verify(supporting=3, contradicting=0), "SUPPORTED")
        prov=ProvenanceTracker().record(subject_id="claim-1", source_id="source-1", action="VALIDATED")
        self.assertTrue(prov.provenance_id.startswith("KCN-RESEARCH-PROV-"))

        claims=["Solar batteries reduce evening demand", "not batteries reduce evening demand", "batteries reduce evening demand"]
        synthesis=KnowledgeSynthesizer().synthesize(claims)
        self.assertEqual(synthesis["claim_count"], 3)
        concepts=ConceptMapper().map_concepts(claims)
        self.assertIn("batteries", concepts)
        contradictions=ContradictionDetector().detect(["not batteries reduce evening demand", "batteries reduce evening demand"])
        self.assertEqual(len(contradictions), 1)
        insights=InsightGenerator().generate(concepts=concepts, contradictions=contradictions)
        self.assertTrue(any("Contradictions" in item for item in insights))

if __name__=='__main__': unittest.main()
