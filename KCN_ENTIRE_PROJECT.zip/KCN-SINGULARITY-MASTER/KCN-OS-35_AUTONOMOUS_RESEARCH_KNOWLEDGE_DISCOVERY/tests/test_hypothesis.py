from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

from hypothesis_engine import AssumptionAnalyzer, ExperimentBuilder, HypothesisGenerator, HypothesisRanker
from simulation_connector import ExperimentDesigner, OutcomeAnalyzer, ResultInterpreter, SimulationPlanner
from knowledge_graph import ConceptNetwork, KnowledgeQuality, KnowledgeUpdates, RelationshipMapper

class TestHypothesis(unittest.TestCase):
    def test_hypothesis_experiment_and_graph_update(self):
        h1=HypothesisGenerator().generate(observation="lower grid load", pattern="battery scheduling")
        h2=HypothesisGenerator().generate(observation="lower grid load", pattern="passive cooling")
        h2=type(h2)(**{**h2.__dict__, "confidence": .7})
        ranked=HypothesisRanker().rank([h1,h2])
        self.assertEqual(ranked[0].hypothesis_id, h2.hypothesis_id)
        assumptions=AssumptionAnalyzer().analyze(["weather stable", "occupancy known"])
        self.assertFalse(assumptions["requires_review"])
        experiment=ExperimentBuilder().build(hypothesis_id=h2.hypothesis_id, method="simulation", variables=["battery_size", "schedule"])
        self.assertEqual(experiment.method, "simulation")

        sim_plan=SimulationPlanner().plan(hypothesis=h2.statement, variables=experiment.variables)
        self.assertTrue(sim_plan["simulation_required"])
        design=ExperimentDesigner().design(independent_variable="battery_size", dependent_variable="peak_load", controls=["weather"])
        self.assertEqual(design["dependent_variable"], "peak_load")
        outcome=OutcomeAnalyzer().analyze(predicted=.8, observed=.75)
        self.assertTrue(outcome["supports_model"])
        self.assertEqual(ResultInterpreter().interpret(supports_model=True), "SUPPORTS_HYPOTHESIS")

        graph=ConceptNetwork(); graph.add("battery"); graph.add("grid")
        rel=RelationshipMapper().relate(source="battery", target="grid", relationship_type="reduces_peak_load")
        self.assertEqual(rel.source, "battery")
        update=KnowledgeUpdates().create(knowledge_id="knowledge-1", approved=True)
        self.assertTrue(update.approved)
        quality=KnowledgeQuality().score(confidence=.8, review_approved=True, provenance_present=True)
        self.assertGreater(quality, .85)

if __name__=='__main__': unittest.main()
