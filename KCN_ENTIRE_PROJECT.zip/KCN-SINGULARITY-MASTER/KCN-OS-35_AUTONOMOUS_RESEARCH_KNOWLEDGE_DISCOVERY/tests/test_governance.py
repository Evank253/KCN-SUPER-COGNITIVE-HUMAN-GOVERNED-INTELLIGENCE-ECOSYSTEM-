from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

from expert_review import ApprovalWorkflow, ExpertFeedback, PeerReviewRecord, ReviewerManager
from observability import AuditDashboard, DiscoveryTracking, ExperimentLogs, ResearchMetrics
from safety_layer import AccessControl, HumanOverride, ResearchPermissions, RiskClassifier

class TestGovernance(unittest.TestCase):
    def test_review_safety_and_observability(self):
        reviewers=ReviewerManager().assign(domain="energy", reviewers={"energy":["expert-1","expert-2"]})
        self.assertEqual(len(reviewers), 2)
        feedback=ExpertFeedback().record(reviewer="expert-1", decision="APPROVE", notes="well supported")
        self.assertEqual(feedback.decision, "APPROVE")
        self.assertTrue(ApprovalWorkflow().approved(["APPROVE", "APPROVE"]))
        review=PeerReviewRecord(subject_id="hypothesis-1", reviewer_count=2, status="APPROVED")
        self.assertEqual(review.status, "APPROVED")

        perms=ResearchPermissions(); perms.grant("agent-1", "research:read")
        self.assertTrue(perms.allowed("agent-1", "research:read"))
        self.assertTrue(AccessControl().can_access(identity_verified=True, permission_allowed=True))
        self.assertEqual(RiskClassifier().classify(safety_risk=.8, uncertainty=.5), "HIGH")
        self.assertEqual(HumanOverride().override(requested=True, authority_verified=True)["status"], "STOPPED")

        metrics=ResearchMetrics().productivity(claims=4, hypotheses=2, reviewed=1)
        self.assertEqual(metrics["review_ratio"], .5)
        discovery=DiscoveryTracking().record(title="Battery scheduling insight", status="REVIEW")
        self.assertTrue(discovery.discovery_id.startswith("KCN-DISCOVERY-TRACK-"))
        logs=ExperimentLogs(); logs.log("experiment_planned", {"id":"e1"})
        self.assertEqual(logs.logs[0]["event"], "experiment_planned")
        dashboard=AuditDashboard().build(provenance_records=3, approvals=2, risks=0)
        self.assertEqual(dashboard["status"], "OK")

if __name__=='__main__': unittest.main()
