from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

from research_engine import ResearchOrchestrator, InvestigationManager
from knowledge_acquisition import SourceCollector, DocumentAnalyzer, InformationExtractor, KnowledgeImporter
from connectors import Phase34RuntimeConnector

class TestResearch(unittest.TestCase):
    def test_research_mission_and_acquisition(self):
        mission=ResearchOrchestrator().create_mission("How can solar homes reduce grid load?")
        self.assertEqual(len(mission.question.subquestions), 4)
        self.assertGreaterEqual(len(mission.plan.steps), 7)
        manager=InvestigationManager()
        inv=manager.start(mission.plan.plan_id)
        inv=manager.complete_step(inv.investigation_id, "Collect sources")
        self.assertIn("Collect sources", inv.completed_steps)
        inv=manager.close(inv.investigation_id)
        self.assertEqual(inv.status, "COMPLETED")

        source=SourceCollector().collect(title="Solar paper", uri="memory://solar", source_type="paper")
        analysis=DocumentAnalyzer().analyze(text="Solar homes can reduce peak demand. Batteries can shift load.")
        self.assertGreater(analysis["word_count"], 5)
        claims=InformationExtractor().extract_claims(text="Solar homes can reduce peak demand. Batteries can shift load.")
        self.assertEqual(len(claims), 2)
        knowledge=KnowledgeImporter().import_claim(claim=claims[0], source_id=source.source_id, confidence=.8)
        self.assertEqual(knowledge.confidence, .8)

        conn=Phase34RuntimeConnector(handler=lambda op,payload: {"op":op,"accepted":True})
        self.assertTrue(conn.send("runtime_research", {"question": mission.question.question}).accepted)

if __name__=='__main__': unittest.main()
