"""Hypothesis ranking."""
from .hypothesis_generator import Hypothesis

class HypothesisRanker:
    def rank(self, hypotheses: list[Hypothesis]) -> list[Hypothesis]:
        return sorted(hypotheses, key=lambda item: item.confidence, reverse=True)
