"""Experiment builder."""
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class ExperimentDesign:
    hypothesis_id: str
    method: str
    variables: list[str]
    experiment_id: str = field(default_factory=lambda: f"KCN-EXPERIMENT-{uuid4().hex[:12].upper()}")

class ExperimentBuilder:
    def build(self, *, hypothesis_id: str, method: str, variables: list[str]) -> ExperimentDesign:
        return ExperimentDesign(hypothesis_id=hypothesis_id, method=method, variables=variables)
