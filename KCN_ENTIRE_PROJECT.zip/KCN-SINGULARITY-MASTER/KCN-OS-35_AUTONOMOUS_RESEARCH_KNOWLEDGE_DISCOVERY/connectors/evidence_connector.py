from .base_connector import BaseConnector
class EvidenceConnector(BaseConnector):
    def __init__(self, handler=None) -> None:
        super().__init__("EvidenceConnector", handler)
