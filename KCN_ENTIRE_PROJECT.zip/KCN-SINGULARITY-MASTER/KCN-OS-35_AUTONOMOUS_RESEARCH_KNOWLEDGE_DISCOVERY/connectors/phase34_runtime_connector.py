from .base_connector import BaseConnector
class Phase34RuntimeConnector(BaseConnector):
    def __init__(self, handler=None) -> None:
        super().__init__("Phase34RuntimeConnector", handler)
