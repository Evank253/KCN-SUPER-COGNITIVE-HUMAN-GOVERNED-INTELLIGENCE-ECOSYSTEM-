from .base_connector import BaseConnector
class GovernanceConnector(BaseConnector):
    def __init__(self, handler=None) -> None:
        super().__init__("GovernanceConnector", handler)
