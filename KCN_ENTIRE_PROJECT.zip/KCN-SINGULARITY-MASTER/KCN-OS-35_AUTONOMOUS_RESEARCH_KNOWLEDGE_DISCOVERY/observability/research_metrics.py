"""Research metrics."""

class ResearchMetrics:
    def productivity(self, *, claims: int, hypotheses: int, reviewed: int) -> dict:
        return {"claims": claims, "hypotheses": hypotheses, "reviewed": reviewed, "review_ratio": round(reviewed / hypotheses, 3) if hypotheses else 0.0}
