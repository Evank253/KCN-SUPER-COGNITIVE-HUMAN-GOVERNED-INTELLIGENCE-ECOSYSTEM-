"""Experiment logs."""

class ExperimentLogs:
    def __init__(self) -> None:
        self.logs: list[dict] = []
    def log(self, event: str, payload: dict) -> dict:
        item = {"event": event, "payload": payload}
        self.logs.append(item)
        return item
