"""Audit dashboard."""

class AuditDashboard:
    def build(self, *, provenance_records: int, approvals: int, risks: int) -> dict:
        return {"provenance_records": provenance_records, "approvals": approvals, "risks": risks, "status": "ATTENTION" if risks else "OK"}
