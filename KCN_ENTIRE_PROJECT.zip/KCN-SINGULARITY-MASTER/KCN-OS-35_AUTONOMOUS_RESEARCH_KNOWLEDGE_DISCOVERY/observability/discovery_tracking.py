"""Discovery tracking."""
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class DiscoveryTrackRecord:
    title: str
    status: str
    discovery_id: str = field(default_factory=lambda: f"KCN-DISCOVERY-TRACK-{uuid4().hex[:12].upper()}")

class DiscoveryTracking:
    def record(self, *, title: str, status: str) -> DiscoveryTrackRecord:
        return DiscoveryTrackRecord(title=title, status=status)
