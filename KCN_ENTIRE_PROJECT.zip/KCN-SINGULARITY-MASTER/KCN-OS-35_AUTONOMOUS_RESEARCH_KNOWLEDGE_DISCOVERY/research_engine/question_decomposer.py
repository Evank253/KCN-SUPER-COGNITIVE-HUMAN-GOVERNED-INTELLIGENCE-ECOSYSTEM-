"""Research question decomposition."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List
from uuid import uuid4


@dataclass(frozen=True)
class ResearchQuestion:
    question: str
    subquestions: List[str]
    question_id: str = field(default_factory=lambda: f"KCN-RQ-{uuid4().hex[:12].upper()}")


class QuestionDecomposer:
    def decompose(self, question: str) -> ResearchQuestion:
        cleaned = question.strip().rstrip("?")
        subquestions = [
            f"What is already known about {cleaned}?",
            f"What evidence supports or contradicts {cleaned}?",
            f"What mechanisms could explain {cleaned}?",
            f"What experiment or simulation could test {cleaned}?",
        ]
        return ResearchQuestion(question=question, subquestions=subquestions)
