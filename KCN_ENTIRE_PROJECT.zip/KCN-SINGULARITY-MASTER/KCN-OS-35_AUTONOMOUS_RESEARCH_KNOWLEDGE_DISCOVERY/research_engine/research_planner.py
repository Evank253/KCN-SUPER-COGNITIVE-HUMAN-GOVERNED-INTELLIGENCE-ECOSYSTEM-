"""Research planning."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List
from uuid import uuid4

from .question_decomposer import ResearchQuestion


@dataclass(frozen=True)
class ResearchPlanStep:
    name: str
    capability: str
    requires_review: bool = False


@dataclass(frozen=True)
class ResearchPlan:
    question_id: str
    objective: str
    steps: List[ResearchPlanStep]
    plan_id: str = field(default_factory=lambda: f"KCN-RESEARCH-PLAN-{uuid4().hex[:12].upper()}")


class ResearchPlanner:
    def create_plan(self, research_question: ResearchQuestion) -> ResearchPlan:
        steps = [
            ResearchPlanStep("Collect sources", "source_collection"),
            ResearchPlanStep("Analyze documents", "document_analysis"),
            ResearchPlanStep("Validate evidence", "evidence_validation"),
            ResearchPlanStep("Synthesize knowledge", "knowledge_synthesis"),
            ResearchPlanStep("Generate hypotheses", "hypothesis_generation", requires_review=True),
            ResearchPlanStep("Design experiment", "experiment_design", requires_review=True),
            ResearchPlanStep("Expert review", "expert_review", requires_review=True),
        ]
        return ResearchPlan(question_id=research_question.question_id, objective=research_question.question, steps=steps)
