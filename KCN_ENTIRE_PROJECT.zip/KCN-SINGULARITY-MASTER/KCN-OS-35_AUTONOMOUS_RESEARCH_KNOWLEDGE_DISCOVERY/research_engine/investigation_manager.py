"""Investigation management."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class InvestigationRecord:
    plan_id: str
    status: str
    completed_steps: List[str]
    investigation_id: str = field(default_factory=lambda: f"KCN-INVESTIGATION-{uuid4().hex[:12].upper()}")


class InvestigationManager:
    def __init__(self) -> None:
        self._records: Dict[str, InvestigationRecord] = {}

    def start(self, plan_id: str) -> InvestigationRecord:
        record = InvestigationRecord(plan_id=plan_id, status="RUNNING", completed_steps=[])
        self._records[record.investigation_id] = record
        return record

    def complete_step(self, investigation_id: str, step_name: str) -> InvestigationRecord:
        record = self._records[investigation_id]
        steps = list(record.completed_steps)
        if step_name not in steps:
            steps.append(step_name)
        updated = InvestigationRecord(**{**record.__dict__, "completed_steps": steps})
        self._records[investigation_id] = updated
        return updated

    def close(self, investigation_id: str) -> InvestigationRecord:
        record = self._records[investigation_id]
        updated = InvestigationRecord(**{**record.__dict__, "status": "COMPLETED"})
        self._records[investigation_id] = updated
        return updated
