"""Research orchestrator connecting question decomposition and planning."""

from __future__ import annotations

from dataclasses import dataclass

from .investigation_manager import InvestigationManager, InvestigationRecord
from .question_decomposer import QuestionDecomposer, ResearchQuestion
from .research_planner import ResearchPlan, ResearchPlanner


@dataclass(frozen=True)
class ResearchMission:
    question: ResearchQuestion
    plan: ResearchPlan
    investigation: InvestigationRecord


class ResearchOrchestrator:
    def __init__(self) -> None:
        self.decomposer = QuestionDecomposer()
        self.planner = ResearchPlanner()
        self.investigations = InvestigationManager()

    def create_mission(self, question: str) -> ResearchMission:
        rq = self.decomposer.decompose(question)
        plan = self.planner.create_plan(rq)
        investigation = self.investigations.start(plan.plan_id)
        return ResearchMission(question=rq, plan=plan, investigation=investigation)
