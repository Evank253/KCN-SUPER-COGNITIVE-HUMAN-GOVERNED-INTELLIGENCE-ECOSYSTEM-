"""Expert feedback."""
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class ExpertFeedbackRecord:
    reviewer: str
    decision: str
    notes: str
    feedback_id: str = field(default_factory=lambda: f"KCN-EXPERT-FEEDBACK-{uuid4().hex[:12].upper()}")

class ExpertFeedback:
    def record(self, *, reviewer: str, decision: str, notes: str) -> ExpertFeedbackRecord:
        if decision not in {"APPROVE", "REJECT", "REQUEST_CHANGES"}:
            raise ValueError("invalid expert decision")
        return ExpertFeedbackRecord(reviewer=reviewer, decision=decision, notes=notes)
