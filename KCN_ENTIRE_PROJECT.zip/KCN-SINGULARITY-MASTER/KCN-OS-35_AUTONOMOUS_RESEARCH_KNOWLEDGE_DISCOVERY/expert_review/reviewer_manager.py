"""Reviewer assignment."""

class ReviewerManager:
    def assign(self, *, domain: str, reviewers: dict[str, list[str]]) -> list[str]:
        return reviewers.get(domain, [])
