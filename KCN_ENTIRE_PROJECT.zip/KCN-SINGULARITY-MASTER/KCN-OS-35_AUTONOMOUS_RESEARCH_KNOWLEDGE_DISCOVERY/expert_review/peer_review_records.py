"""Peer review records."""
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class PeerReviewRecord:
    subject_id: str
    reviewer_count: int
    status: str
    review_id: str = field(default_factory=lambda: f"KCN-PEER-REVIEW-{uuid4().hex[:12].upper()}")
