"""Approval workflow."""

class ApprovalWorkflow:
    def approved(self, decisions: list[str]) -> bool:
        return bool(decisions) and all(decision == "APPROVE" for decision in decisions)
