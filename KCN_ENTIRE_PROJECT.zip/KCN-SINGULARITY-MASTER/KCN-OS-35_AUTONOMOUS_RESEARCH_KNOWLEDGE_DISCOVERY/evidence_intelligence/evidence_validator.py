"""Evidence validation."""

class EvidenceValidator:
    def validate(self, *, source_score: float, evidence_strength: float, reproducibility: float) -> dict:
        confidence = round(max(0.0, min(1.0, source_score * 0.35 + evidence_strength * 0.4 + reproducibility * 0.25)), 3)
        return {"confidence": confidence, "status": "SUPPORTED" if confidence >= 0.75 else "NEEDS_REVIEW"}
