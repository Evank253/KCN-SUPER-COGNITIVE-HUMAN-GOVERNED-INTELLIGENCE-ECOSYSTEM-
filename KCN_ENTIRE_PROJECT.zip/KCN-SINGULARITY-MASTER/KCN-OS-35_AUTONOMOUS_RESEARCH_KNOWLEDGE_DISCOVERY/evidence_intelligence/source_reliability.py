"""Source reliability scoring."""

class SourceReliability:
    def score(self, *, reputation: float, recency: float, citation_quality: float) -> float:
        return round(max(0.0, min(1.0, reputation * 0.45 + recency * 0.2 + citation_quality * 0.35)), 3)
