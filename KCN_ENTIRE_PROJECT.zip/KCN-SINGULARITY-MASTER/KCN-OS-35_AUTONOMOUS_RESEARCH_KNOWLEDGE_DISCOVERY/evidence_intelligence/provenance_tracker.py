"""Evidence provenance tracking."""
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class ProvenanceRecord:
    subject_id: str
    source_id: str
    action: str
    provenance_id: str = field(default_factory=lambda: f"KCN-RESEARCH-PROV-{uuid4().hex[:12].upper()}")

class ProvenanceTracker:
    def record(self, *, subject_id: str, source_id: str, action: str) -> ProvenanceRecord:
        return ProvenanceRecord(subject_id=subject_id, source_id=source_id, action=action)
