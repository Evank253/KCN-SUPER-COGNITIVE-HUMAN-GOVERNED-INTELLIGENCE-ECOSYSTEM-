"""Claim verification."""

class ClaimVerifier:
    def verify(self, *, supporting: int, contradicting: int) -> str:
        if supporting > contradicting and supporting >= 2:
            return "SUPPORTED"
        if contradicting > supporting:
            return "CONTRADICTED"
        return "INCONCLUSIVE"
