"""Knowledge synthesis."""

class KnowledgeSynthesizer:
    def synthesize(self, claims: list[str]) -> dict:
        return {"claim_count": len(claims), "summary": "; ".join(claims[:3]), "requires_review": len(claims) == 0}
