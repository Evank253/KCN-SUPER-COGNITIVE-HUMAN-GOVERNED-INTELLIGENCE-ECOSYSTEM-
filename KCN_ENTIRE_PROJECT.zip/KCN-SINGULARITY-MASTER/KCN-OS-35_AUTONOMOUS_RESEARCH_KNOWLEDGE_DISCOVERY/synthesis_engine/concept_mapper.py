"""Concept mapping."""

class ConceptMapper:
    def map_concepts(self, claims: list[str]) -> list[str]:
        concepts = set()
        for claim in claims:
            for word in claim.split():
                clean = word.strip('.,!?;:').lower()
                if len(clean) > 5:
                    concepts.add(clean)
        return sorted(concepts)
