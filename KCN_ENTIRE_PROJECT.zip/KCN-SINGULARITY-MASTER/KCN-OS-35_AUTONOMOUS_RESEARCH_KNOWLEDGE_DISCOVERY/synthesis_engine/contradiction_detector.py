"""Contradiction detection heuristic."""

class ContradictionDetector:
    def detect(self, claims: list[str]) -> list[tuple[str, str]]:
        contradictions = []
        lowered = [c.lower() for c in claims]
        for claim in lowered:
            if claim.startswith("not ") and claim[4:] in lowered:
                contradictions.append((claim, claim[4:]))
        return contradictions
