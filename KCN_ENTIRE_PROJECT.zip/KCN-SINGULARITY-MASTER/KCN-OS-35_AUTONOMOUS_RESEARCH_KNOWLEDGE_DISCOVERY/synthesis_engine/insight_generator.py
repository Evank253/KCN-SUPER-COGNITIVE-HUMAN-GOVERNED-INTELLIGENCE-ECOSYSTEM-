"""Insight generation."""

class InsightGenerator:
    def generate(self, *, concepts: list[str], contradictions: list[tuple[str, str]]) -> list[str]:
        insights = []
        if concepts:
            insights.append(f"Key concepts: {', '.join(concepts[:5])}")
        if contradictions:
            insights.append("Contradictions require expert review")
        return insights
