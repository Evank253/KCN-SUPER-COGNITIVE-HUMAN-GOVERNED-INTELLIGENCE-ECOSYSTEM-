"""Research risk classifier."""

class RiskClassifier:
    def classify(self, *, safety_risk: float, uncertainty: float) -> str:
        score = safety_risk * 0.7 + uncertainty * 0.3
        return "HIGH" if score >= 0.7 else "MEDIUM" if score >= 0.35 else "LOW"
