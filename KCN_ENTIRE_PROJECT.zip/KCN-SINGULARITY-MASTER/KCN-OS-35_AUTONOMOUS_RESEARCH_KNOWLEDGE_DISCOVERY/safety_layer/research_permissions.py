"""Research permission checks."""

class ResearchPermissions:
    def __init__(self) -> None:
        self.permissions: dict[str, set[str]] = {}
    def grant(self, subject: str, permission: str) -> None:
        self.permissions.setdefault(subject, set()).add(permission)
    def allowed(self, subject: str, permission: str) -> bool:
        return permission in self.permissions.get(subject, set()) or "*" in self.permissions.get(subject, set())
