"""Human override."""

class HumanOverride:
    def override(self, *, requested: bool, authority_verified: bool) -> dict:
        active = requested and authority_verified
        return {"override_active": active, "status": "STOPPED" if active else "UNCHANGED"}
