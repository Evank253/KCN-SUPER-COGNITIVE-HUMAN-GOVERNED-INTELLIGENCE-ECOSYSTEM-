"""Access control."""

class AccessControl:
    def can_access(self, *, identity_verified: bool, permission_allowed: bool) -> bool:
        return identity_verified and permission_allowed
