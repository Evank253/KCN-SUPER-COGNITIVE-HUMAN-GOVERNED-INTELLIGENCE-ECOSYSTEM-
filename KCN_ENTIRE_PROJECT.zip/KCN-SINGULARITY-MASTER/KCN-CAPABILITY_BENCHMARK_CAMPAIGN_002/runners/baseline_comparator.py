"""Baseline comparison for Campaign 002."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class BaselineComparison:
    probe_id: str
    score: float
    human_median_delta: float | None
    human_expert_delta: float | None
    external_ai_delta: float | None
    labels: list[str]


class BaselineComparator:
    def compare(self, *, result: dict, human_baseline: dict | None, external_baseline: dict | None) -> BaselineComparison:
        score = float(result.get("score", 0.0))
        labels: list[str] = []
        human_median_delta = None
        human_expert_delta = None
        external_ai_delta = None
        if human_baseline:
            human_median_delta = round(score - float(human_baseline.get("human_median_score", 0.0)), 4)
            human_expert_delta = round(score - float(human_baseline.get("human_expert_score", 0.0)), 4)
            labels.append("meets_human_median" if human_median_delta >= 0 else "below_human_median")
            labels.append("meets_human_expert" if human_expert_delta >= 0 else "below_human_expert")
        if external_baseline:
            external_ai_delta = round(score - float(external_baseline.get("score", 0.0)), 4)
            labels.append("exceeds_external_ai" if external_ai_delta > 0 else "below_or_equal_external_ai")
        return BaselineComparison(
            probe_id=result["probe_id"],
            score=score,
            human_median_delta=human_median_delta,
            human_expert_delta=human_expert_delta,
            external_ai_delta=external_ai_delta,
            labels=labels,
        )
