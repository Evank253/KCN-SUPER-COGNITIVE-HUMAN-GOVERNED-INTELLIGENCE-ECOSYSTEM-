"""Blind task loading and benchmark artifact hashing."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


def sha256_json(payload: Any) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()
    return "sha256:" + hashlib.sha256(raw).hexdigest()


class BlindTaskLoader:
    def load_candidate_packet(self, path: Path) -> dict:
        packet = json.loads(path.read_text())
        return {
            "packet_id": packet["packet_id"],
            "version": packet["version"],
            "sealed": packet.get("sealed", False),
            "tasks": [
                {"probe_id": task["probe_id"], "prompt": task["prompt"], "input": task["input"]}
                for task in packet["tasks"]
            ],
        }

    def load_private_metadata(self, path: Path) -> dict:
        return json.loads(path.read_text())

    def file_hash(self, path: Path) -> str:
        return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()

    def object_hash(self, payload: Any) -> str:
        return sha256_json(payload)
