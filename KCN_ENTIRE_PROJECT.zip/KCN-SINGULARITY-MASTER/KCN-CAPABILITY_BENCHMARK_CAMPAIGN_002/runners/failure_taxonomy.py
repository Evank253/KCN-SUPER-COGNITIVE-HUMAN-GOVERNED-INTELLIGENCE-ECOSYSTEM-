"""Failure taxonomy for Campaign 002."""

from __future__ import annotations

from collections import Counter

FAILURE_CATEGORIES = {
    "reasoning",
    "planning",
    "tool_selection",
    "memory_retrieval",
    "evidence_citation",
    "governance_violation",
    "permission_failure",
    "simulation_error",
    "research_synthesis",
    "calibration_error",
    "unknown",
}


class FailureTaxonomy:
    def normalize(self, category: str | None) -> str:
        return category if category in FAILURE_CATEGORIES else "unknown"

    def summarize(self, cases: list[dict]) -> dict[str, int]:
        failures = [self.normalize(case.get("failure_category")) for case in cases if not case.get("passed", False)]
        return dict(Counter(failures))
