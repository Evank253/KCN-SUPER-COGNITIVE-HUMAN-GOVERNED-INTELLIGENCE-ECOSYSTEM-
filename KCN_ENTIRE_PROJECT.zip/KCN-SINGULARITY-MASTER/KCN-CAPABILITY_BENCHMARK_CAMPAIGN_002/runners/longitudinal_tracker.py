"""Longitudinal tracking for benchmark campaigns."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class LongitudinalComparison:
    current_score: float
    previous_score: float | None
    delta: float | None
    regression: bool
    improved: bool


class LongitudinalTracker:
    def compare(self, *, current_score: float, previous_score: float | None, tolerance: float = 0.01) -> LongitudinalComparison:
        if previous_score is None:
            return LongitudinalComparison(current_score=current_score, previous_score=None, delta=None, regression=False, improved=False)
        delta = round(current_score - previous_score, 4)
        return LongitudinalComparison(
            current_score=current_score,
            previous_score=previous_score,
            delta=delta,
            regression=delta < -abs(tolerance),
            improved=delta > abs(tolerance),
        )
