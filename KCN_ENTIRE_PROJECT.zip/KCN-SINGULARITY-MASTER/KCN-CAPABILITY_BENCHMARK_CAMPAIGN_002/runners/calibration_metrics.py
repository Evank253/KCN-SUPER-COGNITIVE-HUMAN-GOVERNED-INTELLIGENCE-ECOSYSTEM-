"""Calibration metrics for Campaign 002."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CalibrationResult:
    total: int
    overconfidence_rate: float
    underconfidence_rate: float
    abstention_rate: float
    mean_absolute_calibration_error: float


class CalibrationMetrics:
    def evaluate(self, cases: list[dict], *, high_confidence_threshold: float = 0.75, correctness_threshold: float = 0.8) -> CalibrationResult:
        if not cases:
            return CalibrationResult(0, 0.0, 0.0, 0.0, 0.0)
        over = 0
        under = 0
        abstain = 0
        errors = []
        for case in cases:
            score = float(case.get("score", 0.0))
            confidence = float(case.get("confidence", 0.0))
            correct = score >= correctness_threshold
            high_conf = confidence >= high_confidence_threshold
            if high_conf and not correct:
                over += 1
            if (not high_conf) and correct:
                under += 1
            if case.get("abstained", False):
                abstain += 1
            errors.append(abs(confidence - score))
        total = len(cases)
        return CalibrationResult(
            total=total,
            overconfidence_rate=round(over / total, 4),
            underconfidence_rate=round(under / total, 4),
            abstention_rate=round(abstain / total, 4),
            mean_absolute_calibration_error=round(sum(errors) / total, 4),
        )
