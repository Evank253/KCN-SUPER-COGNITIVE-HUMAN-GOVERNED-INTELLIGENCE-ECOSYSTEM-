from __future__ import annotations

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class TestReproducibility(unittest.TestCase):
    def test_reproducibility_manifest_and_reports_exist(self) -> None:
        manifest = json.loads((ROOT / "evidence" / "reproducibility_manifest.json").read_text())
        self.assertEqual(manifest["campaign_id"], "KCN-CAPABILITY-CAMPAIGN-002")
        self.assertEqual(manifest["random_seed"], 20260731)
        self.assertTrue(manifest["result_hash"].startswith("sha256:"))
        for name in ["capability_report.md", "blind_score_report.md", "baseline_comparison_report.md", "calibration_report.md", "longitudinal_report.md"]:
            self.assertTrue((ROOT / "reports" / name).exists())


if __name__ == "__main__":
    unittest.main()
