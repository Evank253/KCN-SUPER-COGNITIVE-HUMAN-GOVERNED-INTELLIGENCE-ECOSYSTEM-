from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runners"))
from blind_task_loader import BlindTaskLoader


class TestBlindLoader(unittest.TestCase):
    def test_loader_returns_only_candidate_visible_fields(self) -> None:
        packet = BlindTaskLoader().load_candidate_packet(ROOT / "task_sets" / "sealed_hidden_tasks.json")
        self.assertEqual(len(packet["tasks"]), 5)
        for task in packet["tasks"]:
            self.assertEqual(set(task), {"probe_id", "prompt", "input"})


if __name__ == "__main__":
    unittest.main()
