from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runners"))
from baseline_comparator import BaselineComparator
from longitudinal_tracker import LongitudinalTracker


class TestBaselineComparator(unittest.TestCase):
    def test_baseline_and_longitudinal_comparison(self) -> None:
        comparison = BaselineComparator().compare(
            result={"probe_id": "p1", "score": 0.9},
            human_baseline={"human_median_score": 0.7, "human_expert_score": 0.95},
            external_baseline={"score": 0.85},
        )
        self.assertIn("meets_human_median", comparison.labels)
        self.assertIn("below_human_expert", comparison.labels)
        self.assertIn("exceeds_external_ai", comparison.labels)
        trend = LongitudinalTracker().compare(current_score=0.91, previous_score=0.86)
        self.assertTrue(trend.improved)


if __name__ == "__main__":
    unittest.main()
