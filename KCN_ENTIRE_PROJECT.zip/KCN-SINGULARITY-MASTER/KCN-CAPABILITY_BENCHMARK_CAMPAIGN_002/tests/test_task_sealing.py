from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

sys.path.insert(0, str(ROOT / "runners"))
from blind_task_loader import BlindTaskLoader


class TestTaskSealing(unittest.TestCase):
    def test_candidate_packet_hides_private_metadata_and_hashes_exist(self) -> None:
        loader = BlindTaskLoader()
        candidate = loader.load_candidate_packet(ROOT / "task_sets" / "sealed_hidden_tasks.json")
        self.assertTrue(candidate["sealed"])
        for task in candidate["tasks"]:
            self.assertIn("probe_id", task)
            self.assertNotIn("domain", task)
            self.assertNotIn("expected", task)
            self.assertNotIn("scoring_weights", task)
        subprocess.run([sys.executable, "runners/run_campaign_002.py"], cwd=ROOT, check=True, capture_output=True, text=True)
        registry = json.loads((ROOT / "benchmark_registry" / "task_hash_registry.json").read_text())
        self.assertTrue(registry["sealed_hidden_tasks.json"].startswith("sha256:"))
        self.assertTrue(registry["task_metadata_private.example.json"].startswith("sha256:"))


if __name__ == "__main__":
    unittest.main()
