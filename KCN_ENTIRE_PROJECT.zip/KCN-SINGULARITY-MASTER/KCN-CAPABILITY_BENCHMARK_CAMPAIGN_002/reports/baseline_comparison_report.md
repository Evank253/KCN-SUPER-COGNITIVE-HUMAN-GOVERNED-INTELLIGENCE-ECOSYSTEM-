# Baseline Comparison Report

These baselines are example placeholders, not real human/external AI data.

| Probe | Score | Human Median Δ | Human Expert Δ | External AI Δ | Labels |
|---|---:|---:|---:|---:|---|
| `BLIND-002-001` | 1.000 | 0.3 | 0.1 | 0.18 | meets_human_median, meets_human_expert, exceeds_external_ai |
| `BLIND-002-002` | 1.000 | 0.32 | 0.12 | 0.2 | meets_human_median, meets_human_expert, exceeds_external_ai |
| `BLIND-002-003` | 1.000 | 0.28 | 0.09 | 0.22 | meets_human_median, meets_human_expert, exceeds_external_ai |
| `BLIND-002-004` | 1.000 | 0.34 | 0.13 | 0.24 | meets_human_median, meets_human_expert, exceeds_external_ai |
| `BLIND-002-005` | 1.000 | 0.2 | 0.05 | 0.14 | meets_human_median, meets_human_expert, exceeds_external_ai |
