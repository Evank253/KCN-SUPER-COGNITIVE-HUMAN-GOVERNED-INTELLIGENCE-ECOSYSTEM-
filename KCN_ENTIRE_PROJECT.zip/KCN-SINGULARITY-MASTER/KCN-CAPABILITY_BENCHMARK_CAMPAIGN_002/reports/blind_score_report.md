# Blind Score Report

| Probe | Domain | Score | Confidence | Passed |
|---|---|---:|---:|---|
| `BLIND-002-001` | runtime | 1.000 | 1.000 | True |
| `BLIND-002-002` | reasoning_planning | 1.000 | 0.940 | True |
| `BLIND-002-003` | research | 1.000 | 0.820 | True |
| `BLIND-002-004` | simulation | 1.000 | 0.900 | True |
| `BLIND-002-005` | governance | 1.000 | 0.980 | True |
