# Calibration Report

```json
{
  "total": 5,
  "overconfidence_rate": 0.0,
  "underconfidence_rate": 0.0,
  "abstention_rate": 0.0,
  "mean_absolute_calibration_error": 0.072
}
```
