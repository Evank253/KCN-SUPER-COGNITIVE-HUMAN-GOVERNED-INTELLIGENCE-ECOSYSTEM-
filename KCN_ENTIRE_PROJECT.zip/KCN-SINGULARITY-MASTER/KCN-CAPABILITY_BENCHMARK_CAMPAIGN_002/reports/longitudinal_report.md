# Longitudinal Tracking Report

Compared Campaign 002 to previous internal Campaign 001 score placeholder of `1.0`.

```json
{
  "current_score": 1.0,
  "previous_score": 1.0,
  "delta": 0.0,
  "regression": false,
  "improved": false
}
```
