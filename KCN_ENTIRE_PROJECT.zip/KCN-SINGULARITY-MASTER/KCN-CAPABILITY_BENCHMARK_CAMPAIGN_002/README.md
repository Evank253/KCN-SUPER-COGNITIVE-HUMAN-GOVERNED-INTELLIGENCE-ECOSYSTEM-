# KCN Capability Benchmark Campaign 002

Campaign 002 strengthens KCN's evidence program by adding blind evaluation, baseline-comparison infrastructure, benchmark governance, calibration metrics, failure taxonomy, and longitudinal tracking.

## Purpose

Move from internal scaffold validation toward more credible capability evaluation:

```text
Frozen Benchmark Artifacts
  ↓
Sealed Hidden Tasks
  ↓
Blind Runtime Execution
  ↓
Calibration + Failure Analysis
  ↓
Human / External AI Baseline Comparison
  ↓
Evidence Package
  ↓
Longitudinal Tracking
```

## What Campaign 002 Can Support

- The benchmark artifacts are versioned and hash-tracked.
- Blind task packets can be loaded without exposing private metadata to the candidate system.
- Scores can be compared to human and external AI baselines.
- Confidence calibration is measured.
- Failures are classified into actionable categories.
- Results can be tracked against prior campaign releases.

## What Campaign 002 Does Not Support

Campaign 002 does **not** prove AGI or ASI. It is still not an independent scientific validation. It creates the infrastructure needed for stronger evidence.

## Run Campaign

```bash
cd KCN-SINGULARITY-MASTER/KCN-CAPABILITY_BENCHMARK_CAMPAIGN_002
python runners/run_campaign_002.py
```

## Run Tests

```bash
python -m unittest discover -s tests -v
```
