# Blind Evaluation Protocol

## Candidate Visibility

The candidate runtime receives only:

- probe ID
- generic prompt
- structured input payload

The candidate does not receive:

- domain label
- scoring weights
- expected answer
- human baseline values
- external AI baseline values
- private task metadata

## Evaluator Visibility

The evaluator can access private task metadata and answer keys after the candidate returns outputs.

## Sealing

The task packet and private metadata are hash-registered before the run. Any changes alter the benchmark hashes.
