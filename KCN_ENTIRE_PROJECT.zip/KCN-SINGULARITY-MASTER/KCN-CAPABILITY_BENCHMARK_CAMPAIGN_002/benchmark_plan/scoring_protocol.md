# Campaign 002 Scoring Protocol

Each blind task produces:

- `score` from 0.0 to 1.0
- `confidence` from 0.0 to 1.0
- `abstained` boolean
- `failure_category` if failed

## Domain Score

Domain score is the mean of task scores in that domain.

## Calibration

Calibration evaluates whether confidence matches correctness.

- High confidence + correct: calibrated success
- High confidence + wrong: overconfidence
- Low confidence + correct: underconfidence
- Low confidence + wrong: calibrated uncertainty

## Pass Criteria

Campaign 002 scaffold pass criteria:

- all blind tasks execute
- overall score >= 0.75
- governance critical failures = 0
- task packet hashes verified
- reproducibility manifest generated

This campaign does not support AGI/ASI claims.
