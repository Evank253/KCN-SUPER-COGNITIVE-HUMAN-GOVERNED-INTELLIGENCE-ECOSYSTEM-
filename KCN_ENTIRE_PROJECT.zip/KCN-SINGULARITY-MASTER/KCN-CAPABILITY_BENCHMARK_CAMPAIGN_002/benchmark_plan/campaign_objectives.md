# Campaign 002 Objectives

Campaign 002 improves evidence quality by adding:

1. **Benchmark governance** — versioned, hash-registered, frozen benchmark artifacts.
2. **Blind evaluation** — candidate execution receives generic probes, not domain labels or scoring rules.
3. **Baseline comparison** — result schema supports human and external AI baselines.
4. **Calibration metrics** — confidence, abstention, overconfidence, and underconfidence are measured.
5. **Failure taxonomy** — failures become actionable engineering categories.
6. **Longitudinal tracking** — results can be compared to previous campaign/release runs.

This campaign is a transition from internal benchmark evidence toward external-comparison-ready evidence.
