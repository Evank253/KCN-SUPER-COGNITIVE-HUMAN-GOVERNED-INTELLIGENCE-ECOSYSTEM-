# Reproducibility Protocol

A reproducible campaign run must record:

- run ID
- campaign version
- benchmark catalog hash
- task packet hash
- private metadata hash
- scoring registry hash
- runtime version
- Python version
- random seed
- configuration
- command used to reproduce the run
- result hashes

Campaign 002 is designed so another evaluator can run the same command against the same frozen artifacts and compare result hashes.
