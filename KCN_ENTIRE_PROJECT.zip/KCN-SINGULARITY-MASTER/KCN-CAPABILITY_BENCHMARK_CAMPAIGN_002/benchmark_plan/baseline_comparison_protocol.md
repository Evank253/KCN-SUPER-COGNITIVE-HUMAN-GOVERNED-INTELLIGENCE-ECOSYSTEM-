# Baseline Comparison Protocol

Campaign 002 supports baseline comparison but uses example baseline records until real human and external AI evaluations are collected.

Baseline types:

- human median
- human expert
- external AI baseline
- previous KCN release

Scores are normalized between 0 and 1.

A result can be marked as:

- below baseline
- meets median baseline
- meets expert baseline
- exceeds external AI baseline

These labels are evidence descriptors, not AGI/ASI claims.
