"""Runtime scheduler."""

from reasoning_core import RuntimePlan

class RuntimeScheduler:
    def ordered_steps(self, plan: RuntimePlan):
        return list(plan.steps)
