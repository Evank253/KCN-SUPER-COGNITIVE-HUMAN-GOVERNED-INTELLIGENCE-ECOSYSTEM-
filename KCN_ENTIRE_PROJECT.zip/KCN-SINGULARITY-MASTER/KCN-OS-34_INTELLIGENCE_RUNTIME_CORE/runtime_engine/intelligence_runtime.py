"""Integrated intelligence runtime core."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List
from uuid import uuid4

from reasoning_core import PlanningEngine, ReasoningEngine
from runtime_engine.execution_manager import ExecutionManager
from runtime_engine.state_controller import StateController
from safety_layer import HumanApproval
from verification_layer import ConfidenceEngine, OutputValidator, ReasoningAudit


@dataclass(frozen=True)
class RuntimeTask:
    intent: str
    subject: str
    capabilities: List[str]
    high_impact: List[str] = field(default_factory=list)
    task_id: str = field(default_factory=lambda: f"KCN-RUNTIME-TASK-{uuid4().hex[:12].upper()}")


@dataclass(frozen=True)
class RuntimeResult:
    task_id: str
    status: str
    outputs: List[dict]
    confidence: float
    audit_id: str


class IntelligenceRuntime:
    def __init__(self, execution_manager: ExecutionManager) -> None:
        self.reasoning = ReasoningEngine()
        self.planning = PlanningEngine()
        self.execution_manager = execution_manager
        self.state = StateController()
        self.validator = OutputValidator()
        self.confidence = ConfidenceEngine()
        self.audit = ReasoningAudit()
        self.approvals = HumanApproval()

    def run(self, task: RuntimeTask, *, auto_approve: bool = False) -> RuntimeResult:
        self.state.transition("RUNNING")
        reasoning = self.reasoning.interpret(task.intent)
        plan = self.planning.create_plan(objective=reasoning.objective, capabilities=task.capabilities, high_impact=task.high_impact)
        outputs: List[dict] = []
        for step in plan.steps:
            if step.requires_approval:
                approval = self.approvals.request_and_record(action=step.capability, approver="runtime-operator", approved=auto_approve)
                if not approval.approved:
                    self.state.transition("BLOCKED")
                    audit = self.audit.record(objective=plan.objective, summary="blocked pending human approval")
                    return RuntimeResult(task_id=task.task_id, status="BLOCKED", outputs=outputs, confidence=0.0, audit_id=audit.audit_id)
            result = self.execution_manager.execute_step(subject=task.subject, capability=step.capability, payload={"task_id": task.task_id, "objective": plan.objective})
            outputs.append(result)
            if not result.get("accepted"):
                self.state.transition("FAILED")
                audit = self.audit.record(objective=plan.objective, summary=f"execution failed for {step.capability}")
                return RuntimeResult(task_id=task.task_id, status="FAILED", outputs=outputs, confidence=0.0, audit_id=audit.audit_id)
        valid = all(output.get("accepted") and self.validator.validate(output.get("execution", {})) for output in outputs)
        score = self.confidence.score(evidence_score=1.0 if valid else 0.0, consistency_score=1.0, tool_success=valid)
        self.state.transition("VERIFIED" if valid else "FAILED")
        audit = self.audit.record(objective=plan.objective, summary="runtime execution completed" if valid else "runtime verification failed")
        return RuntimeResult(task_id=task.task_id, status=self.state.state, outputs=outputs, confidence=score, audit_id=audit.audit_id)
