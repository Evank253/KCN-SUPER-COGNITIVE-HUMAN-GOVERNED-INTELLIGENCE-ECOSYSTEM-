"""Runtime state controller."""

class StateController:
    VALID = {"CREATED", "PLANNED", "RUNNING", "VERIFIED", "BLOCKED", "FAILED"}
    def __init__(self) -> None:
        self.state = "CREATED"
    def transition(self, state: str) -> str:
        if state not in self.VALID:
            raise ValueError(f"invalid runtime state: {state}")
        self.state = state
        return self.state
