"""Execution manager that runs planned capabilities through approved tools."""

from tool_orchestration import CapabilityRouter, ToolExecutor
from safety_layer import EmergencyControl, PermissionManager

class ExecutionManager:
    def __init__(self, *, router: CapabilityRouter, permissions: PermissionManager, emergency: EmergencyControl | None = None) -> None:
        self.router = router
        self.permissions = permissions
        self.emergency = emergency or EmergencyControl()
        self.executor = ToolExecutor()
    def execute_step(self, *, subject: str, capability: str, payload: dict) -> dict:
        if not self.emergency.can_execute():
            return {"accepted": False, "error": "emergency stop active"}
        if not self.permissions.allowed(subject, capability):
            return {"accepted": False, "error": "permission denied"}
        tool = self.router.route(capability)
        return {"accepted": True, "execution": self.executor.execute(tool, payload)}
