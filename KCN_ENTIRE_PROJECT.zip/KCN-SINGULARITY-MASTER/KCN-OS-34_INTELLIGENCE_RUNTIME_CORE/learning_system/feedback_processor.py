"""Feedback processor."""

class FeedbackProcessor:
    def summarize(self, feedback: list[dict]) -> dict:
        if not feedback:
            return {"count": 0, "average_rating": 0.0}
        avg = sum(item.get("rating", 0.0) for item in feedback) / len(feedback)
        return {"count": len(feedback), "average_rating": round(avg, 3)}
