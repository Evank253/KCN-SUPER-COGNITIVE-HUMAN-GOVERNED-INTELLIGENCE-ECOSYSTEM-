"""Runtime performance tracker."""

class PerformanceTracker:
    def pass_rate(self, *, passed: int, total: int) -> float:
        return round(passed / total, 4) if total else 0.0
    def regression(self, *, previous: float, current: float, tolerance: float = 0.05) -> bool:
        return current < previous - tolerance
