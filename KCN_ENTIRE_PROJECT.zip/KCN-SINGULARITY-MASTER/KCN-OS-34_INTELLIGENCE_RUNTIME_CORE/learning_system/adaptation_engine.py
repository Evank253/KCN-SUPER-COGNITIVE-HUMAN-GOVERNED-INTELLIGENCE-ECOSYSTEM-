"""Runtime adaptation preference engine."""

class AdaptationEngine:
    def adapt_priority(self, *, current_priority: int, feedback_score: float) -> int:
        if feedback_score > 0.8:
            return min(10, current_priority + 1)
        if feedback_score < 0.4:
            return max(1, current_priority - 1)
        return current_priority
