"""Controlled improvement proposal loop."""

from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class ImprovementProposal:
    issue: str
    proposed_change: str
    requires_approval: bool = True
    proposal_id: str = field(default_factory=lambda: f"KCN-RUNTIME-IMPROVE-{uuid4().hex[:12].upper()}")

class ImprovementLoop:
    def propose(self, *, issue: str, proposed_change: str) -> ImprovementProposal:
        return ImprovementProposal(issue=issue, proposed_change=proposed_change)
