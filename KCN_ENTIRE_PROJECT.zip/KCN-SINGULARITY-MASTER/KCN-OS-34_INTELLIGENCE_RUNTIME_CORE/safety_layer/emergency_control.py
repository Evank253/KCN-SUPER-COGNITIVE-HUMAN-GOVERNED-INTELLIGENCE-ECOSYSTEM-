"""Emergency runtime control."""

class EmergencyControl:
    def __init__(self) -> None:
        self.stopped = False
    def stop(self, reason: str) -> dict:
        self.stopped = True
        return {"stopped": True, "reason": reason}
    def can_execute(self) -> bool:
        return not self.stopped
