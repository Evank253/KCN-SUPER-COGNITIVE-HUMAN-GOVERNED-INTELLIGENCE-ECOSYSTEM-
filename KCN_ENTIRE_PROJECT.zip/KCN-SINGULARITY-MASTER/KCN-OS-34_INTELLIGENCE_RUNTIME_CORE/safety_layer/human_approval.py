"""Human approval manager."""

from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class Approval:
    action: str
    approved: bool
    approver: str
    approval_id: str = field(default_factory=lambda: f"KCN-RUNTIME-APPROVAL-{uuid4().hex[:12].upper()}")

class HumanApproval:
    def request_and_record(self, *, action: str, approver: str, approved: bool) -> Approval:
        return Approval(action=action, approved=approved, approver=approver)
