"""Permission manager for runtime actions."""

class PermissionManager:
    def __init__(self) -> None:
        self._permissions: dict[str, set[str]] = {}
    def grant(self, subject: str, permission: str) -> None:
        self._permissions.setdefault(subject, set()).add(permission)
    def allowed(self, subject: str, permission: str) -> bool:
        perms = self._permissions.get(subject, set())
        return permission in perms or "*" in perms
