"""Action limit checks."""

class ActionLimits:
    def within_limits(self, *, risk_score: float, max_risk: float = 0.5) -> bool:
        return risk_score <= max_risk
