from .base_connector import BaseConnector
class Phase43SecurityConnector(BaseConnector):
    def __init__(self, handler=None) -> None:
        super().__init__("Phase43SecurityConnector", handler)
