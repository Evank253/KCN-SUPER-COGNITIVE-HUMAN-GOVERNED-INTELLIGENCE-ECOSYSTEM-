from .base_connector import BaseConnector
class Phase44TrustConnector(BaseConnector):
    def __init__(self, handler=None) -> None:
        super().__init__("Phase44TrustConnector", handler)
