from .base_connector import BaseConnector
class Phase42CollaborationConnector(BaseConnector):
    def __init__(self, handler=None) -> None:
        super().__init__("Phase42CollaborationConnector", handler)
