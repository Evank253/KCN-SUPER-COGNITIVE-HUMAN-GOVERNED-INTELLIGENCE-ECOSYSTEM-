from .base_connector import BaseConnector
class Phase32ValidationConnector(BaseConnector):
    def __init__(self, handler=None) -> None:
        super().__init__("Phase32ValidationConnector", handler)
