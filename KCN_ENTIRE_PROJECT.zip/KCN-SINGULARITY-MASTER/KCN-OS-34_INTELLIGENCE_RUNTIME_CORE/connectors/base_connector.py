"""Base connector for runtime integrations."""
from dataclasses import dataclass, field
from typing import Callable
from uuid import uuid4
@dataclass(frozen=True)
class ConnectorResult:
    connector: str
    operation: str
    accepted: bool
    payload: dict
    result_id: str = field(default_factory=lambda: f"KCN-RUNTIME-CONN-{uuid4().hex[:12].upper()}")
class BaseConnector:
    def __init__(self, name: str, handler: Callable[[str, dict], dict] | None = None) -> None:
        self.name=name; self.handler=handler
    def send(self, operation: str, payload: dict) -> ConnectorResult:
        if not self.handler:
            return ConnectorResult(self.name, operation, False, {"error":"no handler configured"})
        return ConnectorResult(self.name, operation, True, self.handler(operation, payload))
