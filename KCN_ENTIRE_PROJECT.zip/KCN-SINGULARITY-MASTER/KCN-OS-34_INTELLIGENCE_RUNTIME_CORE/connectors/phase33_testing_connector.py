from .base_connector import BaseConnector
class Phase33TestingConnector(BaseConnector):
    def __init__(self, handler=None) -> None:
        super().__init__("Phase33TestingConnector", handler)
