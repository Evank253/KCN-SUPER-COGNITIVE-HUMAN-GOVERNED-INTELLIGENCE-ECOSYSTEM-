from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))

from runtime_engine import ExecutionManager, IntelligenceRuntime, RuntimeTask
from safety_layer import PermissionManager
from tool_orchestration import CapabilityRouter, ToolRegistry

class TestRuntime(unittest.TestCase):
    def _runtime(self):
        registry = ToolRegistry()
        registry.register(name="research-tool", capability="research", run=lambda payload: {"result": "researched", "payload": payload})
        registry.register(name="build-tool", capability="build", run=lambda payload: {"result": "built", "payload": payload})
        permissions = PermissionManager()
        permissions.grant("user-1", "research")
        permissions.grant("user-1", "build")
        manager = ExecutionManager(router=CapabilityRouter(registry), permissions=permissions)
        return IntelligenceRuntime(manager)

    def test_runtime_executes_verified_flow(self):
        runtime = self._runtime()
        task = RuntimeTask(intent="Create a verified prototype", subject="user-1", capabilities=["research", "build"], high_impact=["build"])
        result = runtime.run(task, auto_approve=True)
        self.assertEqual(result.status, "VERIFIED")
        self.assertEqual(len(result.outputs), 2)
        self.assertEqual(result.confidence, 1.0)

    def test_runtime_blocks_unapproved_high_impact(self):
        runtime = self._runtime()
        task = RuntimeTask(intent="Create a verified prototype", subject="user-1", capabilities=["build"], high_impact=["build"])
        result = runtime.run(task, auto_approve=False)
        self.assertEqual(result.status, "BLOCKED")

if __name__ == "__main__": unittest.main()
