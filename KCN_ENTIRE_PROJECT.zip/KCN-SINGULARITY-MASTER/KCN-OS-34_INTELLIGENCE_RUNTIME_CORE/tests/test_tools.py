from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))

from agent_coordination import AgentRuntime, CollaborationManager, RuntimeAgent, SwarmInterface
from connectors import Phase32ValidationConnector
from reasoning_core import DecisionOption, DecisionSupport, InferenceManager, PlanningEngine, ReasoningEngine
from tool_orchestration import APIManager, CapabilityRouter, ToolExecutor, ToolRegistry

class TestTools(unittest.TestCase):
    def test_reasoning_tools_agents_and_connector(self):
        reasoning = ReasoningEngine().interpret("Design a safe robot.")
        self.assertEqual(reasoning.objective, "Design a safe robot")
        plan = PlanningEngine().create_plan(objective=reasoning.objective, capabilities=["research"], high_impact=[])
        self.assertEqual(plan.steps[0].capability, "research")
        flags = InferenceManager().infer_flags({"high_impact": True, "human_approved": False})
        self.assertIn("approval_required", flags)
        best = DecisionSupport().rank([DecisionOption("a", .8, .2), DecisionOption("b", .9, .5)])[0]
        self.assertEqual(best.name, "a")

        registry = ToolRegistry()
        tool = registry.register(name="calc", capability="calculate", run=lambda payload: {"value": payload["x"] + 1})
        routed = CapabilityRouter(registry).route("calculate")
        self.assertEqual(routed.tool_id, tool.tool_id)
        executed = ToolExecutor().execute(routed, {"x": 1})
        self.assertEqual(executed["result"]["value"], 2)
        api = APIManager(); api.register_adapter("echo", lambda payload: payload)
        self.assertTrue(api.call("echo", {"ok": True})["accepted"])

        agent = RuntimeAgent(name="ResearchAgent", capability="research", run=lambda payload: {"done": True})
        self.assertTrue(AgentRuntime().execute(agent, {})["result"]["done"])
        self.assertEqual(len(SwarmInterface().form_swarm([agent], ["research"])), 1)
        self.assertTrue(CollaborationManager().aggregate([{"a": 1}])["verified"])

        connector = Phase32ValidationConnector(handler=lambda op, payload: {"op": op, "payload": payload})
        self.assertTrue(connector.send("validate", {"score": 1}).accepted)

if __name__ == "__main__": unittest.main()
