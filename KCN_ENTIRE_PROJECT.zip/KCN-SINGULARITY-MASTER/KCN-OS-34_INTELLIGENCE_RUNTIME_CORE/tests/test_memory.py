from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))

from memory_system import ContextManager, LongTermMemory, MemoryRetrieval, WorkingMemory

class TestMemory(unittest.TestCase):
    def test_memory_layers(self):
        wm = WorkingMemory(); wm.set("objective", "build robot")
        self.assertEqual(wm.get("objective"), "build robot")
        ctx = ContextManager(); ctx.update(user="u1", project="robot")
        self.assertEqual(ctx.current()["project"], "robot")
        ltm = LongTermMemory()
        rec1 = ltm.remember(scope="u1", content="robot project prefers safe design", owner="u1")
        rec2 = ltm.remember(scope="u1", content="gardening note", owner="u1")
        recalled = ltm.recall(scope="u1")
        ranked = MemoryRetrieval().rank(query="robot", records=recalled)
        self.assertEqual(ranked[0].record_id, rec1.record_id)
        self.assertEqual(len(recalled), 2)

if __name__ == "__main__": unittest.main()
