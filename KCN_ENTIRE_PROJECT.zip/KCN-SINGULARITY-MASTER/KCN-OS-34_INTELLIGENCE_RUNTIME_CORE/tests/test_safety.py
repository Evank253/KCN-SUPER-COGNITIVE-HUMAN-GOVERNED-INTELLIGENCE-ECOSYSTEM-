from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0, str(ROOT))

from learning_system import AdaptationEngine, FeedbackProcessor, ImprovementLoop, PerformanceTracker
from observability import BehaviorMonitor, ExecutionLogs, PerformanceDashboard, RuntimeMetrics
from safety_layer import ActionLimits, EmergencyControl, HumanApproval, PermissionManager
from verification_layer import ConfidenceEngine, EvidenceChecker, OutputValidator, ReasoningAudit

class TestSafety(unittest.TestCase):
    def test_safety_verification_learning_observability(self):
        perms = PermissionManager(); perms.grant("u1", "read")
        self.assertTrue(perms.allowed("u1", "read"))
        self.assertFalse(perms.allowed("u1", "write"))
        approval = HumanApproval().request_and_record(action="deploy", approver="operator", approved=True)
        self.assertTrue(approval.approved)
        self.assertTrue(ActionLimits().within_limits(risk_score=.2))
        emergency = EmergencyControl(); emergency.stop("test")
        self.assertFalse(emergency.can_execute())

        self.assertTrue(OutputValidator().validate({"result": "ok"}))
        self.assertEqual(ConfidenceEngine().score(evidence_score=1, consistency_score=1, tool_success=True), 1.0)
        self.assertTrue(EvidenceChecker().check(["sha256:abc", "artifact:1"]))
        audit = ReasoningAudit().record(objective="x", summary="ok")
        self.assertTrue(audit.audit_id.startswith("KCN-REASON-AUDIT-"))

        summary = FeedbackProcessor().summarize([{"rating": .8}, {"rating": 1.0}])
        self.assertEqual(summary["average_rating"], .9)
        proposal = ImprovementLoop().propose(issue="latency", proposed_change="cache retrieval")
        self.assertTrue(proposal.requires_approval)
        self.assertEqual(AdaptationEngine().adapt_priority(current_priority=5, feedback_score=.9), 6)
        self.assertTrue(PerformanceTracker().regression(previous=.9, current=.8))

        metrics = RuntimeMetrics(); metrics.record("latency", 1.2)
        self.assertEqual(metrics.metrics[0]["name"], "latency")
        logs = ExecutionLogs(); logs.log("started", {"task": 1})
        self.assertEqual(logs.logs[0]["event"], "started")
        self.assertEqual(BehaviorMonitor().flag(action="deploy", allowed=False), ["blocked:deploy"])
        self.assertEqual(PerformanceDashboard().build(pass_rate=1.0, avg_confidence=.95)["status"], "OK")

if __name__ == "__main__": unittest.main()
