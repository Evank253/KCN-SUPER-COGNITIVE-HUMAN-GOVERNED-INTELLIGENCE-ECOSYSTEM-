"""Decision support utilities."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class DecisionOption:
    name: str
    benefit: float
    risk: float


class DecisionSupport:
    def rank(self, options: List[DecisionOption]) -> List[DecisionOption]:
        return sorted(options, key=lambda option: (option.benefit - option.risk, option.benefit), reverse=True)
