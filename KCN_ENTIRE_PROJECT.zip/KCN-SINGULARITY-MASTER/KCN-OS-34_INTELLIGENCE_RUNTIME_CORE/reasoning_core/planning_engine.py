"""Planning engine for decomposing objectives."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List
from uuid import uuid4


@dataclass(frozen=True)
class PlanStep:
    name: str
    capability: str
    requires_approval: bool = False


@dataclass(frozen=True)
class RuntimePlan:
    objective: str
    steps: List[PlanStep]
    plan_id: str = field(default_factory=lambda: f"KCN-RUNTIME-PLAN-{uuid4().hex[:12].upper()}")


class PlanningEngine:
    def create_plan(self, *, objective: str, capabilities: List[str], high_impact: List[str] | None = None) -> RuntimePlan:
        high_impact_set = set(high_impact or [])
        steps = [PlanStep(name=capability.replace("_", " ").title(), capability=capability, requires_approval=capability in high_impact_set) for capability in capabilities]
        return RuntimePlan(objective=objective, steps=steps)
