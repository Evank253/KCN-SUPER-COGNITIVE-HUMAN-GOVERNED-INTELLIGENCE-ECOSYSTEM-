"""Reasoning engine for turning intent into structured understanding."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List
from uuid import uuid4


@dataclass(frozen=True)
class ReasoningSummary:
    intent: str
    objective: str
    assumptions: List[str]
    risks: List[str]
    summary_id: str = field(default_factory=lambda: f"KCN-REASON-{uuid4().hex[:12].upper()}")


class ReasoningEngine:
    def interpret(self, intent: str) -> ReasoningSummary:
        objective = intent.strip().rstrip(".")
        assumptions = ["human remains final authority", "high-impact actions require approval"]
        risks = [] if objective else ["empty objective"]
        return ReasoningSummary(intent=intent, objective=objective, assumptions=assumptions, risks=risks)
