"""Inference manager for simple rule-based conclusions."""

from __future__ import annotations

from typing import Dict, List


class InferenceManager:
    def infer_flags(self, facts: Dict[str, bool]) -> List[str]:
        flags = []
        if facts.get("high_impact") and not facts.get("human_approved"):
            flags.append("approval_required")
        if facts.get("missing_evidence"):
            flags.append("evidence_required")
        return flags
