"""Swarm interface."""

from .agent_runtime import RuntimeAgent

class SwarmInterface:
    def form_swarm(self, agents: list[RuntimeAgent], capabilities: list[str]) -> list[RuntimeAgent]:
        selected = []
        for capability in capabilities:
            for agent in agents:
                if agent.capability == capability and agent not in selected:
                    selected.append(agent)
                    break
        return selected
