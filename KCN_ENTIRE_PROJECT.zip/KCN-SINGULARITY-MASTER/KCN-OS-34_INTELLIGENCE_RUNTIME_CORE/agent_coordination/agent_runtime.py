"""Agent runtime."""

from dataclasses import dataclass, field
from typing import Callable
from uuid import uuid4

@dataclass(frozen=True)
class RuntimeAgent:
    name: str
    capability: str
    run: Callable[[dict], dict]
    agent_id: str = field(default_factory=lambda: f"KCN-RUNTIME-AGENT-{uuid4().hex[:12].upper()}")

class AgentRuntime:
    def execute(self, agent: RuntimeAgent, payload: dict) -> dict:
        return {"agent": agent.name, "result": agent.run(payload)}
