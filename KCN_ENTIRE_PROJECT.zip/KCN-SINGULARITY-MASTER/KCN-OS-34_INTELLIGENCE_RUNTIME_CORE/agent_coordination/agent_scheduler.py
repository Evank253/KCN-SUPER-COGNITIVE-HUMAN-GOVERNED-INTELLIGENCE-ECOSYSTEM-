"""Agent scheduler."""

from .agent_runtime import RuntimeAgent

class AgentScheduler:
    def select(self, agents: list[RuntimeAgent], capability: str) -> RuntimeAgent:
        matches = [agent for agent in agents if agent.capability == capability]
        if not matches:
            raise LookupError(f"no agent for capability: {capability}")
        return matches[0]
