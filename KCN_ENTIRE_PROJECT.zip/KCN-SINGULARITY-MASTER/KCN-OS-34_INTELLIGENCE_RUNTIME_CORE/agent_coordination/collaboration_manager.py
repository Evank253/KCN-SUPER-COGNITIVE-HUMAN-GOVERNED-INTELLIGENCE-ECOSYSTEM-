"""Collaboration aggregation."""

class CollaborationManager:
    def aggregate(self, outputs: list[dict]) -> dict:
        return {"count": len(outputs), "outputs": outputs, "verified": all(bool(output) for output in outputs)}
