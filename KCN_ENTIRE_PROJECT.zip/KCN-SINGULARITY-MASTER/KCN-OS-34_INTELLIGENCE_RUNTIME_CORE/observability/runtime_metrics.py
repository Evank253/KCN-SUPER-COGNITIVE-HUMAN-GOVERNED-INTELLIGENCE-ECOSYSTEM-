"""Runtime metrics."""

class RuntimeMetrics:
    def __init__(self) -> None:
        self.metrics: list[dict] = []
    def record(self, name: str, value: float) -> dict:
        item = {"name": name, "value": value}
        self.metrics.append(item)
        return item
