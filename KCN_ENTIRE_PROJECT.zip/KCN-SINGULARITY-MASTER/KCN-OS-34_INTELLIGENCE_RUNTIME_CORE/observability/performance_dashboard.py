"""Performance dashboard."""

class PerformanceDashboard:
    def build(self, *, pass_rate: float, avg_confidence: float) -> dict:
        return {"pass_rate": pass_rate, "avg_confidence": avg_confidence, "status": "OK" if pass_rate >= 0.95 else "ATTENTION"}
