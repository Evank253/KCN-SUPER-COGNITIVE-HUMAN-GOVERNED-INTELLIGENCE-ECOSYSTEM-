"""Behavior monitor."""

class BehaviorMonitor:
    def flag(self, *, action: str, allowed: bool) -> list[str]:
        return [] if allowed else [f"blocked:{action}"]
