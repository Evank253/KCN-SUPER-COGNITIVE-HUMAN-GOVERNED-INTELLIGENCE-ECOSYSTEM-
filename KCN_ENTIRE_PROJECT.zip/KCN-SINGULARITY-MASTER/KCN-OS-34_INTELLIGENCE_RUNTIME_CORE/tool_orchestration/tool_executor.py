"""Tool executor."""

from .tool_registry import ToolSpec

class ToolExecutor:
    def execute(self, tool: ToolSpec, payload: dict) -> dict:
        result = tool.run(payload)
        return {"tool": tool.name, "capability": tool.capability, "result": result}
