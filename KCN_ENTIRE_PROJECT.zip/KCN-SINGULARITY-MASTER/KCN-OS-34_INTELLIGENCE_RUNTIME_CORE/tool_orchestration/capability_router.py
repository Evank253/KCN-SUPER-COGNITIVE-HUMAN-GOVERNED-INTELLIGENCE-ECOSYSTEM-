"""Capability router."""

from .tool_registry import ToolRegistry, ToolSpec

class CapabilityRouter:
    def __init__(self, registry: ToolRegistry) -> None:
        self.registry = registry
    def route(self, capability: str) -> ToolSpec:
        return self.registry.require_capability(capability)
