"""Tool registry."""

from dataclasses import dataclass, field
from typing import Callable
from uuid import uuid4

ToolFn = Callable[[dict], dict]

@dataclass(frozen=True)
class ToolSpec:
    name: str
    capability: str
    run: ToolFn
    tool_id: str = field(default_factory=lambda: f"KCN-TOOL-{uuid4().hex[:12].upper()}")

class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, ToolSpec] = {}
    def register(self, *, name: str, capability: str, run: ToolFn) -> ToolSpec:
        tool = ToolSpec(name=name, capability=capability, run=run)
        self._tools[name] = tool
        return tool
    def find_by_capability(self, capability: str) -> list[ToolSpec]:
        return [tool for tool in self._tools.values() if tool.capability == capability]
    def require_capability(self, capability: str) -> ToolSpec:
        matches = self.find_by_capability(capability)
        if not matches:
            raise LookupError(f"no tool for capability: {capability}")
        return matches[0]
