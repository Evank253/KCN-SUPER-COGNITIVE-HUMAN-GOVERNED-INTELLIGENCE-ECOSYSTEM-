"""Memory retrieval ranking."""

from .long_term_memory import MemoryRecord

class MemoryRetrieval:
    def rank(self, *, query: str, records: list[MemoryRecord]) -> list[MemoryRecord]:
        q = query.lower()
        return sorted(records, key=lambda record: (q in record.content.lower(), len(record.content)), reverse=True)
