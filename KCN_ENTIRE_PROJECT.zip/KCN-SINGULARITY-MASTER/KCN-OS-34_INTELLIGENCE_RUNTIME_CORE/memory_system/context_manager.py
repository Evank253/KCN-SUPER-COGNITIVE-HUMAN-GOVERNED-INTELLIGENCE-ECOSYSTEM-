"""Context manager for runtime task context."""

class ContextManager:
    def __init__(self) -> None:
        self._context: dict[str, object] = {}
    def update(self, **kwargs) -> dict[str, object]:
        self._context.update(kwargs)
        return dict(self._context)
    def current(self) -> dict[str, object]:
        return dict(self._context)
