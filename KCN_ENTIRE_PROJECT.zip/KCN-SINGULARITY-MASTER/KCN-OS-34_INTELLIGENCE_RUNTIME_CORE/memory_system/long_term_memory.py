"""Long-term memory with simple scoped retrieval."""

from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class MemoryRecord:
    scope: str
    content: str
    owner: str
    record_id: str = field(default_factory=lambda: f"KCN-LTM-{uuid4().hex[:12].upper()}")

class LongTermMemory:
    def __init__(self) -> None:
        self._records: list[MemoryRecord] = []
    def remember(self, *, scope: str, content: str, owner: str) -> MemoryRecord:
        record = MemoryRecord(scope=scope, content=content, owner=owner)
        self._records.append(record)
        return record
    def recall(self, *, scope: str, text: str | None = None) -> list[MemoryRecord]:
        records = [record for record in self._records if record.scope == scope]
        if text:
            records = [record for record in records if text.lower() in record.content.lower()]
        return records
