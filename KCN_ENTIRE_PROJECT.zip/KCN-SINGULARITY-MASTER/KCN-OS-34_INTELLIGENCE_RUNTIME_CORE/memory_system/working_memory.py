"""Working memory for current runtime execution."""

class WorkingMemory:
    def __init__(self) -> None:
        self._items: dict[str, object] = {}
    def set(self, key: str, value: object) -> None:
        self._items[key] = value
    def get(self, key: str, default=None):
        return self._items.get(key, default)
    def clear(self) -> None:
        self._items.clear()
    def snapshot(self) -> dict[str, object]:
        return dict(self._items)
