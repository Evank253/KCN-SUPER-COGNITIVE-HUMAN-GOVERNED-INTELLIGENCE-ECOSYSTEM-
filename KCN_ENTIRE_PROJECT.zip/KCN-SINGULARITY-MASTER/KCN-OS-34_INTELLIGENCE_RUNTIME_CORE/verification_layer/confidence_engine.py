"""Confidence scoring."""

class ConfidenceEngine:
    def score(self, *, evidence_score: float, consistency_score: float, tool_success: bool) -> float:
        return round(max(0.0, min(1.0, evidence_score * 0.4 + consistency_score * 0.4 + (0.2 if tool_success else 0.0))), 3)
