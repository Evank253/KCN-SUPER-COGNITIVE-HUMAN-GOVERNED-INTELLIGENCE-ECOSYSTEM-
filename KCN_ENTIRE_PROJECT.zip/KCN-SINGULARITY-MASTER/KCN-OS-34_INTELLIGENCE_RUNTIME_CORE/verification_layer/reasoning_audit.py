"""Reasoning audit records."""

from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class ReasoningAuditRecord:
    objective: str
    summary: str
    audit_id: str = field(default_factory=lambda: f"KCN-REASON-AUDIT-{uuid4().hex[:12].upper()}")

class ReasoningAudit:
    def record(self, *, objective: str, summary: str) -> ReasoningAuditRecord:
        return ReasoningAuditRecord(objective=objective, summary=summary)
