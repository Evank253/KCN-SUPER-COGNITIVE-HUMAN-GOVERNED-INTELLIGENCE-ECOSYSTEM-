"""Evidence checker."""

class EvidenceChecker:
    def check(self, evidence_refs: list[str]) -> bool:
        return bool(evidence_refs) and all(ref.startswith(("sha256:", "artifact:", "source:", "evidence:")) for ref in evidence_refs)
