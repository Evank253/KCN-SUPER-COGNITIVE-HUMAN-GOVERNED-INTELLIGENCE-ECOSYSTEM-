"""Output validation."""

class OutputValidator:
    def validate(self, output: dict) -> bool:
        return isinstance(output, dict) and "result" in output and output["result"] is not None
