"""Base connector for KCN Phase 20 integrations."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Optional
from uuid import uuid4


@dataclass(frozen=True)
class ConnectorResponse:
    connector: str
    operation: str
    accepted: bool
    payload: dict
    response_id: str = field(default_factory=lambda: f"KCN-EI-CONN-{uuid4().hex[:12].upper()}")
    completed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class BaseConnector:
    def __init__(self, name: str, handler: Optional[Callable[[str, dict], dict]] = None) -> None:
        self.name = name
        self.handler = handler

    def send(self, operation: str, payload: dict) -> ConnectorResponse:
        if self.handler is None:
            return ConnectorResponse(connector=self.name, operation=operation, accepted=False, payload={"error": "no handler configured", "input": payload})
        return ConnectorResponse(connector=self.name, operation=operation, accepted=True, payload=self.handler(operation, payload))
