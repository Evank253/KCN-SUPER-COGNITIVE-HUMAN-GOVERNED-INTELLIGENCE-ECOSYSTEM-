"""AssuranceConnector adapter."""

from __future__ import annotations

from .base_connector import BaseConnector


class AssuranceConnector(BaseConnector):
    def __init__(self, handler=None) -> None:
        super().__init__(name="AssuranceConnector", handler=handler)
