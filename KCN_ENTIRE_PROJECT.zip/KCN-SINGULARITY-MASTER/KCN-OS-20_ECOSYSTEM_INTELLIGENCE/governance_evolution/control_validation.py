"""Governance control validation."""

from __future__ import annotations

from typing import Dict, List


class ControlValidator:
    def validate(self, *, controls: Dict[str, bool]) -> List[str]:
        return [control for control, implemented in controls.items() if not implemented]

    def score(self, *, controls: Dict[str, bool]) -> float:
        if not controls:
            return 0.0
        return round(len([ok for ok in controls.values() if ok]) / len(controls), 3)
