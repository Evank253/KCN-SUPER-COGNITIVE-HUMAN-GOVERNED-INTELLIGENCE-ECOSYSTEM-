"""Audit improvement tracking."""

from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4


@dataclass(frozen=True)
class AuditImprovementRecord:
    audit_id: str
    finding: str
    remediation: str
    record_id: str = field(default_factory=lambda: f"KCN-AUDIT-IMPROVE-{uuid4().hex[:12].upper()}")


class AuditImprovementTracker:
    def __init__(self) -> None:
        self.records: list[AuditImprovementRecord] = []

    def add(self, *, audit_id: str, finding: str, remediation: str) -> AuditImprovementRecord:
        record = AuditImprovementRecord(audit_id=audit_id, finding=finding, remediation=remediation)
        self.records.append(record)
        return record
