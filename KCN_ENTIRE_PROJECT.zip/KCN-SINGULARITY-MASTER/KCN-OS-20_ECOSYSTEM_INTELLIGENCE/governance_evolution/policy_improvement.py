"""Policy improvement proposals."""

from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4


@dataclass(frozen=True)
class PolicyImprovement:
    policy_id: str
    issue: str
    proposed_change: str
    improvement_id: str = field(default_factory=lambda: f"KCN-POLICY-IMPROVE-{uuid4().hex[:12].upper()}")
    status: str = "PROPOSED"


class PolicyImprovementEngine:
    def propose(self, *, policy_id: str, issue: str, proposed_change: str) -> PolicyImprovement:
        return PolicyImprovement(policy_id=policy_id, issue=issue, proposed_change=proposed_change)
