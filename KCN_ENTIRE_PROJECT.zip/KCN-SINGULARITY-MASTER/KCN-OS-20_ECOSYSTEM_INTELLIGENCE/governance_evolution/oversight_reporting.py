"""Oversight reporting for human-governed evolution."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class OversightReport:
    title: str
    summary: str
    open_changes: int
    pending_approvals: int
    risks: List[str]


class OversightReporting:
    def build(self, *, title: str, open_changes: int, pending_approvals: int, risks: List[str]) -> OversightReport:
        summary = f"{open_changes} open changes, {pending_approvals} pending approvals, {len(risks)} tracked risks."
        return OversightReport(title=title, summary=summary, open_changes=open_changes, pending_approvals=pending_approvals, risks=risks)
