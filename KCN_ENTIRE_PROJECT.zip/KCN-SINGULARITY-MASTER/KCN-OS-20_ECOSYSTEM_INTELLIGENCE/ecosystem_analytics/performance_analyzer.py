"""Performance analysis for ecosystem metrics."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass(frozen=True)
class PerformanceFinding:
    metric: str
    status: str
    value: float
    threshold: float
    recommendation: str


class PerformanceAnalyzer:
    def analyze(self, *, metric_values: Dict[str, float], thresholds: Dict[str, float]) -> List[PerformanceFinding]:
        findings: List[PerformanceFinding] = []
        for metric, value in metric_values.items():
            threshold = thresholds.get(metric)
            if threshold is None:
                continue
            status = "PASS" if value <= threshold else "ATTENTION"
            recommendation = "continue monitoring" if status == "PASS" else f"investigate {metric}; value exceeds threshold"
            findings.append(PerformanceFinding(metric=metric, status=status, value=value, threshold=threshold, recommendation=recommendation))
        return findings

    def score(self, *, metric_values: Dict[str, float], thresholds: Dict[str, float]) -> float:
        findings = self.analyze(metric_values=metric_values, thresholds=thresholds)
        if not findings:
            return 1.0
        passed = len([finding for finding in findings if finding.status == "PASS"])
        return round(passed / len(findings), 3)
