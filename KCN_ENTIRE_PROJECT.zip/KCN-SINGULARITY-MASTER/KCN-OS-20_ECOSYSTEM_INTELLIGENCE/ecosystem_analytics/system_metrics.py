"""System metric collection for KCN ecosystem intelligence."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional
from uuid import uuid4


@dataclass(frozen=True)
class MetricRecord:
    name: str
    value: float
    unit: str
    source: str
    metric_id: str = field(default_factory=lambda: f"KCN-METRIC-{uuid4().hex[:12].upper()}")
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    tags: Dict[str, str] = field(default_factory=dict)


class SystemMetricsCollector:
    def __init__(self) -> None:
        self._metrics: List[MetricRecord] = []

    def record(self, *, name: str, value: float, unit: str, source: str, tags: Optional[Dict[str, str]] = None) -> MetricRecord:
        metric = MetricRecord(name=name, value=float(value), unit=unit, source=source, tags=tags or {})
        self._metrics.append(metric)
        return metric

    def list_metrics(self, *, name: Optional[str] = None, source: Optional[str] = None) -> List[MetricRecord]:
        metrics = list(self._metrics)
        if name:
            metrics = [metric for metric in metrics if metric.name == name]
        if source:
            metrics = [metric for metric in metrics if metric.source == source]
        return metrics

    def latest_value(self, name: str, *, default: float = 0.0) -> float:
        for metric in reversed(self._metrics):
            if metric.name == name:
                return metric.value
        return default

    def average(self, name: str) -> float:
        values = [metric.value for metric in self._metrics if metric.name == name]
        return round(sum(values) / len(values), 4) if values else 0.0
