"""Usage analytics for KCN ecosystem activity."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class UsageEvent:
    user_id: str
    action: str
    subsystem: str
    event_id: str = field(default_factory=lambda: f"KCN-USAGE-{uuid4().hex[:12].upper()}")
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class UsageAnalytics:
    def __init__(self) -> None:
        self._events: List[UsageEvent] = []

    def record(self, *, user_id: str, action: str, subsystem: str) -> UsageEvent:
        event = UsageEvent(user_id=user_id, action=action, subsystem=subsystem)
        self._events.append(event)
        return event

    def counts_by_subsystem(self) -> Dict[str, int]:
        return dict(Counter(event.subsystem for event in self._events))

    def counts_by_action(self) -> Dict[str, int]:
        return dict(Counter(event.action for event in self._events))

    def active_users(self) -> int:
        return len({event.user_id for event in self._events})
