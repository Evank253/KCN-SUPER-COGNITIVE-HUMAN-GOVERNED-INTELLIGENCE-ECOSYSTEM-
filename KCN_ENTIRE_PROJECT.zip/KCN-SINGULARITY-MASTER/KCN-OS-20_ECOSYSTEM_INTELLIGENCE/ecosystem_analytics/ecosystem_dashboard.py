"""Ecosystem intelligence dashboard."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List


@dataclass(frozen=True)
class EcosystemDashboardSnapshot:
    health_score: float
    performance_score: float
    active_users: int
    open_recommendations: int
    risks: List[str]
    generated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class EcosystemDashboard:
    def build(self, *, health_score: float, performance_score: float, active_users: int, open_recommendations: int, risks: List[str]) -> EcosystemDashboardSnapshot:
        return EcosystemDashboardSnapshot(
            health_score=round(max(0.0, min(1.0, health_score)), 3),
            performance_score=round(max(0.0, min(1.0, performance_score)), 3),
            active_users=active_users,
            open_recommendations=open_recommendations,
            risks=risks,
        )
