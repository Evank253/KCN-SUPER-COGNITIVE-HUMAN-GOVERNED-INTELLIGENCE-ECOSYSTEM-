"""Future scenario modeling."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict
from uuid import uuid4


@dataclass(frozen=True)
class FutureScenario:
    name: str
    assumptions: Dict[str, float]
    scenario_id: str = field(default_factory=lambda: f"KCN-SCENARIO-{uuid4().hex[:12].upper()}")


class FutureScenarioBuilder:
    def build(self, *, name: str, assumptions: Dict[str, float]) -> FutureScenario:
        return FutureScenario(name=name, assumptions=assumptions)
