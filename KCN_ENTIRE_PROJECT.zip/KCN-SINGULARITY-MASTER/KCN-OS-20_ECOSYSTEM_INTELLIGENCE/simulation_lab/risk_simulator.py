"""Risk simulation helpers."""

from __future__ import annotations

from typing import Dict


class RiskSimulator:
    def score(self, *, likelihood: float, impact: float, control_strength: float) -> float:
        raw = max(0.0, min(1.0, likelihood)) * max(0.0, min(1.0, impact)) * (1.0 - max(0.0, min(1.0, control_strength)))
        return round(raw, 3)

    def label(self, score: float) -> str:
        return "HIGH" if score >= 0.5 else "MEDIUM" if score >= 0.2 else "LOW"
