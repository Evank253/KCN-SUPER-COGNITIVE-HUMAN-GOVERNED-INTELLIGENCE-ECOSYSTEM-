"""Outcome prediction based on weighted signals."""

from __future__ import annotations

from typing import Dict


class OutcomePrediction:
    def predict_success(self, *, signals: Dict[str, float], weights: Dict[str, float]) -> float:
        if not signals:
            return 0.0
        total_weight = sum(abs(weights.get(key, 1.0)) for key in signals) or 1.0
        weighted = sum(max(0.0, min(1.0, value)) * abs(weights.get(key, 1.0)) for key, value in signals.items())
        return round(weighted / total_weight, 3)
