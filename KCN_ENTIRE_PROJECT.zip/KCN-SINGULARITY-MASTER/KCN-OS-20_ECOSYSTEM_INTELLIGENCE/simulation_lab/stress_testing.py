"""Stress testing estimates for ecosystem capacity."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class StressTestResult:
    load: float
    capacity: float
    utilization: float
    status: str


class StressTesting:
    def run(self, *, load: float, capacity: float) -> StressTestResult:
        utilization = load / capacity if capacity else 1.0
        status = "PASS" if utilization <= 0.8 else "DEGRADED" if utilization <= 1.0 else "FAIL"
        return StressTestResult(load=load, capacity=capacity, utilization=round(utilization, 3), status=status)
