"""Benchmark runner for ecosystem capabilities."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Dict
from uuid import uuid4

BenchmarkFn = Callable[[], float]


@dataclass(frozen=True)
class BenchmarkResult:
    name: str
    score: float
    passed: bool
    threshold: float
    result_id: str = field(default_factory=lambda: f"KCN-BENCH-{uuid4().hex[:12].upper()}")
    completed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class BenchmarkRunner:
    def __init__(self) -> None:
        self._benchmarks: Dict[str, tuple[BenchmarkFn, float]] = {}

    def register(self, *, name: str, benchmark: BenchmarkFn, threshold: float) -> None:
        self._benchmarks[name] = (benchmark, threshold)

    def run(self, name: str) -> BenchmarkResult:
        benchmark, threshold = self._benchmarks[name]
        score = benchmark()
        return BenchmarkResult(name=name, score=round(score, 3), passed=score >= threshold, threshold=threshold)

    def run_all(self) -> list[BenchmarkResult]:
        return [self.run(name) for name in sorted(self._benchmarks)]
