"""Regression detection against previous benchmark scores."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RegressionFinding:
    benchmark: str
    previous_score: float
    current_score: float
    regression: bool
    delta: float


class RegressionDetector:
    def detect(self, *, benchmark: str, previous_score: float, current_score: float, tolerance: float = 0.05) -> RegressionFinding:
        delta = round(current_score - previous_score, 3)
        return RegressionFinding(
            benchmark=benchmark,
            previous_score=previous_score,
            current_score=current_score,
            regression=delta < -abs(tolerance),
            delta=delta,
        )
