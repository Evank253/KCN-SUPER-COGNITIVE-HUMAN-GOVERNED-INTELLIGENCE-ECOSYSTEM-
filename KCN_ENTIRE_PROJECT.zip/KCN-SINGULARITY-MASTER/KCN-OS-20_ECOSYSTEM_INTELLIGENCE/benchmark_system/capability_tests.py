"""Capability test helpers."""

from __future__ import annotations

from typing import Dict


class CapabilityTests:
    def score_capability(self, *, checks: Dict[str, bool]) -> float:
        if not checks:
            return 0.0
        return round(len([ok for ok in checks.values() if ok]) / len(checks), 3)
