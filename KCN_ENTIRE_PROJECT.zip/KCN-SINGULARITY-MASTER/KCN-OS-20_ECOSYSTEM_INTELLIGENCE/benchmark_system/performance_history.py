"""Benchmark performance history store."""

from __future__ import annotations

from collections import defaultdict
from typing import Dict, List

from .benchmark_runner import BenchmarkResult


class PerformanceHistory:
    def __init__(self) -> None:
        self._history: Dict[str, List[BenchmarkResult]] = defaultdict(list)

    def add(self, result: BenchmarkResult) -> BenchmarkResult:
        self._history[result.name].append(result)
        return result

    def latest(self, name: str) -> BenchmarkResult | None:
        values = self._history.get(name, [])
        return values[-1] if values else None

    def trend(self, name: str) -> List[float]:
        return [result.score for result in self._history.get(name, [])]
