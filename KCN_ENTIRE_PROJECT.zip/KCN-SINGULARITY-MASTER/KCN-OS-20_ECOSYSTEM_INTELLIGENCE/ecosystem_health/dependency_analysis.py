"""Dependency risk analysis."""

from __future__ import annotations

from typing import Dict, List


class DependencyAnalyzer:
    def critical_dependencies(self, *, dependencies: Dict[str, List[str]], criticality: Dict[str, str]) -> List[str]:
        critical = []
        for subsystem, deps in dependencies.items():
            if any(criticality.get(dep) == "HIGH" for dep in deps):
                critical.append(subsystem)
        return sorted(critical)

    def dependency_count(self, *, dependencies: Dict[str, List[str]]) -> Dict[str, int]:
        return {subsystem: len(deps) for subsystem, deps in dependencies.items()}
