"""Reliability tracking."""

from __future__ import annotations


class ReliabilityTracker:
    def uptime_ratio(self, *, successful_checks: int, total_checks: int) -> float:
        return round(successful_checks / total_checks, 4) if total_checks else 0.0

    def error_rate(self, *, errors: int, total_requests: int) -> float:
        return round(errors / total_requests, 4) if total_requests else 0.0
