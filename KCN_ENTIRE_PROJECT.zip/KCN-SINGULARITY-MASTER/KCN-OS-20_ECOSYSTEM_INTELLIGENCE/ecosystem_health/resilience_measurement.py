"""Resilience measurement."""

from __future__ import annotations


class ResilienceMeasurement:
    def score(self, *, redundancy: float, recovery_readiness: float, tested_failover: bool) -> float:
        score = (max(0.0, min(1.0, redundancy)) * 0.35) + (max(0.0, min(1.0, recovery_readiness)) * 0.45) + (0.2 if tested_failover else 0.0)
        return round(score, 3)
