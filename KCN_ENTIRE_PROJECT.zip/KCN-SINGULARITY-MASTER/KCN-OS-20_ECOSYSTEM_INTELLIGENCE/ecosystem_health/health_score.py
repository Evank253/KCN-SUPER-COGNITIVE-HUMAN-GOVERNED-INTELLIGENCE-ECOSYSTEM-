"""Ecosystem health score calculation."""

from __future__ import annotations

from typing import Dict


class HealthScoreCalculator:
    def calculate(self, *, subsystem_scores: Dict[str, float]) -> float:
        if not subsystem_scores:
            return 0.0
        return round(sum(max(0.0, min(1.0, score)) for score in subsystem_scores.values()) / len(subsystem_scores), 3)

    def label(self, score: float) -> str:
        if score >= 0.9:
            return "EXCELLENT"
        if score >= 0.75:
            return "HEALTHY"
        if score >= 0.55:
            return "DEGRADED"
        return "CRITICAL"
