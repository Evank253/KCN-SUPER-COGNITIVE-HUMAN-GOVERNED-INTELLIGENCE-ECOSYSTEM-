"""Human approval workflows for ecosystem evolution."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class ApprovalWorkflow:
    subject_id: str
    required_approvers: int
    approvals: List[str] = field(default_factory=list)
    workflow_id: str = field(default_factory=lambda: f"KCN-APPROVAL-WF-{uuid4().hex[:12].upper()}")
    status: str = "PENDING"


class ApprovalWorkflows:
    def __init__(self) -> None:
        self._workflows: Dict[str, ApprovalWorkflow] = {}

    def create(self, *, subject_id: str, required_approvers: int = 1) -> ApprovalWorkflow:
        workflow = ApprovalWorkflow(subject_id=subject_id, required_approvers=required_approvers)
        self._workflows[workflow.workflow_id] = workflow
        return workflow

    def approve(self, *, workflow_id: str, approver: str) -> ApprovalWorkflow:
        workflow = self._workflows[workflow_id]
        approvals = list(workflow.approvals)
        if approver not in approvals:
            approvals.append(approver)
        status = "APPROVED" if len(approvals) >= workflow.required_approvers else "PENDING"
        updated = ApprovalWorkflow(**{**workflow.__dict__, "approvals": approvals, "status": status})
        self._workflows[workflow_id] = updated
        return updated
