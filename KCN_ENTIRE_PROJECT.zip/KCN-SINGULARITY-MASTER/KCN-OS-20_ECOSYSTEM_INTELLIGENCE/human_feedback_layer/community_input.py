"""Community input aggregation."""

from __future__ import annotations

from collections import Counter
from typing import List


class CommunityInput:
    def vote_summary(self, votes: List[str]) -> dict[str, int]:
        return dict(Counter(votes))
