"""Expert review records."""

from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4


@dataclass(frozen=True)
class ExpertReviewRecord:
    reviewer_id: str
    subject_id: str
    decision: str
    notes: str
    review_id: str = field(default_factory=lambda: f"KCN-EXPERT-REVIEW-{uuid4().hex[:12].upper()}")


class ExpertReview:
    def review(self, *, reviewer_id: str, subject_id: str, decision: str, notes: str) -> ExpertReviewRecord:
        if decision not in {"APPROVE", "REJECT", "REQUEST_CHANGES"}:
            raise ValueError("decision must be APPROVE, REJECT, or REQUEST_CHANGES")
        return ExpertReviewRecord(reviewer_id=reviewer_id, subject_id=subject_id, decision=decision, notes=notes)
