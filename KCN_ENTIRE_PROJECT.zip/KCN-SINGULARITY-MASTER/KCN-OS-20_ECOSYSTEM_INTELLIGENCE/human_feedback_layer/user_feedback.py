"""User feedback channel."""

from __future__ import annotations

from intelligence_feedback.feedback_collector import FeedbackCollector, FeedbackRecord


class UserFeedback:
    def __init__(self, collector: FeedbackCollector | None = None) -> None:
        self.collector = collector or FeedbackCollector()

    def submit(self, *, user_id: str, message: str, rating: float, subsystem: str | None = None) -> FeedbackRecord:
        return self.collector.collect(source=user_id, category="user", message=message, rating=rating, subsystem=subsystem)
