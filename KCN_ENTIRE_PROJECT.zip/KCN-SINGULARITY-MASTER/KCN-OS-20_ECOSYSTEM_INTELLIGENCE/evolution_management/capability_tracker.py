"""Capability growth tracking."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class CapabilityRecord:
    name: str
    maturity: float
    evidence_refs: List[str]
    capability_id: str = field(default_factory=lambda: f"KCN-CAPABILITY-{uuid4().hex[:12].upper()}")


class CapabilityTracker:
    def __init__(self) -> None:
        self._records: Dict[str, CapabilityRecord] = {}

    def upsert(self, *, name: str, maturity: float, evidence_refs: List[str]) -> CapabilityRecord:
        record = CapabilityRecord(name=name, maturity=max(0.0, min(1.0, maturity)), evidence_refs=evidence_refs)
        self._records[name] = record
        return record

    def maturity_score(self) -> float:
        values = [record.maturity for record in self._records.values()]
        return round(sum(values) / len(values), 3) if values else 0.0
