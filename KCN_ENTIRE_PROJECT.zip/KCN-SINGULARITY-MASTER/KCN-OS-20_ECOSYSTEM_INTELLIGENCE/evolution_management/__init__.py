"""Evolution management exports."""

from .version_evolution import VersionEvolution, VersionRecord
from .architecture_optimizer import ArchitectureOptimizer
from .capability_tracker import CapabilityRecord, CapabilityTracker
from .change_manager import ChangeManager, ChangeRequest

__all__ = [
    "VersionEvolution",
    "VersionRecord",
    "ArchitectureOptimizer",
    "CapabilityRecord",
    "CapabilityTracker",
    "ChangeManager",
    "ChangeRequest",
]
