"""Controlled change management."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class ChangeRequest:
    title: str
    description: str
    risk_level: str
    rollback_plan: str
    change_id: str = field(default_factory=lambda: f"KCN-CHANGE-{uuid4().hex[:12].upper()}")
    status: str = "PROPOSED"
    approvals: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class ChangeManager:
    def __init__(self) -> None:
        self._changes: Dict[str, ChangeRequest] = {}

    def create(self, *, title: str, description: str, risk_level: str, rollback_plan: str) -> ChangeRequest:
        change = ChangeRequest(title=title, description=description, risk_level=risk_level, rollback_plan=rollback_plan)
        self._changes[change.change_id] = change
        return change

    def approve(self, *, change_id: str, approver: str) -> ChangeRequest:
        change = self._changes.get(change_id)
        if change is None:
            raise KeyError(f"unknown change request: {change_id}")
        approvals = list(change.approvals)
        if approver not in approvals:
            approvals.append(approver)
        status = "APPROVED" if approvals else change.status
        updated = ChangeRequest(**{**change.__dict__, "approvals": approvals, "status": status})
        self._changes[change_id] = updated
        return updated

    def list_changes(self, *, status: str | None = None) -> List[ChangeRequest]:
        changes = list(self._changes.values())
        if status:
            changes = [change for change in changes if change.status == status]
        return changes
