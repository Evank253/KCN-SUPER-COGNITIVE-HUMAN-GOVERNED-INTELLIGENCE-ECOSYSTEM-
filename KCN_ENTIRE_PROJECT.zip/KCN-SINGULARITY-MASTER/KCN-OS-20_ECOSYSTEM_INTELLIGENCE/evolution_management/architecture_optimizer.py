"""Architecture optimization recommendation helpers."""

from __future__ import annotations

from typing import Dict, List


class ArchitectureOptimizer:
    def recommend(self, *, dependency_counts: Dict[str, int], latency_ms: Dict[str, float]) -> List[str]:
        recommendations: List[str] = []
        for subsystem, count in dependency_counts.items():
            if count > 8:
                recommendations.append(f"Review coupling for {subsystem}; dependency count is high.")
        for subsystem, latency in latency_ms.items():
            if latency > 500:
                recommendations.append(f"Investigate latency for {subsystem}; p95 exceeds 500ms.")
        return recommendations
