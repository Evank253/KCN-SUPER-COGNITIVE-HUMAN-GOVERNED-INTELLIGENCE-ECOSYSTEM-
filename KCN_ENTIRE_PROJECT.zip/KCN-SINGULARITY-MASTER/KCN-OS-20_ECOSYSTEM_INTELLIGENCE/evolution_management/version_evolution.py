"""Version evolution tracking."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class VersionRecord:
    component: str
    version: str
    change_summary: str
    version_id: str = field(default_factory=lambda: f"KCN-VERSION-{uuid4().hex[:12].upper()}")
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class VersionEvolution:
    def __init__(self) -> None:
        self._versions: Dict[str, List[VersionRecord]] = {}

    def record(self, *, component: str, version: str, change_summary: str) -> VersionRecord:
        record = VersionRecord(component=component, version=version, change_summary=change_summary)
        self._versions.setdefault(component, []).append(record)
        return record

    def latest(self, component: str) -> VersionRecord | None:
        versions = self._versions.get(component, [])
        return versions[-1] if versions else None

    def history(self, component: str) -> List[VersionRecord]:
        return list(self._versions.get(component, []))
