from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from evolution_management import ArchitectureOptimizer, CapabilityTracker, ChangeManager, VersionEvolution
from knowledge_evolution import DiscoveryTracker, InformationLifecycle, KnowledgeGrowthTracker, KnowledgeQualityScorer


class TestEvolutionAndKnowledge(unittest.TestCase):
    def test_version_capability_change_and_knowledge_evolution(self) -> None:
        versions = VersionEvolution()
        v1 = versions.record(component="orchestration", version="0.10.0", change_summary="Initial orchestration package")
        v2 = versions.record(component="orchestration", version="0.10.1", change_summary="Workflow optimization")
        self.assertEqual(versions.latest("orchestration").version_id, v2.version_id)
        self.assertEqual(len(versions.history("orchestration")), 2)

        optimizer_recs = ArchitectureOptimizer().recommend(
            dependency_counts={"orchestration": 9},
            latency_ms={"api_gateway": 650},
        )
        self.assertEqual(len(optimizer_recs), 2)

        tracker = CapabilityTracker()
        tracker.upsert(name="human_approval_workflows", maturity=0.8, evidence_refs=[v1.version_id])
        tracker.upsert(name="rollback_management", maturity=0.7, evidence_refs=[v2.version_id])
        self.assertEqual(tracker.maturity_score(), 0.75)

        changes = ChangeManager()
        change = changes.create(
            title="Optimize orchestration queue",
            description="Improve workflow latency",
            risk_level="MEDIUM",
            rollback_plan="Restore previous queue configuration",
        )
        approved = changes.approve(change_id=change.change_id, approver="human-operator")
        self.assertEqual(approved.status, "APPROVED")

        growth = KnowledgeGrowthTracker()
        growth.record(domain="security", records_added=10, verified_records=8)
        self.assertEqual(growth.verification_ratio("security"), 0.8)

        discovery = DiscoveryTracker().add(title="Workflow bottleneck pattern", domain="operations", confidence=0.75, evidence_ref="metric:latency")
        self.assertEqual(discovery.domain, "operations")

        quality = KnowledgeQualityScorer().score(source_reputation=0.9, evidence_strength=0.8, freshness=0.7, review_status=True)
        self.assertGreater(quality, 0.8)

        lifecycle = InformationLifecycle().transition(record_id=discovery.discovery_id, state="APPROVED", reason="expert reviewed")
        self.assertEqual(lifecycle.state, "APPROVED")


if __name__ == "__main__":
    unittest.main()
