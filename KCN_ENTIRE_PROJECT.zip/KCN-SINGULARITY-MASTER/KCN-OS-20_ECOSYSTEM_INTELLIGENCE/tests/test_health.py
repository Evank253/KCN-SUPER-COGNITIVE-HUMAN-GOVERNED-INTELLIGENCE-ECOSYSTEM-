from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ecosystem_health import DependencyAnalyzer, HealthScoreCalculator, ReliabilityTracker, ResilienceMeasurement


class TestHealth(unittest.TestCase):
    def test_health_dependency_reliability_and_resilience(self) -> None:
        health = HealthScoreCalculator()
        score = health.calculate(subsystem_scores={"security": 0.95, "orchestration": 0.85, "trust": 0.9})
        self.assertEqual(score, 0.9)
        self.assertEqual(health.label(score), "EXCELLENT")

        dependency = DependencyAnalyzer()
        critical = dependency.critical_dependencies(
            dependencies={"orchestration": ["security", "trust"], "dashboard": ["analytics"]},
            criticality={"security": "HIGH", "trust": "MEDIUM", "analytics": "LOW"},
        )
        self.assertEqual(critical, ["orchestration"])
        self.assertEqual(dependency.dependency_count(dependencies={"a": ["b", "c"]})["a"], 2)

        reliability = ReliabilityTracker()
        self.assertEqual(reliability.uptime_ratio(successful_checks=99, total_checks=100), 0.99)
        self.assertEqual(reliability.error_rate(errors=2, total_requests=100), 0.02)

        resilience = ResilienceMeasurement().score(redundancy=0.8, recovery_readiness=0.9, tested_failover=True)
        self.assertGreater(resilience, 0.85)


if __name__ == "__main__":
    unittest.main()
