from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from connectors import GovernanceConnector
from governance_evolution import AuditImprovementTracker, ControlValidator, OversightReporting, PolicyImprovementEngine
from human_feedback_layer import ApprovalWorkflows, CommunityInput, ExpertReview, UserFeedback


class TestGovernanceAndHumanReview(unittest.TestCase):
    def test_governance_improvement_and_human_review(self) -> None:
        policy = PolicyImprovementEngine().propose(
            policy_id="policy:approval",
            issue="major changes need clearer rollback evidence",
            proposed_change="Require rollback plan attachment before review",
        )
        self.assertEqual(policy.status, "PROPOSED")

        validator = ControlValidator()
        missing = validator.validate(controls={"rollback_plan": True, "human_approval": True, "audit_record": False})
        self.assertEqual(missing, ["audit_record"])
        self.assertEqual(validator.score(controls={"a": True, "b": False}), 0.5)

        audit = AuditImprovementTracker().add(
            audit_id="audit:001",
            finding="missing audit record",
            remediation="add required event logging",
        )
        self.assertEqual(audit.remediation, "add required event logging")

        report = OversightReporting().build(title="Evolution Oversight", open_changes=1, pending_approvals=1, risks=["latency"])
        self.assertIn("pending approvals", report.summary)

        expert = ExpertReview().review(reviewer_id="expert-1", subject_id=policy.improvement_id, decision="APPROVE", notes="reasonable control")
        self.assertEqual(expert.decision, "APPROVE")

        approvals = ApprovalWorkflows()
        workflow = approvals.create(subject_id=policy.improvement_id, required_approvers=2)
        workflow = approvals.approve(workflow_id=workflow.workflow_id, approver="operator-1")
        self.assertEqual(workflow.status, "PENDING")
        workflow = approvals.approve(workflow_id=workflow.workflow_id, approver="operator-2")
        self.assertEqual(workflow.status, "APPROVED")

        feedback = UserFeedback().submit(user_id="user-1", message="change improved clarity", rating=0.9)
        self.assertEqual(feedback.category, "user")
        self.assertEqual(CommunityInput().vote_summary(["approve", "approve", "revise"])["approve"], 2)

        connector = GovernanceConnector(handler=lambda operation, payload: {"operation": operation, "accepted": True})
        response = connector.send("register_policy_improvement", {"policy_id": policy.policy_id})
        self.assertTrue(response.accepted)


if __name__ == "__main__":
    unittest.main()
