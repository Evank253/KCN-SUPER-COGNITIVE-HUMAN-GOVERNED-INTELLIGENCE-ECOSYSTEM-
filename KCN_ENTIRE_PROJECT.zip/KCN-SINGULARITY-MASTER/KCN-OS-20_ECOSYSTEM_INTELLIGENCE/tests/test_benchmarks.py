from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmark_system import BenchmarkRunner, CapabilityTests, PerformanceHistory, RegressionDetector
from simulation_lab import FutureScenarioBuilder, OutcomePrediction, RiskSimulator, StressTesting


class TestBenchmarksAndSimulation(unittest.TestCase):
    def test_benchmarks_regression_and_simulation_lab(self) -> None:
        capability_score = CapabilityTests().score_capability(checks={"route": True, "audit": True, "rollback": False})
        self.assertEqual(capability_score, 0.667)

        runner = BenchmarkRunner()
        runner.register(name="orchestration_capability", benchmark=lambda: capability_score, threshold=0.6)
        result = runner.run("orchestration_capability")
        self.assertTrue(result.passed)

        history = PerformanceHistory()
        history.add(result)
        self.assertEqual(history.latest("orchestration_capability").result_id, result.result_id)

        regression = RegressionDetector().detect(benchmark="orchestration_capability", previous_score=0.8, current_score=result.score, tolerance=0.05)
        self.assertTrue(regression.regression)

        scenario = FutureScenarioBuilder().build(name="regional growth", assumptions={"users": 10000, "load_multiplier": 2.0})
        self.assertEqual(scenario.name, "regional growth")

        stress = StressTesting().run(load=75, capacity=100)
        self.assertEqual(stress.status, "PASS")

        risk_score = RiskSimulator().score(likelihood=0.5, impact=0.8, control_strength=0.5)
        self.assertEqual(RiskSimulator().label(risk_score), "MEDIUM")

        prediction = OutcomePrediction().predict_success(signals={"health": 0.9, "readiness": 0.8}, weights={"health": 2, "readiness": 1})
        self.assertGreater(prediction, 0.85)


if __name__ == "__main__":
    unittest.main()
