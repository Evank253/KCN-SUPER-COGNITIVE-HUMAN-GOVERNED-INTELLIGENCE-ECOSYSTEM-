from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ecosystem_analytics import EcosystemDashboard, PerformanceAnalyzer, SystemMetricsCollector, UsageAnalytics
from intelligence_feedback import FeedbackCollector, PatternAnalyzer, RecommendationEngine, ImprovementEngine


class TestMetricsAndFeedback(unittest.TestCase):
    def test_metrics_usage_dashboard_and_recommendations(self) -> None:
        metrics = SystemMetricsCollector()
        metrics.record(name="api_latency_ms", value=120, unit="ms", source="api_gateway")
        metrics.record(name="api_latency_ms", value=180, unit="ms", source="api_gateway")
        metrics.record(name="error_rate", value=0.01, unit="ratio", source="api_gateway")
        self.assertEqual(metrics.average("api_latency_ms"), 150.0)

        analyzer = PerformanceAnalyzer()
        perf_score = analyzer.score(metric_values={"api_latency_ms": 180, "error_rate": 0.01}, thresholds={"api_latency_ms": 250, "error_rate": 0.05})
        self.assertEqual(perf_score, 1.0)

        usage = UsageAnalytics()
        usage.record(user_id="u1", action="mission:create", subsystem="orchestration")
        usage.record(user_id="u2", action="mission:create", subsystem="orchestration")
        self.assertEqual(usage.active_users(), 2)
        self.assertEqual(usage.counts_by_subsystem()["orchestration"], 2)

        feedback = FeedbackCollector()
        feedback.collect(source="u1", category="user", message="Workflow feels slow but useful", rating=0.7, subsystem="orchestration")
        feedback.collect(source="u2", category="user", message="Dashboard useful and clear", rating=0.9, subsystem="dashboard")
        self.assertEqual(feedback.average_rating(), 0.8)
        terms = PatternAnalyzer().top_terms(record.message for record in feedback.records())
        self.assertTrue(any(term == "useful" for term, _count in terms))

        recs = RecommendationEngine().generate_from_findings([
            {"severity": "MEDIUM", "title": "Improve workflow latency", "target_subsystem": "orchestration", "rationale": "User feedback and metrics indicate latency improvement opportunity."}
        ])
        proposal = ImprovementEngine().propose(recommendation=recs[0], change_summary="Optimize workflow queue", expected_benefit="Lower latency")
        self.assertEqual(proposal.status, "AWAITING_REVIEW")

        dashboard = EcosystemDashboard().build(
            health_score=0.9,
            performance_score=perf_score,
            active_users=usage.active_users(),
            open_recommendations=len(recs),
            risks=[],
        )
        self.assertEqual(dashboard.performance_score, 1.0)


if __name__ == "__main__":
    unittest.main()
