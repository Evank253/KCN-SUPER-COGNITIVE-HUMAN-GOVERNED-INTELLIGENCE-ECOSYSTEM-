"""Improvement recommendation generation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class Recommendation:
    title: str
    rationale: str
    priority: str
    target_subsystem: str
    requires_human_review: bool = True
    recommendation_id: str = field(default_factory=lambda: f"KCN-REC-{uuid4().hex[:12].upper()}")
    status: str = "PROPOSED"


class RecommendationEngine:
    def generate_from_findings(self, findings: List[Dict[str, object]]) -> List[Recommendation]:
        recommendations: List[Recommendation] = []
        for finding in findings:
            severity = str(finding.get("severity", "MEDIUM"))
            priority = "HIGH" if severity == "HIGH" else "MEDIUM" if severity == "MEDIUM" else "LOW"
            recommendations.append(
                Recommendation(
                    title=str(finding.get("title", "Ecosystem improvement")),
                    rationale=str(finding.get("rationale", finding.get("finding", "Evidence indicates improvement opportunity."))),
                    priority=priority,
                    target_subsystem=str(finding.get("target_subsystem", "ecosystem")),
                )
            )
        return recommendations
