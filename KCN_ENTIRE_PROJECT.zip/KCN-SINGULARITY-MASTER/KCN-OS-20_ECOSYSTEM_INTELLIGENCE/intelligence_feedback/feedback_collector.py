"""Feedback collection for continuous ecosystem improvement."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional
from uuid import uuid4


@dataclass(frozen=True)
class FeedbackRecord:
    source: str
    category: str
    message: str
    rating: float
    feedback_id: str = field(default_factory=lambda: f"KCN-FEEDBACK-{uuid4().hex[:12].upper()}")
    subsystem: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class FeedbackCollector:
    def __init__(self) -> None:
        self._records: List[FeedbackRecord] = []

    def collect(self, *, source: str, category: str, message: str, rating: float, subsystem: Optional[str] = None) -> FeedbackRecord:
        record = FeedbackRecord(source=source, category=category, message=message, rating=max(0.0, min(1.0, rating)), subsystem=subsystem)
        self._records.append(record)
        return record

    def records(self, *, category: Optional[str] = None) -> List[FeedbackRecord]:
        records = list(self._records)
        if category:
            records = [record for record in records if record.category == category]
        return records

    def average_rating(self) -> float:
        return round(sum(record.rating for record in self._records) / len(self._records), 3) if self._records else 0.0
