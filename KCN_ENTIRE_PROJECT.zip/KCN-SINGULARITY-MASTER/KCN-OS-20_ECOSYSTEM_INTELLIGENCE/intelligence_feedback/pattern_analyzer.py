"""Pattern analysis for feedback and metrics."""

from __future__ import annotations

from collections import Counter
from typing import Dict, Iterable, List


class PatternAnalyzer:
    def top_terms(self, messages: Iterable[str], *, limit: int = 5) -> List[tuple[str, int]]:
        words: List[str] = []
        for message in messages:
            words.extend(word.strip(".,!?;:").lower() for word in message.split() if len(word.strip(".,!?;:")) > 3)
        return Counter(words).most_common(limit)

    def category_counts(self, categories: Iterable[str]) -> Dict[str, int]:
        return dict(Counter(categories))
