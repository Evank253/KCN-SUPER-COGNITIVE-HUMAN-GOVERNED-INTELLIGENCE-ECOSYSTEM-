"""Improvement proposal management."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List
from uuid import uuid4

from .recommendation_engine import Recommendation


@dataclass(frozen=True)
class ImprovementProposal:
    recommendation_id: str
    change_summary: str
    expected_benefit: str
    risk_level: str
    proposal_id: str = field(default_factory=lambda: f"KCN-IMPROVE-{uuid4().hex[:12].upper()}")
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    status: str = "AWAITING_REVIEW"


class ImprovementEngine:
    def __init__(self) -> None:
        self._proposals: Dict[str, ImprovementProposal] = {}

    def propose(self, *, recommendation: Recommendation, change_summary: str, expected_benefit: str, risk_level: str = "MEDIUM") -> ImprovementProposal:
        proposal = ImprovementProposal(
            recommendation_id=recommendation.recommendation_id,
            change_summary=change_summary,
            expected_benefit=expected_benefit,
            risk_level=risk_level,
        )
        self._proposals[proposal.proposal_id] = proposal
        return proposal

    def list_proposals(self) -> List[ImprovementProposal]:
        return sorted(self._proposals.values(), key=lambda proposal: proposal.created_at)
