"""Discovery tracking."""

from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4


@dataclass(frozen=True)
class DiscoveryRecord:
    title: str
    domain: str
    confidence: float
    evidence_ref: str
    discovery_id: str = field(default_factory=lambda: f"KCN-DISCOVERY-{uuid4().hex[:12].upper()}")


class DiscoveryTracker:
    def __init__(self) -> None:
        self.discoveries: list[DiscoveryRecord] = []

    def add(self, *, title: str, domain: str, confidence: float, evidence_ref: str) -> DiscoveryRecord:
        discovery = DiscoveryRecord(title=title, domain=domain, confidence=max(0.0, min(1.0, confidence)), evidence_ref=evidence_ref)
        self.discoveries.append(discovery)
        return discovery
