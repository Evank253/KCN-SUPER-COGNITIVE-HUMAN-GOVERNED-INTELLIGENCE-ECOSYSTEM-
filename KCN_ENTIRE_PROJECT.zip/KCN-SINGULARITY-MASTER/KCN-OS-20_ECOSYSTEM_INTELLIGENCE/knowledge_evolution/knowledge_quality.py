"""Knowledge quality scoring."""

from __future__ import annotations

from typing import Dict


class KnowledgeQualityScorer:
    def score(self, *, source_reputation: float, evidence_strength: float, freshness: float, review_status: bool) -> float:
        score = (source_reputation * 0.3) + (evidence_strength * 0.35) + (freshness * 0.2) + (0.15 if review_status else 0.0)
        return round(max(0.0, min(1.0, score)), 3)
