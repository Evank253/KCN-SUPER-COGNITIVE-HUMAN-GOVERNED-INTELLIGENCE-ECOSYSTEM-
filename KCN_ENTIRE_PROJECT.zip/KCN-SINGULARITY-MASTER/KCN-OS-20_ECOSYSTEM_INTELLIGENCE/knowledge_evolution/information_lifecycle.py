"""Information lifecycle management."""

from __future__ import annotations

from dataclasses import dataclass, field
from uuid import uuid4


@dataclass(frozen=True)
class InformationLifecycleRecord:
    record_id: str
    state: str
    reason: str
    lifecycle_id: str = field(default_factory=lambda: f"KCN-INFOLIFE-{uuid4().hex[:12].upper()}")


class InformationLifecycle:
    VALID_STATES = {"DRAFT", "REVIEW", "APPROVED", "ARCHIVED", "RETIRED"}

    def transition(self, *, record_id: str, state: str, reason: str) -> InformationLifecycleRecord:
        if state not in self.VALID_STATES:
            raise ValueError(f"invalid lifecycle state: {state}")
        return InformationLifecycleRecord(record_id=record_id, state=state, reason=reason)
