"""Knowledge growth tracking."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from uuid import uuid4


@dataclass(frozen=True)
class KnowledgeGrowthRecord:
    domain: str
    records_added: int
    verified_records: int
    growth_id: str = field(default_factory=lambda: f"KCN-KGROWTH-{uuid4().hex[:12].upper()}")
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class KnowledgeGrowthTracker:
    def __init__(self) -> None:
        self.records: list[KnowledgeGrowthRecord] = []

    def record(self, *, domain: str, records_added: int, verified_records: int) -> KnowledgeGrowthRecord:
        item = KnowledgeGrowthRecord(domain=domain, records_added=records_added, verified_records=verified_records)
        self.records.append(item)
        return item

    def verification_ratio(self, domain: str) -> float:
        added = sum(record.records_added for record in self.records if record.domain == domain)
        verified = sum(record.verified_records for record in self.records if record.domain == domain)
        return round(verified / added, 3) if added else 0.0
