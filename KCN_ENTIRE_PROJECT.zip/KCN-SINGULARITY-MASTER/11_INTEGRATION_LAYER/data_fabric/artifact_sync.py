"""Versioned artifact synchronization and hashing."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional
from uuid import uuid4


@dataclass(frozen=True)
class ArtifactRecord:
    name: str
    artifact_type: str
    content_hash: str
    size_bytes: int
    owner: str
    artifact_id: str = field(default_factory=lambda: f"KCN-ART-{uuid4().hex[:12].upper()}")
    version: int = 1
    location: str = "memory://artifact"
    metadata: Dict[str, str] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class ArtifactRepository:
    """In-memory artifact registry.

    Stores metadata and bytes for tests. Production should use object storage and
    retain only signed locations plus hashes in this contract.
    """

    def __init__(self) -> None:
        self._records: Dict[str, ArtifactRecord] = {}
        self._bytes: Dict[str, bytes] = {}
        self._name_latest: Dict[str, str] = {}

    def put(
        self,
        *,
        name: str,
        artifact_type: str,
        data: bytes,
        owner: str,
        metadata: Optional[Dict[str, str]] = None,
    ) -> ArtifactRecord:
        previous_id = self._name_latest.get(name)
        previous = self._records.get(previous_id) if previous_id else None
        version = previous.version + 1 if previous else 1
        artifact_id = f"KCN-ART-{uuid4().hex[:12].upper()}"
        content_hash = "sha256:" + hashlib.sha256(data).hexdigest()
        record = ArtifactRecord(
            artifact_id=artifact_id,
            name=name,
            artifact_type=artifact_type,
            content_hash=content_hash,
            size_bytes=len(data),
            owner=owner,
            version=version,
            location=f"memory://artifact/{artifact_id}",
            metadata=metadata or {},
        )
        self._records[artifact_id] = record
        self._bytes[artifact_id] = data
        self._name_latest[name] = artifact_id
        return record

    def get(self, artifact_id: str) -> Optional[ArtifactRecord]:
        return self._records.get(artifact_id)

    def read_bytes(self, artifact_id: str) -> bytes:
        if artifact_id not in self._bytes:
            raise KeyError(f"unknown artifact: {artifact_id}")
        return self._bytes[artifact_id]

    def latest_by_name(self, name: str) -> Optional[ArtifactRecord]:
        artifact_id = self._name_latest.get(name)
        return self._records.get(artifact_id) if artifact_id else None

    def list(self, *, artifact_type: Optional[str] = None, owner: Optional[str] = None) -> List[ArtifactRecord]:
        records = list(self._records.values())
        if artifact_type:
            records = [record for record in records if record.artifact_type == artifact_type]
        if owner:
            records = [record for record in records if record.owner == owner]
        return sorted(records, key=lambda item: item.created_at)
