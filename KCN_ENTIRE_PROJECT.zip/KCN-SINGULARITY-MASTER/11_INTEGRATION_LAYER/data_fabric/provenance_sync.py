"""Provenance graph for artifact lineage and ownership history."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Iterable, List
from uuid import uuid4


@dataclass(frozen=True)
class ProvenanceEdge:
    child_id: str
    parent_ids: List[str]
    action: str
    actor: str
    edge_id: str = field(default_factory=lambda: f"KCN-PROV-{uuid4().hex[:12].upper()}")
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class ProvenanceGraph:
    def __init__(self) -> None:
        self._edges: Dict[str, ProvenanceEdge] = {}
        self._by_child: Dict[str, List[str]] = {}
        self._by_parent: Dict[str, List[str]] = {}

    def add_lineage(self, *, child_id: str, parent_ids: Iterable[str], action: str, actor: str) -> ProvenanceEdge:
        edge = ProvenanceEdge(child_id=child_id, parent_ids=list(parent_ids), action=action, actor=actor)
        self._edges[edge.edge_id] = edge
        self._by_child.setdefault(child_id, []).append(edge.edge_id)
        for parent_id in edge.parent_ids:
            self._by_parent.setdefault(parent_id, []).append(edge.edge_id)
        return edge

    def parents_of(self, child_id: str) -> List[str]:
        parents: List[str] = []
        for edge_id in self._by_child.get(child_id, []):
            parents.extend(self._edges[edge_id].parent_ids)
        return parents

    def children_of(self, parent_id: str) -> List[str]:
        return [self._edges[edge_id].child_id for edge_id in self._by_parent.get(parent_id, [])]

    def history_for(self, node_id: str) -> List[ProvenanceEdge]:
        edge_ids = set(self._by_child.get(node_id, [])) | set(self._by_parent.get(node_id, []))
        return sorted([self._edges[edge_id] for edge_id in edge_ids], key=lambda item: item.timestamp)
