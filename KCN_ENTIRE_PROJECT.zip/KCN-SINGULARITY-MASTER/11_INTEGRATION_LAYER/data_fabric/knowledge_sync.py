"""Knowledge synchronization across KCN repositories."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Iterable, List, Optional
from uuid import uuid4


@dataclass(frozen=True)
class KnowledgeRecord:
    title: str
    body: str
    source: str
    tags: List[str]
    record_id: str = field(default_factory=lambda: f"KCN-KNOW-{uuid4().hex[:12].upper()}")
    version: int = 1
    content_hash: str = ""
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class KnowledgeSync:
    """Small record store for synchronized knowledge items."""

    def __init__(self) -> None:
        self._records: Dict[str, KnowledgeRecord] = {}

    def upsert(
        self,
        *,
        title: str,
        body: str,
        source: str,
        tags: Optional[Iterable[str]] = None,
        record_id: Optional[str] = None,
    ) -> KnowledgeRecord:
        rid = record_id or f"KCN-KNOW-{uuid4().hex[:12].upper()}"
        previous = self._records.get(rid)
        version = previous.version + 1 if previous else 1
        content_hash = self._hash({"title": title, "body": body, "source": source, "tags": sorted(tags or [])})
        record = KnowledgeRecord(
            record_id=rid,
            title=title,
            body=body,
            source=source,
            tags=sorted(set(tags or [])),
            version=version,
            content_hash=content_hash,
        )
        self._records[rid] = record
        return record

    def get(self, record_id: str) -> Optional[KnowledgeRecord]:
        return self._records.get(record_id)

    def search(self, *, tag: Optional[str] = None, text: Optional[str] = None) -> List[KnowledgeRecord]:
        records = list(self._records.values())
        if tag:
            records = [record for record in records if tag in record.tags]
        if text:
            lowered = text.lower()
            records = [record for record in records if lowered in record.title.lower() or lowered in record.body.lower()]
        return sorted(records, key=lambda item: item.updated_at, reverse=True)

    @staticmethod
    def _hash(payload: dict) -> str:
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()
