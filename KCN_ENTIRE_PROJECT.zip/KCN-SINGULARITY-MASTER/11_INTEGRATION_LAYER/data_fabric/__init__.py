"""Data fabric contracts for KCN Phase 11."""

from .knowledge_sync import KnowledgeRecord, KnowledgeSync
from .artifact_sync import ArtifactRecord, ArtifactRepository
from .provenance_sync import ProvenanceEdge, ProvenanceGraph

__all__ = [
    "KnowledgeRecord",
    "KnowledgeSync",
    "ArtifactRecord",
    "ArtifactRepository",
    "ProvenanceEdge",
    "ProvenanceGraph",
]
