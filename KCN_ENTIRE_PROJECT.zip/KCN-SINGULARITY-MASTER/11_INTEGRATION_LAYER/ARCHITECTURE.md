# KCN Phase 11 Architecture

## Integration Principle

Every package should expose four platform contracts:

1. **Identity contract** — who/what is acting.
2. **Service contract** — what capabilities are available.
3. **Event contract** — what happened and how it is verified.
4. **Artifact/provenance contract** — what was produced and where it came from.

Phase 11 centralizes these contracts without forcing all subsystems into one runtime.

## Core Runtime Planes

### 1. Service Mesh

- `SubsystemRegistry` stores canonical subsystem definitions.
- `ServiceDiscovery` resolves active services by capability, tag, and health.
- `MessageRouter` sends structured messages between subsystems.
- `HealthMonitor` captures heartbeat and health check status.

### 2. Identity Federation

- `UnifiedIdentityProvider` creates platform-wide subjects.
- `PermissionBridge` maps global roles to subsystem-specific permissions.
- `CredentialExchange` issues short-lived HMAC-signed credentials for subsystem calls.

### 3. Event Orchestration

- `GlobalEventBus` is an append-only integrity-chained event recorder.
- `WorkflowScheduler` runs dependency-aware workflows.
- `MissionPipeline` coordinates request → planning → creation → assurance → governance.

### 4. Data Fabric

- `KnowledgeSync` synchronizes knowledge records across repositories.
- `ArtifactSync` synchronizes versioned artifacts with hashes.
- `ProvenanceSync` records lineage and ownership history.

### 5. AI Control Plane

- `AgentRegistry` finds agents by capability.
- `SwarmManager` forms multi-agent teams for missions.
- `ModelRouter` selects models by capability/cost/latency policy.
- `MemoryCoordinator` stores scoped memory records with provenance pointers.

## Production Hardening Concerns

- Replace in-memory stores with durable backing services.
- Enforce mTLS/service credentials at subsystem boundaries.
- Emit events to immutable object storage or a ledger-backed event store.
- Keep personally identifiable information out of event payloads where possible.
- Use policy gates before marketplace publication, external sharing, spending, or irreversible actions.
- Maintain human approval for high-impact decisions.
