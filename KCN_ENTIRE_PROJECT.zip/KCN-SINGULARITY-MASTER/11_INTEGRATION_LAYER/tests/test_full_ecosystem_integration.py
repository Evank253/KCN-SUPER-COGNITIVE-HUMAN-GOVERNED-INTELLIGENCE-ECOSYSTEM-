from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from ai_control_plane import AgentRegistry, MemoryCoordinator, ModelRouter, SwarmManager
from data_fabric import ArtifactRepository, KnowledgeSync, ProvenanceGraph
from event_orchestration import GlobalEventBus, MissionPipeline, WorkflowScheduler
from identity_federation import CredentialExchange, PermissionBridge, UnifiedIdentityProvider
from service_mesh import HealthMonitor, Message, MessageRouter, ServiceDiscovery, SubsystemRegistry


class TestFullEcosystemIntegration(unittest.TestCase):
    def setUp(self) -> None:
        self.registry = SubsystemRegistry()
        self.registry.upsert(
            name="CORE_INTELLIGENCE",
            package="01_CORE_INTELLIGENCE",
            endpoint="memory://core-intelligence",
            capabilities=["intent_analysis", "planning"],
            tags=["core", "intelligence"],
        )
        self.registry.upsert(
            name="CREATION_ENGINE",
            package="03_CREATION_ENGINE",
            endpoint="memory://creation-engine",
            capabilities=["cad", "bim", "energy_simulation", "cost_estimation"],
            tags=["creation"],
        )
        self.registry.upsert(
            name="ASSURANCE_ENGINE",
            package="04_ASSURANCE_ENGINE",
            endpoint="memory://assurance-engine",
            capabilities=["assurance"],
            tags=["assurance"],
        )
        self.registry.upsert(
            name="GOVERNANCE_ENGINE",
            package="05_GOVERNANCE_ENGINE",
            endpoint="memory://governance-engine",
            capabilities=["governance"],
            tags=["governance"],
        )

        self.health = HealthMonitor()
        for subsystem in self.registry.list():
            self.health.heartbeat(subsystem.name, status="HEALTHY")

        self.discovery = ServiceDiscovery(self.registry, self.health)
        self.router = MessageRouter(self.discovery)
        self.router.register_handler("CORE_INTELLIGENCE", self._core_handler)
        self.router.register_handler("CREATION_ENGINE", self._creation_handler)
        self.router.register_handler("ASSURANCE_ENGINE", self._assurance_handler)
        self.router.register_handler("GOVERNANCE_ENGINE", self._governance_handler)

        self.event_bus = GlobalEventBus()
        self.agent_registry = AgentRegistry()
        self.agent_registry.register(name="PlannerAgent", capabilities=["planning", "intent_analysis"])
        self.agent_registry.register(name="ArchitectAgent", capabilities=["cad", "bim"])
        self.agent_registry.register(name="EnergyAgent", capabilities=["energy_simulation"])
        self.agent_registry.register(name="CostAgent", capabilities=["cost_estimation"])
        self.agent_registry.register(name="AssuranceAgent", capabilities=["assurance"])
        self.swarm_manager = SwarmManager(self.agent_registry)
        self.artifacts = ArtifactRepository()
        self.provenance = ProvenanceGraph()

    def test_service_mesh_identity_and_credential_exchange(self) -> None:
        identity = UnifiedIdentityProvider()
        requester = identity.create_subject(display_name="Creator One", subject_type="human", roles=["creator"])

        bridge = PermissionBridge()
        bridge.grant_role_permissions(role="creator", subsystem="CREATION_ENGINE", permissions=["mission:create"])
        decision = bridge.authorize(requester, subsystem="CREATION_ENGINE", permission="mission:create")
        self.assertTrue(decision.allowed)

        exchange = CredentialExchange(secret=b"phase11-test-secret-material")
        credential = exchange.issue(
            subject=requester,
            audience="CREATION_ENGINE",
            scopes=["mission:create"],
            ttl_seconds=60,
        )
        payload = exchange.validate(
            credential.token,
            audience="CREATION_ENGINE",
            required_scope="mission:create",
        )
        self.assertEqual(payload["sub"], requester.subject_id)

        service = self.discovery.resolve_one(capability="cad")
        self.assertEqual(service.name, "CREATION_ENGINE")

    def test_global_tracking_and_smart_home_mission(self) -> None:
        pipeline = MissionPipeline(
            event_bus=self.event_bus,
            message_router=self.router,
            agent_registry=self.agent_registry,
            swarm_manager=self.swarm_manager,
            artifact_repository=self.artifacts,
            provenance_graph=self.provenance,
        )

        result = pipeline.run_creation_mission(
            user_request="Design a sustainable smart home.",
            requester_id="KCN-ID-TEST-CREATOR",
            require_human_approval=True,
        )

        self.assertEqual(result.approval_status, "HUMAN_REVIEW_REQUIRED")
        self.assertEqual(result.integrity_status, "VALID")
        self.assertEqual(set(result.artifacts), {"cad", "bim", "energy_simulation", "cost_estimation"})
        self.assertTrue(self.event_bus.verify_integrity())

        cad_record = self.artifacts.get(result.artifacts["cad"])
        self.assertIsNotNone(cad_record)
        self.assertTrue(cad_record.content_hash.startswith("sha256:"))
        self.assertIn(result.mission_id, self.provenance.parents_of(cad_record.artifact_id))

        actions = [event.action for event in self.event_bus.list_events(tag=result.mission_id)]
        self.assertIn("CAD_MODEL_CREATED", actions)
        self.assertIn("ENERGY_SIMULATION_COMPLETED", actions)
        self.assertIn("GOVERNANCE_REVIEW_RECORDED", actions)
        self.assertIn("TRUST_INTEGRITY_RECORD_CREATED", actions)

    def test_workflow_data_and_memory_planes(self) -> None:
        scheduler = WorkflowScheduler(event_bus=self.event_bus)
        scheduler.add_task("01", "Analyze idea", lambda ctx: {"intent": "sustainable smart home"})
        scheduler.add_task(
            "02",
            "Create learning path",
            lambda ctx: {"modules": ["passive design", "solar sizing", "BIM basics"]},
            depends_on=["01"],
        )
        results = scheduler.execute()
        self.assertEqual([result.status for result in results], ["COMPLETED", "COMPLETED"])

        knowledge = KnowledgeSync()
        record = knowledge.upsert(
            title="Sustainable Smart Home Pattern",
            body="Use passive solar orientation, tight envelope, heat pump, and energy monitoring.",
            source="KCN-CreatorOS",
            tags=["smart-home", "sustainability"],
        )
        self.assertEqual(knowledge.search(tag="smart-home")[0].record_id, record.record_id)

        memory = MemoryCoordinator()
        item = memory.remember(
            scope="creator:portfolio",
            content="User prefers sustainable residential design with human approval gates.",
            owner="KCN-ID-TEST-CREATOR",
            tags=["preference", "approval"],
            provenance_id=record.record_id,
        )
        recalled = memory.recall(scope="creator:portfolio", tag="approval")
        self.assertEqual(recalled[0].memory_id, item.memory_id)

        models = ModelRouter()
        models.register(
            name="DesignReasoner-A",
            provider="internal",
            capabilities=["planning", "design_review"],
            endpoint="memory://model/design-reasoner-a",
            cost_rank=2,
            latency_rank=3,
            quality_rank=8,
        )
        chosen = models.route(capability="planning", policy="highest_quality")
        self.assertEqual(chosen.name, "DesignReasoner-A")

    @staticmethod
    def _core_handler(message: Message) -> dict:
        return {
            "agent": "PlannerAgent",
            "plan_id": "PLAN-SMART-HOME-001",
            "tasks": ["cad", "bim", "energy_simulation", "cost_estimation"],
            "reasoning_summary": "The request requires architectural design, building model, energy analysis, and cost analysis.",
        }

    @staticmethod
    def _creation_handler(message: Message) -> dict:
        capability = message.payload.get("capability", message.target_capability)
        return {
            "agent": {
                "cad": "ArchitectAgent",
                "bim": "ArchitectAgent",
                "energy_simulation": "EnergyAgent",
                "cost_estimation": "CostAgent",
            }.get(capability, "CreationAgent"),
            "artifact_type": capability,
            "mission_id": message.payload.get("mission_id"),
            "status": "created",
            "summary": f"Generated {capability} output for sustainable smart home mission.",
        }

    @staticmethod
    def _assurance_handler(message: Message) -> dict:
        return {
            "agent": "AssuranceAgent",
            "status": "passed",
            "checks": ["hash_present", "provenance_linked", "approval_gate_present"],
        }

    @staticmethod
    def _governance_handler(message: Message) -> dict:
        return {"agent": "GovernanceAgent", "status": "human_review_required"}


if __name__ == "__main__":
    unittest.main()
