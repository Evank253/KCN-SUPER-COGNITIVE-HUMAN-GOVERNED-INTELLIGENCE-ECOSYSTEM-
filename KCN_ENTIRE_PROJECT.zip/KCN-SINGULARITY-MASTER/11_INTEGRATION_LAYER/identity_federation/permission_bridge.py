"""Map global KCN roles to subsystem permissions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Set

from .unified_identity import IdentitySubject


@dataclass(frozen=True)
class PermissionDecision:
    allowed: bool
    subject_id: str
    subsystem: str
    permission: str
    reason: str


class PermissionBridge:
    """Role/permission bridge between the global identity plane and packages."""

    def __init__(self) -> None:
        self._role_permissions: Dict[str, Dict[str, Set[str]]] = {}

    def grant_role_permissions(self, *, role: str, subsystem: str, permissions: Iterable[str]) -> None:
        self._role_permissions.setdefault(role, {}).setdefault(subsystem, set()).update(permissions)

    def permissions_for(self, subject: IdentitySubject, subsystem: str) -> Set[str]:
        effective: Set[str] = set()
        for role in subject.roles:
            effective.update(self._role_permissions.get(role, {}).get(subsystem, set()))
            effective.update(self._role_permissions.get(role, {}).get("*", set()))
        return effective

    def authorize(self, subject: IdentitySubject, *, subsystem: str, permission: str) -> PermissionDecision:
        permissions = self.permissions_for(subject, subsystem)
        wildcard = "*" in permissions
        allowed = wildcard or permission in permissions
        return PermissionDecision(
            allowed=allowed,
            subject_id=subject.subject_id,
            subsystem=subsystem,
            permission=permission,
            reason="role permission matched" if allowed else "no matching permission",
        )
