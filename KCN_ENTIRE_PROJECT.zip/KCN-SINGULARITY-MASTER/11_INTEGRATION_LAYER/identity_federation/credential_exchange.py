"""Short-lived credential exchange for subsystem-to-subsystem calls.

This scaffold uses HMAC from the Python standard library. Production should use
an enterprise identity provider, JWKS rotation, mTLS, and auditable key custody.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Iterable, List

from .unified_identity import IdentitySubject


@dataclass(frozen=True)
class ExchangedCredential:
    token: str
    subject_id: str
    audience: str
    scopes: List[str]
    expires_at: str


class CredentialExchange:
    def __init__(self, secret: bytes) -> None:
        if len(secret) < 16:
            raise ValueError("credential exchange secret must be at least 16 bytes")
        self.secret = secret

    def issue(
        self,
        *,
        subject: IdentitySubject,
        audience: str,
        scopes: Iterable[str],
        ttl_seconds: int = 900,
    ) -> ExchangedCredential:
        expires_at = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)
        payload = {
            "sub": subject.subject_id,
            "aud": audience,
            "scopes": sorted(set(scopes)),
            "exp": int(expires_at.timestamp()),
        }
        token = self._encode(payload)
        return ExchangedCredential(
            token=token,
            subject_id=subject.subject_id,
            audience=audience,
            scopes=payload["scopes"],
            expires_at=expires_at.isoformat(),
        )

    def validate(self, token: str, *, audience: str, required_scope: str | None = None) -> dict:
        payload = self._decode(token)
        if payload.get("aud") != audience:
            raise PermissionError("credential audience mismatch")
        if datetime.now(timezone.utc).timestamp() > int(payload.get("exp", 0)):
            raise PermissionError("credential expired")
        scopes = set(payload.get("scopes", []))
        if required_scope and required_scope not in scopes and "*" not in scopes:
            raise PermissionError("credential missing required scope")
        return payload

    def _encode(self, payload: dict) -> str:
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        body = base64.urlsafe_b64encode(raw).rstrip(b"=")
        signature = hmac.new(self.secret, body, hashlib.sha256).digest()
        sig = base64.urlsafe_b64encode(signature).rstrip(b"=")
        return f"{body.decode()}.{sig.decode()}"

    def _decode(self, token: str) -> dict:
        try:
            body, sig = token.split(".", 1)
        except ValueError as exc:
            raise PermissionError("malformed credential") from exc
        expected = base64.urlsafe_b64encode(
            hmac.new(self.secret, body.encode(), hashlib.sha256).digest()
        ).rstrip(b"=").decode()
        if not hmac.compare_digest(sig, expected):
            raise PermissionError("credential signature invalid")
        padded = body + "=" * (-len(body) % 4)
        return json.loads(base64.urlsafe_b64decode(padded.encode()).decode("utf-8"))
