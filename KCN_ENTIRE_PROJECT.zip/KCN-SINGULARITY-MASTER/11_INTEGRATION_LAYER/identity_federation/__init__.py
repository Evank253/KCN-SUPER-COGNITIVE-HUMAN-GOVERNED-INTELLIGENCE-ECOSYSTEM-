"""Identity federation contracts for KCN Phase 11."""

from .unified_identity import IdentitySubject, UnifiedIdentityProvider
from .permission_bridge import PermissionBridge, PermissionDecision
from .credential_exchange import CredentialExchange, ExchangedCredential

__all__ = [
    "IdentitySubject",
    "UnifiedIdentityProvider",
    "PermissionBridge",
    "PermissionDecision",
    "CredentialExchange",
    "ExchangedCredential",
]
