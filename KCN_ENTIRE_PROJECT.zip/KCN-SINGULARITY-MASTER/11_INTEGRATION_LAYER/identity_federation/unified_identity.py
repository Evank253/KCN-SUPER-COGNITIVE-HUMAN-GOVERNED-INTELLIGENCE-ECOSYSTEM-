"""Unified identity model for users, services, and agents."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Iterable, Optional, Set
from uuid import uuid4


@dataclass(frozen=True)
class IdentitySubject:
    display_name: str
    subject_type: str
    roles: Set[str]
    subject_id: str = field(default_factory=lambda: f"KCN-ID-{uuid4().hex[:12].upper()}")
    email: Optional[str] = None
    attributes: Dict[str, str] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    active: bool = True


class UnifiedIdentityProvider:
    """Creates and resolves platform-wide identities."""

    VALID_TYPES = {"human", "agent", "service", "organization"}

    def __init__(self) -> None:
        self._subjects: Dict[str, IdentitySubject] = {}
        self._display_index: Dict[str, str] = {}

    def create_subject(
        self,
        *,
        display_name: str,
        subject_type: str,
        roles: Iterable[str],
        email: Optional[str] = None,
        attributes: Optional[Dict[str, str]] = None,
    ) -> IdentitySubject:
        if subject_type not in self.VALID_TYPES:
            raise ValueError(f"invalid subject_type: {subject_type}")
        if display_name in self._display_index:
            raise ValueError(f"identity already exists: {display_name}")

        subject = IdentitySubject(
            display_name=display_name,
            subject_type=subject_type,
            roles=set(roles),
            email=email,
            attributes=attributes or {},
        )
        self._subjects[subject.subject_id] = subject
        self._display_index[display_name] = subject.subject_id
        return subject

    def get(self, subject_id_or_name: str) -> Optional[IdentitySubject]:
        subject_id = self._display_index.get(subject_id_or_name, subject_id_or_name)
        return self._subjects.get(subject_id)

    def require(self, subject_id_or_name: str) -> IdentitySubject:
        subject = self.get(subject_id_or_name)
        if subject is None:
            raise KeyError(f"unknown subject: {subject_id_or_name}")
        return subject

    def has_role(self, subject_id_or_name: str, role: str) -> bool:
        return role in self.require(subject_id_or_name).roles
