"""Canonical registry for KCN ecosystem subsystems.

The registry is deliberately dependency-free so it can be used by tests,
local developer environments, and production adapters.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Set
from uuid import uuid4


@dataclass(frozen=True)
class Subsystem:
    """A KCN subsystem or service exposed to the integration layer."""

    name: str
    package: str
    endpoint: str
    capabilities: Set[str]
    subsystem_id: str = field(default_factory=lambda: f"KCN-SUBSYS-{uuid4().hex[:12].upper()}")
    version: str = "0.1.0"
    tags: Set[str] = field(default_factory=set)
    owner: str = "kcn-platform"
    metadata: Dict[str, Any] = field(default_factory=dict)
    registered_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    active: bool = True

    def supports(self, capability: str) -> bool:
        return capability in self.capabilities


class SubsystemRegistry:
    """In-memory subsystem catalog.

    Production deployments can wrap this class with a persistent adapter backed by
    a database, service catalog, or Kubernetes API.
    """

    def __init__(self) -> None:
        self._subsystems: Dict[str, Subsystem] = {}
        self._name_index: Dict[str, str] = {}

    def register(self, subsystem: Subsystem, *, replace: bool = False) -> Subsystem:
        if subsystem.name in self._name_index and not replace:
            raise ValueError(f"subsystem already registered: {subsystem.name}")

        old_id = self._name_index.get(subsystem.name)
        if old_id and replace:
            self._subsystems.pop(old_id, None)

        self._subsystems[subsystem.subsystem_id] = subsystem
        self._name_index[subsystem.name] = subsystem.subsystem_id
        return subsystem

    def upsert(
        self,
        *,
        name: str,
        package: str,
        endpoint: str,
        capabilities: Iterable[str],
        version: str = "0.1.0",
        tags: Optional[Iterable[str]] = None,
        owner: str = "kcn-platform",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Subsystem:
        subsystem = Subsystem(
            name=name,
            package=package,
            endpoint=endpoint,
            capabilities=set(capabilities),
            version=version,
            tags=set(tags or []),
            owner=owner,
            metadata=metadata or {},
        )
        return self.register(subsystem, replace=name in self._name_index)

    def get(self, subsystem_id_or_name: str) -> Optional[Subsystem]:
        subsystem_id = self._name_index.get(subsystem_id_or_name, subsystem_id_or_name)
        return self._subsystems.get(subsystem_id)

    def require(self, subsystem_id_or_name: str) -> Subsystem:
        subsystem = self.get(subsystem_id_or_name)
        if subsystem is None:
            raise KeyError(f"unknown subsystem: {subsystem_id_or_name}")
        return subsystem

    def deactivate(self, subsystem_id_or_name: str) -> Subsystem:
        subsystem = self.require(subsystem_id_or_name)
        updated = Subsystem(
            subsystem_id=subsystem.subsystem_id,
            name=subsystem.name,
            package=subsystem.package,
            endpoint=subsystem.endpoint,
            capabilities=set(subsystem.capabilities),
            version=subsystem.version,
            tags=set(subsystem.tags),
            owner=subsystem.owner,
            metadata=dict(subsystem.metadata),
            registered_at=subsystem.registered_at,
            active=False,
        )
        self._subsystems[subsystem.subsystem_id] = updated
        return updated

    def list(self, *, active_only: bool = False) -> List[Subsystem]:
        values = list(self._subsystems.values())
        if active_only:
            values = [item for item in values if item.active]
        return sorted(values, key=lambda item: item.name)

    def find_by_capability(self, capability: str, *, active_only: bool = True) -> List[Subsystem]:
        return [
            subsystem
            for subsystem in self.list(active_only=active_only)
            if subsystem.supports(capability)
        ]

    def find_by_tag(self, tag: str, *, active_only: bool = True) -> List[Subsystem]:
        return [subsystem for subsystem in self.list(active_only=active_only) if tag in subsystem.tags]
