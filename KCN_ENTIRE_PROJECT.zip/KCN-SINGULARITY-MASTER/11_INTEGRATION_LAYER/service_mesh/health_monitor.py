"""Health monitoring primitives for the KCN service mesh."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Dict, List, Optional


HealthCheck = Callable[[], bool]


@dataclass
class HealthReport:
    subsystem: str
    status: str
    checked_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    detail: str = ""
    latency_ms: Optional[float] = None


class HealthMonitor:
    """Tracks current subsystem health.

    Status values:
    - UNKNOWN: no report yet
    - HEALTHY: check succeeded
    - DEGRADED: heartbeat reported partial functionality
    - UNHEALTHY: check failed
    """

    def __init__(self) -> None:
        self._checks: Dict[str, HealthCheck] = {}
        self._reports: Dict[str, HealthReport] = {}

    def register_check(self, subsystem: str, check: HealthCheck) -> None:
        self._checks[subsystem] = check

    def heartbeat(self, subsystem: str, *, status: str = "HEALTHY", detail: str = "") -> HealthReport:
        if status not in {"HEALTHY", "DEGRADED", "UNHEALTHY", "UNKNOWN"}:
            raise ValueError(f"invalid health status: {status}")
        report = HealthReport(subsystem=subsystem, status=status, detail=detail)
        self._reports[subsystem] = report
        return report

    def run_check(self, subsystem: str) -> HealthReport:
        check = self._checks.get(subsystem)
        if check is None:
            report = HealthReport(subsystem=subsystem, status="UNKNOWN", detail="no check registered")
            self._reports[subsystem] = report
            return report

        started = datetime.now(timezone.utc)
        try:
            ok = bool(check())
            status = "HEALTHY" if ok else "UNHEALTHY"
            detail = "check passed" if ok else "check failed"
        except Exception as exc:  # pragma: no cover - defensive path
            status = "UNHEALTHY"
            detail = f"check raised {exc.__class__.__name__}: {exc}"
        finished = datetime.now(timezone.utc)
        latency = (finished - started).total_seconds() * 1000
        report = HealthReport(subsystem=subsystem, status=status, detail=detail, latency_ms=latency)
        self._reports[subsystem] = report
        return report

    def run_all(self) -> List[HealthReport]:
        return [self.run_check(name) for name in sorted(self._checks)]

    def status_for(self, subsystem: str) -> str:
        return self._reports.get(subsystem, HealthReport(subsystem=subsystem, status="UNKNOWN")).status

    def report_for(self, subsystem: str) -> HealthReport:
        return self._reports.get(subsystem, HealthReport(subsystem=subsystem, status="UNKNOWN"))
