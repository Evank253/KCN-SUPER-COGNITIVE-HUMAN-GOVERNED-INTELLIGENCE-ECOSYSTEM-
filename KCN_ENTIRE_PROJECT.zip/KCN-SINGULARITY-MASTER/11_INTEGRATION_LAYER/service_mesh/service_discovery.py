"""Service discovery for capability-based routing."""

from __future__ import annotations

from typing import Iterable, List, Optional

from .health_monitor import HealthMonitor
from .subsystem_registry import Subsystem, SubsystemRegistry


class ServiceDiscovery:
    """Resolve services from the registry using platform routing constraints."""

    def __init__(self, registry: SubsystemRegistry, health_monitor: Optional[HealthMonitor] = None) -> None:
        self.registry = registry
        self.health_monitor = health_monitor

    def discover(
        self,
        *,
        capability: Optional[str] = None,
        tags: Optional[Iterable[str]] = None,
        require_healthy: bool = True,
    ) -> List[Subsystem]:
        services = self.registry.list(active_only=True)

        if capability:
            services = [service for service in services if capability in service.capabilities]

        required_tags = set(tags or [])
        if required_tags:
            services = [service for service in services if required_tags.issubset(service.tags)]

        if require_healthy and self.health_monitor:
            services = [
                service
                for service in services
                if self.health_monitor.status_for(service.name) in {"HEALTHY", "DEGRADED"}
            ]

        return services

    def resolve_one(self, *, capability: str, tags: Optional[Iterable[str]] = None) -> Subsystem:
        candidates = self.discover(capability=capability, tags=tags, require_healthy=True)
        if not candidates:
            raise LookupError(f"no healthy service found for capability: {capability}")
        # Deterministic strategy: prefer most tags, then lexical name.
        return sorted(candidates, key=lambda service: (-len(service.tags), service.name))[0]
