"""Structured inter-subsystem message routing."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4

from .service_discovery import ServiceDiscovery

MessageHandler = Callable[["Message"], Dict[str, Any]]


@dataclass(frozen=True)
class Message:
    action: str
    source: str
    target_capability: str
    payload: Dict[str, Any]
    message_id: str = field(default_factory=lambda: f"KCN-MSG-{uuid4().hex[:12].upper()}")
    correlation_id: str = field(default_factory=lambda: f"KCN-CORR-{uuid4().hex[:12].upper()}")
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    priority: int = 5


@dataclass(frozen=True)
class RouteResult:
    message_id: str
    target_subsystem: str
    accepted: bool
    response: Dict[str, Any]


class MessageRouter:
    """Routes messages by target capability.

    Handlers are local callables in this scaffold. A production adapter can map
    the selected subsystem to HTTP, gRPC, queue, or event-bus transports.
    """

    def __init__(self, discovery: ServiceDiscovery) -> None:
        self.discovery = discovery
        self._handlers: Dict[str, MessageHandler] = {}
        self._dead_letters: List[Message] = []

    def register_handler(self, subsystem_name: str, handler: MessageHandler) -> None:
        self._handlers[subsystem_name] = handler

    @property
    def dead_letters(self) -> List[Message]:
        return list(self._dead_letters)

    def route(self, message: Message) -> RouteResult:
        target = self.discovery.resolve_one(capability=message.target_capability)
        handler = self._handlers.get(target.name)
        if handler is None:
            self._dead_letters.append(message)
            return RouteResult(
                message_id=message.message_id,
                target_subsystem=target.name,
                accepted=False,
                response={"error": "no handler registered", "endpoint": target.endpoint},
            )

        response = handler(message)
        return RouteResult(
            message_id=message.message_id,
            target_subsystem=target.name,
            accepted=True,
            response=response,
        )
