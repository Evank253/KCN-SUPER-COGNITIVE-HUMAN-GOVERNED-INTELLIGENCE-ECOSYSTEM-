"""Service mesh contracts for KCN Phase 11."""

from .subsystem_registry import Subsystem, SubsystemRegistry
from .service_discovery import ServiceDiscovery
from .message_router import Message, MessageRouter, RouteResult
from .health_monitor import HealthMonitor, HealthReport

__all__ = [
    "Subsystem",
    "SubsystemRegistry",
    "ServiceDiscovery",
    "Message",
    "MessageRouter",
    "RouteResult",
    "HealthMonitor",
    "HealthReport",
]
