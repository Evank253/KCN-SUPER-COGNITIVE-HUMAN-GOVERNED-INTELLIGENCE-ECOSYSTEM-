"""Mission pipeline connecting intelligence, creation, assurance, governance, and trust."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional
from uuid import uuid4

from ai_control_plane.agent_registry import AgentRegistry
from ai_control_plane.swarm_manager import SwarmManager
from data_fabric.artifact_sync import ArtifactRepository
from data_fabric.provenance_sync import ProvenanceGraph
from service_mesh.message_router import Message, MessageRouter

from .global_event_bus import GlobalEventBus


@dataclass(frozen=True)
class MissionResult:
    mission_id: str
    user_request: str
    artifacts: Dict[str, str]
    approval_status: str
    integrity_status: str
    event_count: int
    completed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class MissionPipeline:
    """Coordinates the canonical KCN creation flow.

    It records high-level, auditable summaries of each phase. It avoids requiring
    hidden chain-of-thought storage while preserving platform accountability.
    """

    def __init__(
        self,
        *,
        event_bus: GlobalEventBus,
        message_router: MessageRouter,
        agent_registry: AgentRegistry,
        swarm_manager: SwarmManager,
        artifact_repository: ArtifactRepository,
        provenance_graph: ProvenanceGraph,
    ) -> None:
        self.event_bus = event_bus
        self.message_router = message_router
        self.agent_registry = agent_registry
        self.swarm_manager = swarm_manager
        self.artifact_repository = artifact_repository
        self.provenance_graph = provenance_graph

    def run_creation_mission(self, *, user_request: str, requester_id: str, require_human_approval: bool = True) -> MissionResult:
        mission_id = f"KCN-MISSION-{uuid4().hex[:10].upper()}"
        self.event_bus.publish(
            action="USER_REQUEST_RECEIVED",
            actor=requester_id,
            payload={"mission_id": mission_id, "request": user_request},
            approval_status="VERIFIED",
            tags=["mission", mission_id],
        )

        planning_agent = self.agent_registry.require_capability("planning")
        creation_swarm = self.swarm_manager.form_swarm(
            mission_id=mission_id,
            required_capabilities=["cad", "bim", "energy_simulation", "cost_estimation"],
        )
        self.event_bus.publish(
            action="AGENT_ASSIGNMENTS_CREATED",
            actor="SwarmManager",
            payload={
                "mission_id": mission_id,
                "planning_agent": planning_agent.name,
                "creation_agents": [agent.name for agent in creation_swarm],
            },
            approval_status="VERIFIED",
            tags=["mission", mission_id, "agents"],
        )

        plan = self._route_phase(
            mission_id=mission_id,
            source="CORE_INTELLIGENCE",
            target_capability="planning",
            action="MISSION_PLAN_REQUESTED",
            payload={"request": user_request, "reasoning_summary": "Translate user intent into creation tasks."},
        )

        artifact_ids: Dict[str, str] = {}
        for capability, action in [
            ("cad", "CAD_MODEL_CREATED"),
            ("bim", "BIM_MODEL_CREATED"),
            ("energy_simulation", "ENERGY_SIMULATION_COMPLETED"),
            ("cost_estimation", "COST_ESTIMATE_CREATED"),
        ]:
            response = self._route_phase(
                mission_id=mission_id,
                source="CREATION_ENGINE",
                target_capability=capability,
                action=action,
                payload={"mission_id": mission_id, "plan": plan, "capability": capability},
            )
            artifact_bytes = json.dumps(response, sort_keys=True).encode("utf-8")
            artifact = self.artifact_repository.put(
                name=f"{mission_id}-{capability}",
                artifact_type=capability,
                data=artifact_bytes,
                owner=requester_id,
                metadata={"mission_id": mission_id},
            )
            artifact_ids[capability] = artifact.artifact_id
            self.provenance_graph.add_lineage(
                child_id=artifact.artifact_id,
                parent_ids=[mission_id],
                action=action,
                actor=response.get("agent", "unknown-agent"),
            )
            self.event_bus.publish(
                action=action,
                actor=response.get("agent", "CreationAgent"),
                payload={"mission_id": mission_id, "artifact_id": artifact.artifact_id, "version": artifact.version},
                artifact_hash=artifact.content_hash,
                approval_status="VERIFIED",
                tags=["mission", mission_id, "artifact"],
            )

        assurance = self._route_phase(
            mission_id=mission_id,
            source="ASSURANCE_ENGINE",
            target_capability="assurance",
            action="ASSURANCE_CHECK_COMPLETED",
            payload={"mission_id": mission_id, "artifacts": artifact_ids},
        )
        governance_status = "HUMAN_REVIEW_REQUIRED" if require_human_approval else "VERIFIED"
        governance_payload = {
            "mission_id": mission_id,
            "assurance": assurance,
            "human_approval_required": require_human_approval,
        }
        governance_hash = self._hash_payload(governance_payload)
        self.event_bus.publish(
            action="GOVERNANCE_REVIEW_RECORDED",
            actor="GOVERNANCE_ENGINE",
            payload=governance_payload,
            approval_status=governance_status,
            artifact_hash=governance_hash,
            tags=["mission", mission_id, "governance"],
        )
        integrity_status = "VALID" if self.event_bus.verify_integrity() else "INVALID"
        self.event_bus.publish(
            action="TRUST_INTEGRITY_RECORD_CREATED",
            actor="TRUST_ENGINE",
            payload={"mission_id": mission_id, "artifact_ids": artifact_ids},
            approval_status="VERIFIED",
            artifact_hash=governance_hash,
            tags=["mission", mission_id, "trust"],
        )

        return MissionResult(
            mission_id=mission_id,
            user_request=user_request,
            artifacts=artifact_ids,
            approval_status=governance_status,
            integrity_status=integrity_status,
            event_count=len(self.event_bus.list_events(tag=mission_id)),
        )

    def _route_phase(self, *, mission_id: str, source: str, target_capability: str, action: str, payload: dict) -> dict:
        message = Message(action=action, source=source, target_capability=target_capability, payload=payload)
        result = self.message_router.route(message)
        self.event_bus.publish(
            action=f"{action}_ROUTED",
            actor="MessageRouter",
            payload={
                "mission_id": mission_id,
                "message_id": message.message_id,
                "target_subsystem": result.target_subsystem,
                "accepted": result.accepted,
            },
            approval_status="VERIFIED" if result.accepted else "REJECTED",
            tags=["mission", mission_id, "routing"],
        )
        if not result.accepted:
            raise RuntimeError(f"route rejected for {action}: {result.response}")
        return result.response

    @staticmethod
    def _hash_payload(payload: dict) -> str:
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()
