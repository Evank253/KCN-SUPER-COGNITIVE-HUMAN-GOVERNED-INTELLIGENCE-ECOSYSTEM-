"""Ecosystem-wide event recorder with hash-chain integrity."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Iterable, List, Optional

Subscriber = Callable[["EventRecord"], None]


@dataclass(frozen=True)
class EventRecord:
    event_id: str
    action: str
    actor: str
    payload: Dict[str, Any]
    timestamp: str
    approval_status: str = "PENDING"
    integrity_status: str = "VALID"
    artifact_hash: Optional[str] = None
    previous_hash: Optional[str] = None
    event_hash: str = ""
    tags: List[str] = field(default_factory=list)


class GlobalEventBus:
    """Append-only event log plus pub/sub fanout.

    The event hash chains each event to the previous event. This provides a
    lightweight tamper-evidence primitive for the integration scaffold.
    """

    def __init__(self, event_prefix: str = "KCN-EVENT") -> None:
        self.event_prefix = event_prefix
        self._events: List[EventRecord] = []
        self._subscribers: Dict[str, List[Subscriber]] = {}
        self._global_subscribers: List[Subscriber] = []

    def publish(
        self,
        *,
        action: str,
        actor: str,
        payload: Optional[Dict[str, Any]] = None,
        approval_status: str = "PENDING",
        artifact_hash: Optional[str] = None,
        tags: Optional[Iterable[str]] = None,
    ) -> EventRecord:
        event_id = f"{self.event_prefix}-{len(self._events) + 1:06d}"
        previous_hash = self._events[-1].event_hash if self._events else None
        base = EventRecord(
            event_id=event_id,
            action=action,
            actor=actor,
            payload=payload or {},
            timestamp=datetime.now(timezone.utc).isoformat(),
            approval_status=approval_status,
            artifact_hash=artifact_hash,
            previous_hash=previous_hash,
            tags=list(tags or []),
        )
        event_hash = self._hash_event(base)
        event = EventRecord(**{**asdict(base), "event_hash": event_hash})
        self._events.append(event)
        self._fanout(event)
        return event

    def subscribe(self, action: str, callback: Subscriber) -> None:
        self._subscribers.setdefault(action, []).append(callback)

    def subscribe_all(self, callback: Subscriber) -> None:
        self._global_subscribers.append(callback)

    def list_events(self, *, action: Optional[str] = None, tag: Optional[str] = None) -> List[EventRecord]:
        events = list(self._events)
        if action:
            events = [event for event in events if event.action == action]
        if tag:
            events = [event for event in events if tag in event.tags]
        return events

    def latest(self) -> Optional[EventRecord]:
        return self._events[-1] if self._events else None

    def verify_integrity(self) -> bool:
        previous_hash = None
        for event in self._events:
            expected_hash = self._hash_event(EventRecord(**{**asdict(event), "event_hash": ""}))
            if event.previous_hash != previous_hash or event.event_hash != expected_hash:
                return False
            previous_hash = event.event_hash
        return True

    def to_jsonl(self) -> str:
        return "\n".join(json.dumps(asdict(event), sort_keys=True) for event in self._events)

    def _fanout(self, event: EventRecord) -> None:
        for callback in self._global_subscribers:
            callback(event)
        for callback in self._subscribers.get(event.action, []):
            callback(event)

    @staticmethod
    def _hash_event(event: EventRecord) -> str:
        data = asdict(event)
        data["event_hash"] = ""
        canonical = json.dumps(data, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()
