"""Dependency-aware workflow scheduler for integration missions."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Dict, Iterable, List, Optional, Set

from .global_event_bus import GlobalEventBus

TaskFn = Callable[[dict], dict]


@dataclass(frozen=True)
class WorkflowTask:
    task_id: str
    name: str
    run: TaskFn
    depends_on: Set[str] = field(default_factory=set)


@dataclass(frozen=True)
class TaskResult:
    task_id: str
    name: str
    status: str
    output: dict
    completed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class WorkflowScheduler:
    """Simple topological workflow executor.

    This is intentionally synchronous and deterministic. Distributed execution
    systems can preserve this task contract while running jobs on workers.
    """

    def __init__(self, event_bus: Optional[GlobalEventBus] = None) -> None:
        self.event_bus = event_bus
        self._tasks: Dict[str, WorkflowTask] = {}

    def add_task(self, task_id: str, name: str, run: TaskFn, *, depends_on: Optional[Iterable[str]] = None) -> None:
        if task_id in self._tasks:
            raise ValueError(f"task already exists: {task_id}")
        self._tasks[task_id] = WorkflowTask(task_id=task_id, name=name, run=run, depends_on=set(depends_on or []))

    def execute(self, initial_context: Optional[dict] = None) -> List[TaskResult]:
        context = dict(initial_context or {})
        completed: Set[str] = set()
        results: List[TaskResult] = []

        while len(completed) < len(self._tasks):
            ready = [
                task
                for task in self._tasks.values()
                if task.task_id not in completed and task.depends_on.issubset(completed)
            ]
            if not ready:
                missing = set(self._tasks) - completed
                raise RuntimeError(f"workflow dependency cycle or missing dependency: {sorted(missing)}")

            for task in sorted(ready, key=lambda item: item.task_id):
                if self.event_bus:
                    self.event_bus.publish(
                        action="WORKFLOW_TASK_STARTED",
                        actor="WorkflowScheduler",
                        payload={"task_id": task.task_id, "name": task.name},
                        approval_status="VERIFIED",
                        tags=["workflow"],
                    )
                output = task.run(context)
                context[task.task_id] = output
                result = TaskResult(task_id=task.task_id, name=task.name, status="COMPLETED", output=output)
                results.append(result)
                completed.add(task.task_id)
                if self.event_bus:
                    self.event_bus.publish(
                        action="WORKFLOW_TASK_COMPLETED",
                        actor="WorkflowScheduler",
                        payload={"task_id": task.task_id, "name": task.name, "output": output},
                        approval_status="VERIFIED",
                        tags=["workflow"],
                    )

        return results
