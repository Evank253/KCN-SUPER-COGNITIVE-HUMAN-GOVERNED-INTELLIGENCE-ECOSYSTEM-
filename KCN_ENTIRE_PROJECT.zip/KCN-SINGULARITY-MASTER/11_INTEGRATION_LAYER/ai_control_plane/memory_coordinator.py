"""Scoped AI memory coordination with provenance pointers."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Iterable, List, Optional
from uuid import uuid4


@dataclass(frozen=True)
class MemoryItem:
    scope: str
    content: str
    owner: str
    tags: List[str]
    memory_id: str = field(default_factory=lambda: f"KCN-MEM-{uuid4().hex[:12].upper()}")
    provenance_id: Optional[str] = None
    content_hash: str = ""
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class MemoryCoordinator:
    def __init__(self) -> None:
        self._items: Dict[str, MemoryItem] = {}

    def remember(
        self,
        *,
        scope: str,
        content: str,
        owner: str,
        tags: Optional[Iterable[str]] = None,
        provenance_id: Optional[str] = None,
    ) -> MemoryItem:
        payload = {"scope": scope, "content": content, "owner": owner, "tags": sorted(tags or []), "provenance_id": provenance_id}
        content_hash = "sha256:" + hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        item = MemoryItem(
            scope=scope,
            content=content,
            owner=owner,
            tags=sorted(set(tags or [])),
            provenance_id=provenance_id,
            content_hash=content_hash,
        )
        self._items[item.memory_id] = item
        return item

    def recall(self, *, scope: str, tag: Optional[str] = None, text: Optional[str] = None) -> List[MemoryItem]:
        items = [item for item in self._items.values() if item.scope == scope]
        if tag:
            items = [item for item in items if tag in item.tags]
        if text:
            lowered = text.lower()
            items = [item for item in items if lowered in item.content.lower()]
        return sorted(items, key=lambda item: item.created_at, reverse=True)
