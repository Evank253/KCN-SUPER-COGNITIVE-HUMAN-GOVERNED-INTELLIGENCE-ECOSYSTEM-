"""Registry of AI agents and their capabilities."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Set
from uuid import uuid4


@dataclass(frozen=True)
class AgentSpec:
    name: str
    capabilities: Set[str]
    agent_id: str = field(default_factory=lambda: f"KCN-AGENT-{uuid4().hex[:12].upper()}")
    subsystem: str = "ai_control_plane"
    max_concurrency: int = 1
    metadata: Dict[str, str] = field(default_factory=dict)
    active: bool = True


class AgentRegistry:
    def __init__(self) -> None:
        self._agents: Dict[str, AgentSpec] = {}
        self._name_index: Dict[str, str] = {}

    def register(
        self,
        *,
        name: str,
        capabilities: Iterable[str],
        subsystem: str = "ai_control_plane",
        max_concurrency: int = 1,
        metadata: Optional[Dict[str, str]] = None,
    ) -> AgentSpec:
        if name in self._name_index:
            raise ValueError(f"agent already registered: {name}")
        agent = AgentSpec(
            name=name,
            capabilities=set(capabilities),
            subsystem=subsystem,
            max_concurrency=max_concurrency,
            metadata=metadata or {},
        )
        self._agents[agent.agent_id] = agent
        self._name_index[name] = agent.agent_id
        return agent

    def get(self, agent_id_or_name: str) -> Optional[AgentSpec]:
        agent_id = self._name_index.get(agent_id_or_name, agent_id_or_name)
        return self._agents.get(agent_id)

    def find_by_capability(self, capability: str) -> List[AgentSpec]:
        return sorted(
            [agent for agent in self._agents.values() if agent.active and capability in agent.capabilities],
            key=lambda item: item.name,
        )

    def require_capability(self, capability: str) -> AgentSpec:
        agents = self.find_by_capability(capability)
        if not agents:
            raise LookupError(f"no agent found for capability: {capability}")
        return agents[0]

    def list(self) -> List[AgentSpec]:
        return sorted(self._agents.values(), key=lambda item: item.name)
