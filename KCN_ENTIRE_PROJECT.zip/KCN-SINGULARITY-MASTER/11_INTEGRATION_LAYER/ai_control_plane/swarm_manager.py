"""AI swarm formation and task assignment."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Iterable, List
from uuid import uuid4

from .agent_registry import AgentRegistry, AgentSpec


@dataclass(frozen=True)
class SwarmAssignment:
    mission_id: str
    required_capabilities: List[str]
    agents: List[AgentSpec]
    assignment_id: str = field(default_factory=lambda: f"KCN-SWARM-{uuid4().hex[:12].upper()}")
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class SwarmManager:
    def __init__(self, agent_registry: AgentRegistry) -> None:
        self.agent_registry = agent_registry
        self._assignments: Dict[str, SwarmAssignment] = {}

    def form_swarm(self, *, mission_id: str, required_capabilities: Iterable[str]) -> List[AgentSpec]:
        caps = list(required_capabilities)
        agents: List[AgentSpec] = []
        seen = set()
        for capability in caps:
            agent = self.agent_registry.require_capability(capability)
            if agent.agent_id not in seen:
                agents.append(agent)
                seen.add(agent.agent_id)
        assignment = SwarmAssignment(mission_id=mission_id, required_capabilities=caps, agents=agents)
        self._assignments[assignment.assignment_id] = assignment
        return agents

    def assignments_for_mission(self, mission_id: str) -> List[SwarmAssignment]:
        return [assignment for assignment in self._assignments.values() if assignment.mission_id == mission_id]
