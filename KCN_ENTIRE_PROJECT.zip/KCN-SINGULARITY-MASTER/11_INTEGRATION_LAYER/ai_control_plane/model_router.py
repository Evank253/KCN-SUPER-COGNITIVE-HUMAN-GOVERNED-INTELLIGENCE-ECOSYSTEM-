"""Model routing policy for KCN agents."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Set
from uuid import uuid4


@dataclass(frozen=True)
class ModelEndpoint:
    name: str
    provider: str
    capabilities: Set[str]
    endpoint: str
    model_id: str = field(default_factory=lambda: f"KCN-MODEL-{uuid4().hex[:12].upper()}")
    cost_rank: int = 5
    latency_rank: int = 5
    quality_rank: int = 5
    metadata: Dict[str, str] = field(default_factory=dict)


class ModelRouter:
    def __init__(self) -> None:
        self._models: Dict[str, ModelEndpoint] = {}

    def register(
        self,
        *,
        name: str,
        provider: str,
        capabilities: Iterable[str],
        endpoint: str,
        cost_rank: int = 5,
        latency_rank: int = 5,
        quality_rank: int = 5,
        metadata: Optional[Dict[str, str]] = None,
    ) -> ModelEndpoint:
        model = ModelEndpoint(
            name=name,
            provider=provider,
            capabilities=set(capabilities),
            endpoint=endpoint,
            cost_rank=cost_rank,
            latency_rank=latency_rank,
            quality_rank=quality_rank,
            metadata=metadata or {},
        )
        self._models[model.model_id] = model
        return model

    def route(self, *, capability: str, policy: str = "balanced") -> ModelEndpoint:
        candidates = [model for model in self._models.values() if capability in model.capabilities]
        if not candidates:
            raise LookupError(f"no model found for capability: {capability}")
        if policy == "lowest_cost":
            key = lambda model: (model.cost_rank, -model.quality_rank, model.latency_rank, model.name)
        elif policy == "lowest_latency":
            key = lambda model: (model.latency_rank, model.cost_rank, -model.quality_rank, model.name)
        elif policy == "highest_quality":
            key = lambda model: (-model.quality_rank, model.cost_rank, model.latency_rank, model.name)
        else:
            key = lambda model: (model.cost_rank + model.latency_rank - model.quality_rank, model.name)
        return sorted(candidates, key=key)[0]

    def list(self) -> List[ModelEndpoint]:
        return sorted(self._models.values(), key=lambda item: item.name)
