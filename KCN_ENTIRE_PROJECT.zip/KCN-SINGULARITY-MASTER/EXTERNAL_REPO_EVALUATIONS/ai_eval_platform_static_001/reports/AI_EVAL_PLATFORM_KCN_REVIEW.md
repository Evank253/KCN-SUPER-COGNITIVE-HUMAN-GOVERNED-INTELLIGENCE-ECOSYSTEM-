# KCN External Repository Evaluation — ai-eval-platform

## Evaluation Status

**Decision:** `NOT_READY_FOR_KCN_CAMPAIGN_002_RUNTIME_EXECUTION_WITHOUT_REPO_REPAIR_AND_UPLOAD`

**Overall preliminary score:** `0.37 / 1.00`

This is a **static review** based on the repository tree and file contents pasted into the chat. I could not run the actual project because the repository files were not uploaded into the workspace, and the pasted source appears markdown-transformed/corrupted.

## Important Limitation

The pasted code contains tokens that would not run as Python, for example:

- `from [api.jobs](http://api.jobs) import ...`
- `if **name** == "__main__":`
- `[app.run](http://app.run)(...)`
- `def **init**(...)`
- `for  *in range(self.max*workers):`
- `[adapter.build](http://adapter.build)_and_run()`
- `plugin = **import**(...)`
- `[self.evaluator.run](http://self.evaluator.run)_task(...)`

Those are likely artifacts from rich-text/Markdown conversion. I need the actual repository files or an archive to run executable tests.

## Domain Scores

| Domain | Score | Notes |
|---|---:|---|
| Architecture coverage | 0.80 | The project has API, orchestrator, adapters, evaluators, evidence, dashboard, plugins, examples, Docker, and CI structure. |
| Implementation executability | 0.15 | Pasted code is syntactically invalid due to formatting corruption; full repo not available. |
| Security / governance | 0.25 | Several serious issues visible: unsigned JWT acceptance, dev auth default, arbitrary git/docker execution, shell injection risk. |
| Benchmark governance | 0.45 | Plugin/task concept exists, but no visible immutable benchmark registry or sealed task hashes. |
| Blind evaluation readiness | 0.35 | Task/plugin system could support blind eval, but no visible private metadata isolation/sealed packets. |
| Baseline comparison readiness | 0.20 | No visible human or external AI baseline comparison schema in pasted files. |
| Calibration / failure taxonomy | 0.15 | No visible calibration, abstention, overconfidence, or failure taxonomy system. |
| Evidence / reproducibility | 0.50 | Manifest/signing folders exist, but content is incomplete; Docker/CI present but weak. |
| Deployment / CI | 0.35 | Docker/Compose/CI exist, but dashboard Dockerfile missing in tree and CI hides failed tests. |
| Operational reliability | 0.30 | In-memory job state, fire-and-forget worker status mismatch, limited persistence/error handling. |

## What Looks Strong

The repository has a useful high-level shape for an evaluation platform:

- API service
- job submission and status endpoints
- orchestrator/scheduler/worker model
- project adapters for git/docker/http/OpenAI/HuggingFace
- evaluator abstraction
- plugin-based benchmark loading
- evidence/manifest/signing area
- dashboard area
- examples
- Docker and docker-compose
- CI scaffold
- config file

This is a reasonable starting architecture for an AI evaluation platform.

## Critical Findings

### 1. Authentication is unsafe by default

`api/auth.py` appears to:

```python
jwt.decode(token, options={"verify_signature": False})
```

This accepts unsigned/unverified tokens and should not be used outside local development.

Also:

```python
dev_mode = os.getenv("DEV_MODE", "true")
```

Defaulting development auth to true means missing Authorization can grant a mock admin/evaluator user.

**Recommendation:**

- Default `DEV_MODE=false`.
- Require explicit local override.
- Verify JWT signatures against OIDC JWKS.
- Validate issuer, audience, expiry, and roles.

### 2. Arbitrary code execution risk

The platform accepts git/docker/http project types. That is expected for an evaluation platform, but it requires strong sandboxing.

Visible risks:

- arbitrary git clone URL
- arbitrary Dockerfile build path
- Docker build/run without clear resource limits
- shell execution with `os.popen`
- task input interpolated into shell command

Example risk in evaluator docker path:

```python
cmd = f"docker run --rm {image} /bin/sh -c 'echo \"{input_data}\" > /tmp/task_input ...'"
```

If `input_data` contains shell metacharacters, this can become command injection.

**Recommendation:**

- Use `subprocess.run([...], shell=False)`.
- Pass input via mounted files or stdin, not shell interpolation.
- Enforce container resource limits.
- Use read-only filesystem where possible.
- Disable network by default.
- Add allowlists for repo URLs and image sources.
- Require human approval for untrusted code execution.

### 3. CI hides failed tests

The CI contains:

```bash
pytest -q || true
```

That causes tests to pass even when tests fail.

**Recommendation:** remove `|| true`.

### 4. Job state is inconsistent

`Runner.submit()` records queued status in `self.jobs`, but the worker writes `status.json` separately and does not appear to update `Runner.jobs`.

API `get_job_status()` returns `runner.status(job_id)`, which may remain queued even after completion.

**Recommendation:**

- Store state in a shared durable backend.
- Or have `Runner.status()` read `status.json` from job dir.
- Prefer SQLite/Postgres/Redis for job state.

### 5. No clear benchmark governance

Campaign 002 expects benchmark artifacts such as:

- benchmark catalog
- benchmark versions
- task hash registry
- scoring registry
- benchmark signatures

The pasted repo has plugins and tasks, but not visible immutable benchmark governance.

### 6. No clear calibration or failure taxonomy

Campaign 002 expects tracking for:

- confidence calibration
- abstention
- overconfidence
- underconfidence
- failure categories

No visible equivalent appears in the provided files.

## KCN Campaign 002 Readiness

| Requirement | Status |
|---|---|
| Frozen benchmark versions | Partial / not visible |
| Task hash registry | Not visible |
| Sealed hidden tasks | Not visible |
| Blind task loader | Not visible |
| Private metadata isolation | Not visible |
| Human baseline schema | Not visible |
| External AI baseline schema | Not visible |
| Calibration metrics | Not visible |
| Failure taxonomy | Not visible |
| Evidence hashing | Partial; evidence modules exist but full content missing |
| Reproducibility manifest | Partial; manifest module exists but full content missing |
| Audit log | Partial / not visible |
| Secure sandbox | Not sufficient based on pasted adapters |
| Auth/security controls | Not production-ready |

## Recommended Remediation Roadmap

### Phase A — Make the repo executable

1. Upload actual files, not markdown-rendered code.
2. Run syntax/import tests.
3. Add a minimal test suite.
4. Remove CI `|| true`.
5. Pin dependency versions.

### Phase B — Secure the evaluation runtime

1. Fix JWT verification.
2. Default dev mode off.
3. Replace `os.popen` with safe subprocess usage.
4. Add Docker sandbox limits.
5. Add network/file/resource restrictions.
6. Add allowlists and approval gates for untrusted projects.

### Phase C — Add Campaign 002 evidence infrastructure

1. Add `benchmark_registry/`.
2. Add sealed hidden task packets.
3. Add private metadata separation.
4. Add scoring registry.
5. Add result hash registry.
6. Add calibration metrics.
7. Add failure taxonomy.
8. Add baseline comparison schema.
9. Add reproducibility manifests.

### Phase D — Run executable KCN evaluation

Once the actual repository is uploaded, run:

- import/syntax tests
- unit tests
- security static checks
- benchmark governance checks
- blind task dry-run
- KCN Campaign 002 adapter run

## Current Bottom Line

Based on the pasted repository content, `ai-eval-platform` is a promising evaluation-platform scaffold, but it is **not yet ready** for trustworthy KCN Campaign 002 runtime evaluation.

It first needs:

1. actual source upload,
2. syntax repair,
3. security hardening,
4. sandboxing improvements,
5. benchmark governance,
6. calibration/failure taxonomy,
7. baseline comparison support,
8. reproducibility/evidence packaging.
