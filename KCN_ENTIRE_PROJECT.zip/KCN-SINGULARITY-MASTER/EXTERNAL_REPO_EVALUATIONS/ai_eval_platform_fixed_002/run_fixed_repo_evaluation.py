#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

REPO = Path('/home/user/ai-eval-platform-fixed')
OUT = Path('/home/user/KCN-SINGULARITY-MASTER/EXTERNAL_REPO_EVALUATIONS/ai_eval_platform_fixed_002')
REPORTS = OUT / 'reports'
EVIDENCE = OUT / 'evidence'
REPORTS.mkdir(parents=True, exist_ok=True)
EVIDENCE.mkdir(parents=True, exist_ok=True)


def sha256_file(path: Path) -> str:
    return 'sha256:' + hashlib.sha256(path.read_bytes()).hexdigest()


def sha256_obj(obj) -> str:
    return 'sha256:' + hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(',', ':'), default=str).encode()).hexdigest()


def run(cmd: list[str], cwd: Path) -> dict:
    p = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)
    return {'cmd': cmd, 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}


def read(path: str) -> str:
    p = REPO / path
    return p.read_text(encoding='utf-8') if p.exists() else ''


def exists(path: str) -> bool:
    return (REPO / path).exists()


def no_pattern(path: str, pattern: str) -> bool:
    return not re.search(pattern, read(path))


def yes_pattern(path: str, pattern: str) -> bool:
    return bool(re.search(pattern, read(path)))


started = datetime.now(timezone.utc).isoformat()
compile_result = run([sys.executable, '-m', 'compileall', '-q', '.'], REPO)
test_result = run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], REPO)

checks = []

def add(name, passed, weight, detail):
    checks.append({'name': name, 'passed': bool(passed), 'weight': weight, 'detail': detail})

add('syntax_compileall', compile_result['returncode'] == 0, 1.0, 'python -m compileall -q .')
add('unit_tests', test_result['returncode'] == 0 and 'Ran 12 tests' in test_result['stderr'], 1.0, 'python -m unittest discover -s tests -v')
add('dev_mode_default_false_env', yes_pattern('.env.example', r'DEV_MODE=false'), 0.8, '.env.example defaults DEV_MODE=false')
add('dev_mode_default_false_code', yes_pattern('api/auth.py', r'os\.getenv\("DEV_MODE",\s*"false"\)'), 0.8, 'api/auth.py defaults DEV_MODE false')
add('jwt_signature_not_disabled', no_pattern('api/auth.py', r'verify_signature["\']?\s*:\s*False'), 1.0, 'No verify_signature=False in api/auth.py')
add('secret_required_for_jwt', yes_pattern('api/auth.py', r'SECRET_KEY must be configured'), 0.8, 'Token validation requires SECRET_KEY')
add('ci_no_test_bypass', no_pattern('ci/github-actions.yml', r'\|\|\s*true'), 1.0, 'CI does not ignore failed tests')
add('dangerous_os_popen_removed', not any('os.popen' in p.read_text(errors='ignore') for p in REPO.rglob('*.py')), 1.0, 'No os.popen in Python files')
add('shell_false_patterns', no_pattern('evaluators/evaluator.py', r'shell\s*=\s*True'), 0.8, 'Evaluator does not use shell=True')
add('docker_network_none', yes_pattern('evaluators/evaluator.py', r'--network"?,\s*"none'), 0.9, 'Docker task run disables network')
add('docker_resource_limits', yes_pattern('evaluators/evaluator.py', r'--memory') and yes_pattern('evaluators/evaluator.py', r'--cpus'), 0.9, 'Docker task run has memory/CPU controls')
add('git_allowlist_present', yes_pattern('orchestrator/adapters/git_adapter.py', r'GIT_REPO_ALLOWLIST'), 0.8, 'Git adapter allowlist control exists')
add('http_allowlist_present', yes_pattern('orchestrator/adapters/http_adapter.py', r'HTTP_TARGET_ALLOWLIST'), 0.8, 'HTTP adapter allowlist control exists')
add('runner_status_sync', yes_pattern('orchestrator/runner.py', r'status\.json') and yes_pattern('orchestrator/workers.py', r'status_callback'), 0.8, 'Runner reads status.json and workers call status callback')
add('benchmark_registry_exists', all(exists(p) for p in ['benchmark_registry/benchmark_catalog.json','benchmark_registry/benchmark_versions.json','benchmark_registry/scoring_registry.json','benchmark_registry/failure_taxonomy.json']), 1.0, 'Benchmark governance files exist')
add('calibration_module_exists', exists('evaluators/calibration.py'), 0.8, 'Calibration metrics module exists')
add('failure_taxonomy_exists', exists('evaluators/failure_taxonomy.py'), 0.8, 'Failure taxonomy module exists')
add('evidence_modules_exist', all(exists(p) for p in ['evidence/manifest.py','evidence/signer.py','evidence/audit.py','evidence_manifest.json']), 1.0, 'Evidence manifest/signing/audit files exist')
add('dashboard_dockerfile_exists', exists('dashboard/Dockerfile'), 0.5, 'Dashboard Dockerfile exists')
add('security_docs_exist', exists('docs/security.md'), 0.5, 'Security hardening docs exist')

weighted_total = sum(c['weight'] for c in checks)
weighted_pass = sum(c['weight'] for c in checks if c['passed'])
score = round(weighted_pass / weighted_total, 4) if weighted_total else 0.0
failed = [c for c in checks if not c['passed']]

# Domain scores
categories = {
    'executability': ['syntax_compileall', 'unit_tests'],
    'auth_security': ['dev_mode_default_false_env','dev_mode_default_false_code','jwt_signature_not_disabled','secret_required_for_jwt'],
    'execution_sandbox': ['dangerous_os_popen_removed','shell_false_patterns','docker_network_none','docker_resource_limits','git_allowlist_present','http_allowlist_present'],
    'ci_reliability': ['ci_no_test_bypass'],
    'ops_reliability': ['runner_status_sync'],
    'benchmark_governance': ['benchmark_registry_exists','calibration_module_exists','failure_taxonomy_exists'],
    'evidence_reproducibility': ['evidence_modules_exist'],
    'docs_deployment': ['dashboard_dockerfile_exists','security_docs_exist'],
}
check_by_name = {c['name']: c for c in checks}
domain_scores = {}
for domain, names in categories.items():
    subset = [check_by_name[n] for n in names]
    total = sum(c['weight'] for c in subset)
    passed = sum(c['weight'] for c in subset if c['passed'])
    domain_scores[domain] = round(passed / total, 4) if total else 0.0

files = {}
for path in sorted(REPO.rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts:
        files[str(path.relative_to(REPO))] = sha256_file(path)

summary = {
    'evaluation_id': 'KCN-EXT-EVAL-AI-EVAL-PLATFORM-FIXED-002',
    'target_repository': str(REPO),
    'started_at': started,
    'completed_at': datetime.now(timezone.utc).isoformat(),
    'decision': 'READY_FOR_INTERNAL_CAMPAIGN_002_DRY_RUN' if score >= 0.85 and not failed else 'NEEDS_REMEDIATION',
    'overall_score': score,
    'domain_scores': domain_scores,
    'checks': checks,
    'failed_checks': failed,
    'compile_result': compile_result,
    'test_result': {'returncode': test_result['returncode'], 'stderr': test_result['stderr']},
    'artifact_hash': sha256_obj(files),
}

(REPORTS / 'evaluation_summary.json').write_text(json.dumps(summary, indent=2, sort_keys=True))
(EVIDENCE / 'file_hashes.json').write_text(json.dumps(files, indent=2, sort_keys=True))
(EVIDENCE / 'provenance.json').write_text(json.dumps({'evaluation_id': summary['evaluation_id'], 'repo': str(REPO), 'artifact_hash': summary['artifact_hash'], 'source': 'fixed workspace repository'}, indent=2, sort_keys=True))
with (EVIDENCE / 'audit_log.jsonl').open('w') as f:
    f.write(json.dumps({'event': 'COMPILEALL_RUN', 'returncode': compile_result['returncode'], 'timestamp': started}, sort_keys=True) + '\n')
    f.write(json.dumps({'event': 'UNIT_TEST_RUN', 'returncode': test_result['returncode'], 'timestamp': summary['completed_at']}, sort_keys=True) + '\n')

report = f"""# KCN Campaign 002 Dry-Run Evaluation — ai-eval-platform-fixed

## Decision

**{summary['decision']}**

## Score

Overall score: **{score:.3f} / 1.000**

## Domain Scores

| Domain | Score |
|---|---:|
"""
for domain, value in domain_scores.items():
    report += f"| {domain} | {value:.3f} |\n"
report += "\n## Check Results\n\n| Check | Passed | Weight | Detail |\n|---|---|---:|---|\n"
for c in checks:
    report += f"| {c['name']} | {c['passed']} | {c['weight']} | {c['detail']} |\n"
report += f"""
## Executable Validation

```text
compileall return code: {compile_result['returncode']}
unittest return code: {test_result['returncode']}
```

Unit test result excerpt:

```text
{test_result['stderr'][-1200:]}
```

## Evidence Artifacts

- `evidence/file_hashes.json`
- `evidence/provenance.json`
- `evidence/audit_log.jsonl`
- `reports/evaluation_summary.json`

## Remaining Non-Blocking Work

The fixed system is ready for internal KCN Campaign 002 dry-run style evaluation. Before production or third-party evaluation, still add:

1. Real OIDC JWKS validation.
2. Database-backed job state and durable worker queue.
3. Hardened untrusted-code isolation host.
4. Full sealed hidden task implementation for live benchmarks.
5. Real human and external AI baseline data.
6. End-to-end Docker/Git/HTTP integration tests.
"""
(REPORTS / 'AI_EVAL_PLATFORM_FIXED_KCN_EVALUATION.md').write_text(report)
print(json.dumps({'decision': summary['decision'], 'overall_score': score, 'failed_checks': len(failed)}, indent=2))
