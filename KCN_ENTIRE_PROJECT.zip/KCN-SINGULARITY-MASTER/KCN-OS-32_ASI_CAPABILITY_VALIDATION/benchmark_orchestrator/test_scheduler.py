"""Benchmark test scheduler."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, List
from uuid import uuid4

from .benchmark_registry import BenchmarkSpec


@dataclass(frozen=True)
class ScheduledBenchmark:
    benchmark_id: str
    name: str
    domain: str
    order: int


@dataclass(frozen=True)
class BenchmarkSchedule:
    schedule_id: str = field(default_factory=lambda: f"KCN-BENCH-SCHEDULE-{uuid4().hex[:12].upper()}")
    items: List[ScheduledBenchmark] = field(default_factory=list)


class TestScheduler:
    def schedule(self, benchmarks: Iterable[BenchmarkSpec], *, blind_first: bool = True) -> BenchmarkSchedule:
        ordered = sorted(benchmarks, key=lambda item: (not item.holdout if blind_first else item.holdout, item.domain, item.name))
        items = [ScheduledBenchmark(benchmark_id=item.benchmark_id, name=item.name, domain=item.domain, order=index) for index, item in enumerate(ordered, start=1)]
        return BenchmarkSchedule(items=items)
