"""High-level benchmark manager."""

from __future__ import annotations

from typing import Callable, Iterable, List

from .benchmark_registry import BenchmarkRegistry, BenchmarkSpec
from .evaluation_pipeline import BenchmarkResult, EvaluationPipeline
from .test_scheduler import BenchmarkSchedule, TestScheduler


class BenchmarkManager:
    def __init__(self) -> None:
        self.registry = BenchmarkRegistry()
        self.scheduler = TestScheduler()
        self.pipeline = EvaluationPipeline()

    def register(self, spec: BenchmarkSpec) -> BenchmarkSpec:
        return self.registry.register(spec)

    def schedule_all(self) -> BenchmarkSchedule:
        return self.scheduler.schedule(self.registry.list())

    def run_all(self, candidate: Callable[[str], dict], *, blind: bool = False) -> List[BenchmarkResult]:
        return self.pipeline.run(self.registry.list(), candidate, blind=blind)
