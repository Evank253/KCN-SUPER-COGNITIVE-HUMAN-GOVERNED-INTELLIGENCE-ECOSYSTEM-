"""Benchmark registry for Phase 32."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional
from uuid import uuid4

BenchmarkFn = Callable[[dict], float]


@dataclass(frozen=True)
class BenchmarkSpec:
    name: str
    domain: str
    prompt: str
    evaluator: BenchmarkFn
    benchmark_id: str = field(default_factory=lambda: f"KCN-BENCHSPEC-{uuid4().hex[:12].upper()}")
    tags: List[str] = field(default_factory=list)
    expert_median_baseline: float = 0.75
    top_human_baseline: float = 0.95
    holdout: bool = False


class BenchmarkRegistry:
    def __init__(self) -> None:
        self._benchmarks: Dict[str, BenchmarkSpec] = {}

    def register(self, spec: BenchmarkSpec) -> BenchmarkSpec:
        if spec.name in self._benchmarks:
            raise ValueError(f"benchmark already registered: {spec.name}")
        self._benchmarks[spec.name] = spec
        return spec

    def create(
        self,
        *,
        name: str,
        domain: str,
        prompt: str,
        evaluator: BenchmarkFn,
        tags: Optional[Iterable[str]] = None,
        expert_median_baseline: float = 0.75,
        top_human_baseline: float = 0.95,
        holdout: bool = False,
    ) -> BenchmarkSpec:
        return self.register(BenchmarkSpec(
            name=name,
            domain=domain,
            prompt=prompt,
            evaluator=evaluator,
            tags=list(tags or []),
            expert_median_baseline=expert_median_baseline,
            top_human_baseline=top_human_baseline,
            holdout=holdout,
        ))

    def list(self, *, domain: Optional[str] = None, holdout: Optional[bool] = None) -> List[BenchmarkSpec]:
        benchmarks = list(self._benchmarks.values())
        if domain:
            benchmarks = [item for item in benchmarks if item.domain == domain]
        if holdout is not None:
            benchmarks = [item for item in benchmarks if item.holdout == holdout]
        return sorted(benchmarks, key=lambda item: item.name)

    def require(self, name: str) -> BenchmarkSpec:
        if name not in self._benchmarks:
            raise KeyError(f"unknown benchmark: {name}")
        return self._benchmarks[name]
