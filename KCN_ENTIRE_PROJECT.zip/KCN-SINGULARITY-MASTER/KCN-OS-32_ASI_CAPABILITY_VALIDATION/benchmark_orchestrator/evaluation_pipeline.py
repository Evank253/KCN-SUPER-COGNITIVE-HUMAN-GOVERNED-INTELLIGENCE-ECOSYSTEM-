"""Evaluation pipeline for benchmark execution."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Iterable, List
from uuid import uuid4

from .benchmark_registry import BenchmarkSpec

CandidateFn = Callable[[str], dict]


@dataclass(frozen=True)
class BenchmarkResult:
    benchmark_id: str
    name: str
    domain: str
    candidate_score: float
    blind_score: float
    expert_median_baseline: float
    top_human_baseline: float
    novelty_score: float
    transfer_score: float
    robustness_score: float
    result_id: str = field(default_factory=lambda: f"KCN-BENCHRESULT-{uuid4().hex[:12].upper()}")
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    result_hash: str = ""


class EvaluationPipeline:
    """Runs benchmark specs through a candidate adapter.

    Candidate functions return a dictionary. The benchmark evaluator converts the
    output to a score between 0 and any benchmark-defined upper range.
    """

    def run(self, benchmarks: Iterable[BenchmarkSpec], candidate: CandidateFn, *, blind: bool = False) -> List[BenchmarkResult]:
        results: List[BenchmarkResult] = []
        for spec in benchmarks:
            prompt = self._blind_prompt(spec) if blind else spec.prompt
            output = candidate(prompt)
            score = float(spec.evaluator(output))
            blind_score = score if blind else float(output.get("blind_score", score))
            result = BenchmarkResult(
                benchmark_id=spec.benchmark_id,
                name=spec.name,
                domain=spec.domain,
                candidate_score=score,
                blind_score=blind_score,
                expert_median_baseline=spec.expert_median_baseline,
                top_human_baseline=spec.top_human_baseline,
                novelty_score=float(output.get("novelty_score", min(1.0, score))),
                transfer_score=float(output.get("transfer_score", min(1.0, score))),
                robustness_score=float(output.get("robustness_score", min(1.0, score))),
            )
            result_hash = self._hash_result(result)
            results.append(BenchmarkResult(**{**result.__dict__, "result_hash": result_hash}))
        return results

    @staticmethod
    def _blind_prompt(spec: BenchmarkSpec) -> str:
        token = hashlib.sha256(f"{spec.benchmark_id}:{spec.name}".encode()).hexdigest()[:16]
        return f"Solve hidden benchmark probe {token}. Return structured result."

    @staticmethod
    def _hash_result(result: BenchmarkResult) -> str:
        payload = {**result.__dict__, "result_hash": ""}
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canonical.encode()).hexdigest()
