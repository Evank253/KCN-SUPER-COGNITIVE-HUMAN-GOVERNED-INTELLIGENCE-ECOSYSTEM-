"""Novel problem scoring."""

from __future__ import annotations


class NovelProblemScorer:
    def score(self, *, solution_correctness: float, novelty: float, verification_quality: float) -> float:
        return round(max(0.0, min(1.0, solution_correctness * 0.45 + novelty * 0.30 + verification_quality * 0.25)), 3)
