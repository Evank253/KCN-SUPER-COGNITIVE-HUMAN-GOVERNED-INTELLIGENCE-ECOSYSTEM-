"""Abstraction test scoring."""

from __future__ import annotations


class AbstractionTests:
    def score(self, *, pattern_identification: float, compression: float, reuse_success: float) -> float:
        return round(max(0.0, min(1.0, pattern_identification * 0.4 + compression * 0.2 + reuse_success * 0.4)), 3)
