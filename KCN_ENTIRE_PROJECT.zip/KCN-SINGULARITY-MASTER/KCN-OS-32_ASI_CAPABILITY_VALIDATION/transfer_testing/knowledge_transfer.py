"""Knowledge transfer scoring."""

from __future__ import annotations


class KnowledgeTransferScorer:
    def score(self, *, source_understanding: float, target_application: float, abstraction_quality: float) -> float:
        return round(max(0.0, min(1.0, source_understanding * 0.25 + target_application * 0.5 + abstraction_quality * 0.25)), 3)
