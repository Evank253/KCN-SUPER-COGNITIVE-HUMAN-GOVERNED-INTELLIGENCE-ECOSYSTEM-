"""Cross-domain task definitions."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List
from uuid import uuid4


@dataclass(frozen=True)
class CrossDomainTask:
    source_domain: str
    target_domain: str
    prompt: str
    task_id: str = field(default_factory=lambda: f"KCN-XFER-TASK-{uuid4().hex[:12].upper()}")
    hidden: bool = True


class CrossDomainTaskFactory:
    def create(self, *, source_domain: str, target_domain: str, prompt: str) -> CrossDomainTask:
        return CrossDomainTask(source_domain=source_domain, target_domain=target_domain, prompt=prompt)
