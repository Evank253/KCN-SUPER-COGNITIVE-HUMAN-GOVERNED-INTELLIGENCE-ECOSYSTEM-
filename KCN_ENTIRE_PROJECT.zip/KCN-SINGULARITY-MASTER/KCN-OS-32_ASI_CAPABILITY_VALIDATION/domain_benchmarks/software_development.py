"""SoftwareDevelopmentBenchmark domain benchmark shell."""

from __future__ import annotations

from benchmark_orchestrator import BenchmarkSpec


class SoftwareDevelopmentBenchmark:
    domain = "software_engineering"

    def create_spec(self, *, name: str | None = None, prompt: str | None = None, top_human_baseline: float = 1.0) -> BenchmarkSpec:
        return BenchmarkSpec(
            name=name or "software_engineering_benchmark",
            domain=self.domain,
            prompt=prompt or "Solve a private software_engineering benchmark task.",
            evaluator=lambda output: float(output.get("score", 0.0)),
            expert_median_baseline=0.8,
            top_human_baseline=top_human_baseline,
            holdout=True,
        )
