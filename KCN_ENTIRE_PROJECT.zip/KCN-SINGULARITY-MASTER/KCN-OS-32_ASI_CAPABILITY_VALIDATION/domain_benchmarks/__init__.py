"""Domain benchmark exports."""

from .mathematics import MathematicsBenchmark
from .science import ScienceBenchmark
from .engineering import EngineeringBenchmark
from .software_development import SoftwareDevelopmentBenchmark
from .strategy import StrategyBenchmark
from .economics import EconomicsBenchmark
from .research import ResearchBenchmark

__all__ = [
    "MathematicsBenchmark",
    "ScienceBenchmark",
    "EngineeringBenchmark",
    "SoftwareDevelopmentBenchmark",
    "StrategyBenchmark",
    "EconomicsBenchmark",
    "ResearchBenchmark",
]
