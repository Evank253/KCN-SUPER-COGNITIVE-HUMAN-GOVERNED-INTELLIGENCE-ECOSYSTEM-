"""Capability report generation."""

from __future__ import annotations

from typing import Iterable


class CapabilityReport:
    def build_markdown(self, *, title: str, decision: str, metrics: dict, failed_gates: Iterable[str]) -> str:
        report = f"# {title}\n\n## Decision\n\n**{decision}**\n\n## Metrics\n\n| Metric | Value |\n|---|---:|\n"
        for key, value in metrics.items():
            if key != "failed_gates":
                report += f"| {key} | {value} |\n"
        report += "\n## Failed Gates\n\n"
        failed = list(failed_gates)
        report += "None\n" if not failed else "".join(f"- `{gate}`\n" for gate in failed)
        return report
