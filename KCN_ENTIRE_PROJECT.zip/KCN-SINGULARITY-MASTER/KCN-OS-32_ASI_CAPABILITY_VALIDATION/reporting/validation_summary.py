"""Validation summary builder."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ValidationSummary:
    decision: str
    passed_gates: int
    total_gates: int
    ready: bool


class ValidationSummaryBuilder:
    def build(self, *, decision: str, passed_gates: int, total_gates: int) -> ValidationSummary:
        return ValidationSummary(decision=decision, passed_gates=passed_gates, total_gates=total_gates, ready=decision == "ASI_CLAIM_SUPPORTED_BY_PROTOCOL")
