"""Benchmark dashboard summaries."""

from __future__ import annotations

from collections import Counter


class BenchmarkDashboard:
    def summarize_by_domain(self, results: list[dict]) -> dict[str, int]:
        return dict(Counter(item.get("domain", "unknown") for item in results))
