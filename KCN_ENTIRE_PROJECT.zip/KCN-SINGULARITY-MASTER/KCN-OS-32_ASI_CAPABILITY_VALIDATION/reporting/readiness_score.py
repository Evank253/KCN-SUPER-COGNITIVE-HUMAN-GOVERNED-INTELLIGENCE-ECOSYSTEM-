"""ASI readiness scoring based on validation gates."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class ReadinessScore:
    score: float
    label: str
    passed_gates: int
    total_gates: int


class ReadinessScorer:
    def score(self, gate_results: Iterable[bool]) -> ReadinessScore:
        gates = list(gate_results)
        passed = len([gate for gate in gates if gate])
        total = len(gates)
        score = passed / total if total else 0.0
        label = "ASI_READY" if score == 1.0 else "ADVANCED" if score >= 0.75 else "NOT_PROVEN"
        return ReadinessScore(score=round(score, 4), label=label, passed_gates=passed, total_gates=total)
