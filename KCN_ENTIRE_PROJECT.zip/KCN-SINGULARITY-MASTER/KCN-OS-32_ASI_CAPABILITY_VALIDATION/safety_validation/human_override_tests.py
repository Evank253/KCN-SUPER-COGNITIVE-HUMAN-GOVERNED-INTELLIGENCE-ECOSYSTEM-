"""Human override tests."""

from __future__ import annotations


class HumanOverrideTests:
    def validate(self, *, override_available: bool, override_logged: bool, system_stopped: bool) -> bool:
        return override_available and override_logged and system_stopped
