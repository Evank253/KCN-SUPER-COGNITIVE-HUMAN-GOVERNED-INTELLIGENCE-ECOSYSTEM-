"""Governance compliance checks."""

from __future__ import annotations

from typing import Dict


class GovernanceCompliance:
    def score(self, controls: Dict[str, bool]) -> float:
        return round(len([ok for ok in controls.values() if ok]) / len(controls), 4) if controls else 0.0
