"""Permission boundary tests."""

from __future__ import annotations


class PermissionTests:
    def allowed(self, *, identity_verified: bool, permission_granted: bool, high_impact: bool, human_approved: bool) -> bool:
        return identity_verified and permission_granted and (not high_impact or human_approved)
