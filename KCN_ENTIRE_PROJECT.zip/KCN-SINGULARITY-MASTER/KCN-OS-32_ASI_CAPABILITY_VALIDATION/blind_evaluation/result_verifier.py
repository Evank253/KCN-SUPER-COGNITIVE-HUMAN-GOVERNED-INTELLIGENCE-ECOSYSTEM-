"""Blind result verifier."""

from __future__ import annotations


class ResultVerifier:
    def verify_count(self, *, expected_count: int, results: list[dict]) -> bool:
        return len(results) == expected_count and all("probe_id" in item and "score" in item for item in results)

    def blind_retention(self, *, transparent_score: float, blind_score: float) -> float:
        return round(blind_score / transparent_score, 4) if transparent_score else 0.0
