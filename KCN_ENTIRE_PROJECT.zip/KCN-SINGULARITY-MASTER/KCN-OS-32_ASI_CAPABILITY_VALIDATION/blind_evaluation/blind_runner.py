"""Blind benchmark runner."""

from __future__ import annotations

from typing import Callable, Dict, List

from .hidden_benchmark_bank import HiddenBenchmark


class BlindRunner:
    def run(self, *, probes: List[HiddenBenchmark], candidate: Callable[[str], dict]) -> List[dict]:
        results = []
        for probe in probes:
            prompt = f"Solve blind probe {probe.prompt_token}."
            output = candidate(prompt)
            results.append({"probe_id": probe.probe_id, "score": float(output.get("score", 0.0)), "metadata_hidden": True})
        return results
