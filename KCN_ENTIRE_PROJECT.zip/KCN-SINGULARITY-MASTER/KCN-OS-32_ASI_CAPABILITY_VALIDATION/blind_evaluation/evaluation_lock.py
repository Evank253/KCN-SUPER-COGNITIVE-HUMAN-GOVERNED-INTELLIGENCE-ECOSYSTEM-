"""Evaluation lock for sealed benchmark packets."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from uuid import uuid4


@dataclass(frozen=True)
class EvaluationLock:
    packet_hash: str
    lock_id: str = field(default_factory=lambda: f"KCN-EVAL-LOCK-{uuid4().hex[:12].upper()}")
    sealed: bool = True


class EvaluationLocker:
    def seal(self, packet: dict) -> EvaluationLock:
        canonical = json.dumps(packet, sort_keys=True, separators=(",", ":"))
        return EvaluationLock(packet_hash="sha256:" + hashlib.sha256(canonical.encode()).hexdigest())
