"""Hidden benchmark bank for blind evaluation."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class HiddenBenchmark:
    probe_id: str
    prompt_token: str
    hidden_domain_hash: str
    benchmark_id: str = field(default_factory=lambda: f"KCN-HIDDEN-BENCH-{uuid4().hex[:12].upper()}")


class HiddenBenchmarkBank:
    def __init__(self) -> None:
        self._items: Dict[str, HiddenBenchmark] = {}

    def add(self, *, domain: str, secret_prompt: str) -> HiddenBenchmark:
        probe_id = f"BLIND-PROBE-{uuid4().hex[:10].upper()}"
        item = HiddenBenchmark(
            probe_id=probe_id,
            prompt_token=hashlib.sha256(secret_prompt.encode()).hexdigest()[:16],
            hidden_domain_hash=hashlib.sha256(domain.encode()).hexdigest(),
        )
        self._items[probe_id] = item
        return item

    def list(self) -> List[HiddenBenchmark]:
        return list(self._items.values())
