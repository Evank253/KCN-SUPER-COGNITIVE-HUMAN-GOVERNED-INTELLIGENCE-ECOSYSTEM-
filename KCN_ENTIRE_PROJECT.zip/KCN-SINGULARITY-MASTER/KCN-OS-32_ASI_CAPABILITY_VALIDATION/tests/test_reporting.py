from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from cognitive_evaluation import AdaptationTests, CreativityTests, LearningTests, PlanningTests, ReasoningTests
from reporting import BenchmarkDashboard, CapabilityReport, ReadinessScorer, ValidationSummaryBuilder
from robustness_testing import AdversarialTesting, FailureAnalysis, RecoveryTesting, UncertaintyTesting
from safety_validation import AlignmentTests, GovernanceCompliance, HumanOverrideTests, PermissionTests
from transfer_testing import AbstractionTests, CrossDomainTaskFactory, KnowledgeTransferScorer, NovelProblemScorer


class TestReportingAndScoring(unittest.TestCase):
    def test_scoring_reporting_safety_and_transfer(self) -> None:
        self.assertGreater(ReasoningTests().score(correctness=1.0, explanation_quality=0.9, consistency=0.9), 0.9)
        self.assertGreater(PlanningTests().score(dependency_validity=1, resource_fit=0.9, risk_handling=0.9, timeline_quality=0.8), 0.85)
        self.assertGreater(CreativityTests().score(novelty=0.9, usefulness=0.9, coherence=0.8), 0.85)
        self.assertGreater(LearningTests().score(pretest=0.2, posttest=0.9, resource_efficiency=0.8), 0.7)
        self.assertGreater(AdaptationTests().score(baseline_score=1.0, changed_condition_score=0.9, recovery_speed=0.8), 0.85)

        task = CrossDomainTaskFactory().create(source_domain="biology", target_domain="materials", prompt="apply structure concept")
        self.assertTrue(task.hidden)
        self.assertGreater(KnowledgeTransferScorer().score(source_understanding=0.9, target_application=0.85, abstraction_quality=0.8), 0.8)
        self.assertGreater(NovelProblemScorer().score(solution_correctness=0.9, novelty=0.85, verification_quality=0.9), 0.85)
        self.assertGreater(AbstractionTests().score(pattern_identification=0.9, compression=0.8, reuse_success=0.85), 0.8)

        self.assertGreater(AdversarialTesting().score(clean_score=1.0, adversarial_score=0.9), 0.85)
        self.assertEqual(FailureAnalysis().summarize(["timeout", "timeout", "format"])["timeout"], 2)
        self.assertLess(UncertaintyTesting().calibration_error(confidence=0.8, correctness=0.75), 0.1)
        self.assertEqual(RecoveryTesting().score(detected_failure=True, corrected_output=True, audit_logged=True), 1.0)

        self.assertEqual(AlignmentTests().pass_rate(passed=99, total=100), 0.99)
        self.assertTrue(PermissionTests().allowed(identity_verified=True, permission_granted=True, high_impact=True, human_approved=True))
        self.assertTrue(HumanOverrideTests().validate(override_available=True, override_logged=True, system_stopped=True))
        self.assertEqual(GovernanceCompliance().score({"approval": True, "audit": True}), 1.0)

        readiness = ReadinessScorer().score([True, True, False])
        self.assertEqual(readiness.label, "NOT_PROVEN")
        summary = ValidationSummaryBuilder().build(decision="NOT_PROVEN", passed_gates=2, total_gates=3)
        self.assertFalse(summary.ready)
        dashboard = BenchmarkDashboard().summarize_by_domain([{"domain": "math"}, {"domain": "math"}, {"domain": "science"}])
        self.assertEqual(dashboard["math"], 2)
        report = CapabilityReport().build_markdown(title="Capability Report", decision="NOT_PROVEN", metrics={"passed_gates": 2}, failed_gates=["blind_retention"])
        self.assertIn("blind_retention", report)


if __name__ == "__main__":
    unittest.main()
