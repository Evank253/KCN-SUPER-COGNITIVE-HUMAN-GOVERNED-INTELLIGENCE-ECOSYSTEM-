from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from benchmark_orchestrator import BenchmarkManager
from domain_benchmarks import EngineeringBenchmark, MathematicsBenchmark, ScienceBenchmark
from human_comparison import ComparisonEngine, ExpertBaselineStore, ScoringNormalizer


class TestBenchmarkEngine(unittest.TestCase):
    def test_register_schedule_run_and_compare(self) -> None:
        manager = BenchmarkManager()
        for spec in [
            MathematicsBenchmark().create_spec(name="math_holdout", top_human_baseline=1.0),
            ScienceBenchmark().create_spec(name="science_holdout", top_human_baseline=1.0),
            EngineeringBenchmark().create_spec(name="engineering_holdout", top_human_baseline=1.0),
        ]:
            manager.register(spec)

        schedule = manager.schedule_all()
        self.assertEqual(len(schedule.items), 3)

        candidate = lambda prompt: {
            "score": 1.12,
            "blind_score": 1.08,
            "novelty_score": 0.86,
            "transfer_score": 0.84,
            "robustness_score": 0.9,
        }
        results = manager.run_all(candidate)
        self.assertEqual(len(results), 3)
        self.assertTrue(all(result.result_hash.startswith("sha256:") for result in results))

        baselines = ExpertBaselineStore()
        baseline = baselines.add(domain="mathematical_reasoning", expert_median=0.8, top_human=1.0, sample_size=30)
        comparison = ComparisonEngine().compare(candidate_score=1.12, expert_median=baseline.expert_median, top_human=baseline.top_human)
        self.assertTrue(comparison.exceeds_top_human)
        self.assertEqual(ScoringNormalizer().normalize(raw_score=80, maximum_score=100), 0.8)


if __name__ == "__main__":
    unittest.main()
