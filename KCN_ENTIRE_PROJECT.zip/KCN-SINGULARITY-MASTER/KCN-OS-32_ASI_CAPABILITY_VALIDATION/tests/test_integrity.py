from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from evidence_package import ArtifactSigner, AuditExporter, ProvenanceRecord, ResultHasher


class TestIntegrity(unittest.TestCase):
    def test_hash_sign_provenance_and_audit_export(self) -> None:
        result = {"benchmark": "math", "score": 1.12}
        result_hash = ResultHasher().hash(result)
        self.assertTrue(result_hash.startswith("sha256:"))
        self.assertEqual(result_hash, ResultHasher().hash({"score": 1.12, "benchmark": "math"}))

        signer = ArtifactSigner(secret=b"phase32-validation-secret")
        signature = signer.sign(result_hash)
        self.assertTrue(signer.verify(result_hash, signature))

        provenance = ProvenanceRecord(
            subject_id="result:math",
            source="independent-lab-1",
            action="BENCHMARK_RESULT_RECORDED",
            evidence_hash=result_hash,
            parents=[],
        )
        exported = AuditExporter().export_json([provenance])
        self.assertIn(provenance.provenance_id, exported)


if __name__ == "__main__":
    unittest.main()
