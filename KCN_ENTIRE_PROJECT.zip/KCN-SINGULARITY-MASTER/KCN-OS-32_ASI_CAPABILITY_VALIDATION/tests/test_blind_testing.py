from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from blind_evaluation import BlindRunner, EvaluationLocker, HiddenBenchmarkBank, ResultVerifier


class TestBlindTesting(unittest.TestCase):
    def test_hidden_bank_runner_lock_and_verifier(self) -> None:
        bank = HiddenBenchmarkBank()
        bank.add(domain="mathematics", secret_prompt="private math problem")
        bank.add(domain="science", secret_prompt="private science task")
        probes = bank.list()
        self.assertEqual(len(probes), 2)
        self.assertNotEqual(probes[0].hidden_domain_hash, "mathematics")

        results = BlindRunner().run(probes=probes, candidate=lambda prompt: {"score": 1.05})
        self.assertTrue(ResultVerifier().verify_count(expected_count=2, results=results))
        self.assertGreater(ResultVerifier().blind_retention(transparent_score=1.10, blind_score=1.05), 0.95)

        lock = EvaluationLocker().seal({"probes": [probe.probe_id for probe in probes]})
        self.assertTrue(lock.sealed)
        self.assertTrue(lock.packet_hash.startswith("sha256:"))


if __name__ == "__main__":
    unittest.main()
