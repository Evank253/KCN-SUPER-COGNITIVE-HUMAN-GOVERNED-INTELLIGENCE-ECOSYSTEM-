"""Result hashing for benchmark evidence."""

from __future__ import annotations

import hashlib
import json


class ResultHasher:
    def hash(self, result: dict) -> str:
        canonical = json.dumps(result, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canonical.encode()).hexdigest()
