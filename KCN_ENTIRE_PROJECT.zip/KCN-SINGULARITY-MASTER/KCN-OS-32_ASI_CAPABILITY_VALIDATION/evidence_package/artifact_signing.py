"""Local artifact signing scaffold using HMAC.

Production deployments should use managed signing keys and external custody.
"""

from __future__ import annotations

import hashlib
import hmac


class ArtifactSigner:
    def __init__(self, secret: bytes) -> None:
        if len(secret) < 16:
            raise ValueError("secret must be at least 16 bytes")
        self.secret = secret

    def sign(self, artifact_hash: str) -> str:
        return "hmac-sha256:" + hmac.new(self.secret, artifact_hash.encode(), hashlib.sha256).hexdigest()

    def verify(self, artifact_hash: str, signature: str) -> bool:
        return hmac.compare_digest(self.sign(artifact_hash), signature)
