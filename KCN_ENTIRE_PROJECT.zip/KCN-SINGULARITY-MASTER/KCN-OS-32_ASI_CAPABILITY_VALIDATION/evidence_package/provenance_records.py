"""Provenance records for validation evidence."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List
from uuid import uuid4


@dataclass(frozen=True)
class ProvenanceRecord:
    subject_id: str
    source: str
    action: str
    evidence_hash: str
    parents: List[str]
    provenance_id: str = field(default_factory=lambda: f"KCN-ASI-PROV-{uuid4().hex[:12].upper()}")
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
