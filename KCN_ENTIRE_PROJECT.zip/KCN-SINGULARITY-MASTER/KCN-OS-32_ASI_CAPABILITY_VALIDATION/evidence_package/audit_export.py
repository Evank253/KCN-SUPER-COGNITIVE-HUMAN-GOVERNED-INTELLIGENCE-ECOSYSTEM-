"""Audit package export."""

from __future__ import annotations

import json
from dataclasses import asdict
from typing import Iterable


class AuditExporter:
    def export_json(self, records: Iterable[object]) -> str:
        payload = [asdict(record) if hasattr(record, "__dataclass_fields__") else record for record in records]
        return json.dumps(payload, indent=2, sort_keys=True)
