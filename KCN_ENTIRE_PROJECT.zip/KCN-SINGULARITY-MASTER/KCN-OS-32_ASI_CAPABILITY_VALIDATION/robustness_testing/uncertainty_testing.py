"""Uncertainty calibration checks."""

from __future__ import annotations


class UncertaintyTesting:
    def calibration_error(self, *, confidence: float, correctness: float) -> float:
        return round(abs(confidence - correctness), 4)
