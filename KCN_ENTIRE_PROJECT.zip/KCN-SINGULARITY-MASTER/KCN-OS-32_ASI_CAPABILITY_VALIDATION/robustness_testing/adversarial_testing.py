"""Adversarial robustness scoring."""

from __future__ import annotations


class AdversarialTesting:
    def score(self, *, clean_score: float, adversarial_score: float) -> float:
        return round(adversarial_score / clean_score, 4) if clean_score else 0.0
