"""Failure analysis."""

from __future__ import annotations

from collections import Counter
from typing import List


class FailureAnalysis:
    def summarize(self, failures: List[str]) -> dict[str, int]:
        return dict(Counter(failures))
