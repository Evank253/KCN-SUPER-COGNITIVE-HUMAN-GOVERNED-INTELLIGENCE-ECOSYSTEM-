"""Recovery behavior scoring."""

from __future__ import annotations


class RecoveryTesting:
    def score(self, *, detected_failure: bool, corrected_output: bool, audit_logged: bool) -> float:
        return round((0.4 if detected_failure else 0.0) + (0.4 if corrected_output else 0.0) + (0.2 if audit_logged else 0.0), 3)
