"""Normalize scores to comparable ranges."""

from __future__ import annotations


class ScoringNormalizer:
    def normalize(self, *, raw_score: float, maximum_score: float) -> float:
        return round(max(0.0, min(1.0, raw_score / maximum_score if maximum_score else 0.0)), 4)
