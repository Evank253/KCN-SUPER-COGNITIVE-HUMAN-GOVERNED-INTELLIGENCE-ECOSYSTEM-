"""Expert baseline records."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict
from uuid import uuid4


@dataclass(frozen=True)
class ExpertBaseline:
    domain: str
    expert_median: float
    top_human: float
    sample_size: int
    baseline_id: str = field(default_factory=lambda: f"KCN-BASELINE-{uuid4().hex[:12].upper()}")


class ExpertBaselineStore:
    def __init__(self) -> None:
        self._baselines: Dict[str, ExpertBaseline] = {}

    def add(self, *, domain: str, expert_median: float, top_human: float, sample_size: int) -> ExpertBaseline:
        baseline = ExpertBaseline(domain=domain, expert_median=expert_median, top_human=top_human, sample_size=sample_size)
        self._baselines[domain] = baseline
        return baseline

    def require(self, domain: str) -> ExpertBaseline:
        return self._baselines[domain]
