"""Compare candidate scores to human baselines."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ComparisonResult:
    candidate_score: float
    expert_median_ratio: float
    top_human_ratio: float
    exceeds_top_human: bool


class ComparisonEngine:
    def compare(self, *, candidate_score: float, expert_median: float, top_human: float) -> ComparisonResult:
        expert_ratio = candidate_score / expert_median if expert_median else 0.0
        top_ratio = candidate_score / top_human if top_human else 0.0
        return ComparisonResult(candidate_score=candidate_score, expert_median_ratio=round(expert_ratio, 4), top_human_ratio=round(top_ratio, 4), exceeds_top_human=top_ratio > 1.0)
