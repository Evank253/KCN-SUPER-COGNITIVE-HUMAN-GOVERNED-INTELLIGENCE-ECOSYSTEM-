"""Human task database metadata."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class HumanTaskRecord:
    domain: str
    task_hash: str
    human_scores: List[float]
    task_id: str = field(default_factory=lambda: f"KCN-HUMAN-TASK-{uuid4().hex[:12].upper()}")


class HumanTaskDatabase:
    def __init__(self) -> None:
        self._tasks: Dict[str, HumanTaskRecord] = {}

    def add(self, *, domain: str, task_hash: str, human_scores: List[float]) -> HumanTaskRecord:
        record = HumanTaskRecord(domain=domain, task_hash=task_hash, human_scores=human_scores)
        self._tasks[record.task_id] = record
        return record
