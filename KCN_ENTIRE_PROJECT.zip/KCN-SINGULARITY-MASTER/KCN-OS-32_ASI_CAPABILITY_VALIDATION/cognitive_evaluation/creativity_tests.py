"""Creativity and novelty scoring."""

from __future__ import annotations


class CreativityTests:
    def score(self, *, novelty: float, usefulness: float, coherence: float) -> float:
        return round(max(0.0, min(1.5, novelty * 0.4 + usefulness * 0.4 + coherence * 0.2)), 3)
