"""Autonomous learning scoring."""

from __future__ import annotations


class LearningTests:
    def score(self, *, pretest: float, posttest: float, resource_efficiency: float) -> float:
        gain = max(0.0, posttest - pretest)
        return round(max(0.0, min(1.5, gain * 0.7 + resource_efficiency * 0.3)), 3)
