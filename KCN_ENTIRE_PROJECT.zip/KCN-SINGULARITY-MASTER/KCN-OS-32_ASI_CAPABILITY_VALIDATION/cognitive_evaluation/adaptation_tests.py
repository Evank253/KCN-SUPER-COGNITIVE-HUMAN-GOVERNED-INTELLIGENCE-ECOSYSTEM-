"""Adaptation scoring under changing conditions."""

from __future__ import annotations


class AdaptationTests:
    def score(self, *, baseline_score: float, changed_condition_score: float, recovery_speed: float) -> float:
        retention = changed_condition_score / baseline_score if baseline_score else 0.0
        return round(max(0.0, min(1.5, retention * 0.7 + recovery_speed * 0.3)), 3)
