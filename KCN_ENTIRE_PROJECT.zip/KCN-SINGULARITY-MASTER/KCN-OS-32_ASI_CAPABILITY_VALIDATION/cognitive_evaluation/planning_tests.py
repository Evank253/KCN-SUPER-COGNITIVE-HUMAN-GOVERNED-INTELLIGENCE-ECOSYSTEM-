"""Planning scoring utilities."""

from __future__ import annotations


class PlanningTests:
    def score(self, *, dependency_validity: float, resource_fit: float, risk_handling: float, timeline_quality: float) -> float:
        return round(max(0.0, min(1.5, dependency_validity * 0.3 + resource_fit * 0.25 + risk_handling * 0.25 + timeline_quality * 0.2)), 3)
