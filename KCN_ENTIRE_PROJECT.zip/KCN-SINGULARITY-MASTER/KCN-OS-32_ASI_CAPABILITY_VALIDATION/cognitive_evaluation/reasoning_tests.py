"""Reasoning scoring utilities."""

from __future__ import annotations

from typing import Dict


class ReasoningTests:
    def score(self, *, correctness: float, explanation_quality: float, consistency: float) -> float:
        return round(max(0.0, min(1.5, correctness * 0.5 + explanation_quality * 0.25 + consistency * 0.25)), 3)
