from __future__ import annotations
from identity.identity_registry import IdentityRegistry
from policy.policy_engine import PolicyEngine
from approval.approval_manager import ApprovalManager
from audit.audit_log import AuditLog
from state_management.system_state import SystemStateManager
from reality_boundary.boundary_manager import RealityBoundaryManager
from deployment_control.deployment_controller import DeploymentController
from experiment_control.experiment_controller import ExperimentController
from evidence_bridge.evidence_bridge import EvidenceBridge

class ControlPlane:
    def __init__(self):
        self.identity = IdentityRegistry()
        self.policy = PolicyEngine()
        self.approvals = ApprovalManager()
        self.audit = AuditLog()
        self.state = SystemStateManager()
        self.boundary = RealityBoundaryManager()
        self.deployment = DeploymentController()
        self.experiments = ExperimentController()
        self.evidence = EvidenceBridge()

    def authorize_action(self, *, actor_id: str, action: str, context: dict) -> dict:
        decision = self.policy.evaluate(action=action, context={**context, "actor_id": actor_id})
        self.audit.record(event_type="ACTION_AUTHORIZATION", actor_id=actor_id, payload={"action": action, "allowed": decision.allowed})
        return {"allowed": decision.allowed, "reasons": decision.reasons, "matched_rules": decision.matched_rules}
