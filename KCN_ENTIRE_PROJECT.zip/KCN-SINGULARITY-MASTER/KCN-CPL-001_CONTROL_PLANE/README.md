# KCN-CPL-001 — Control Plane

The KCN Control Plane is the simple management layer that governs complex intelligence systems.

It answers:

> Who can do what, when, in which environment, and under whose approval?

## Purpose

Manage:

- identities
- roles and permissions
- policies
- approval workflows
- system states
- deployments
- experiments
- audit logs
- evidence links
- reality-boundary transitions

## Core Rule

```text
Intelligence may be complex.
Control must stay explicit.
```

## Reality Boundary

```text
SIMULATION
  ↓ requires validation
TEST
  ↓ requires human review
PREVIEW
  ↓ requires approval
PRODUCTION
  ↓ monitored real-world operation
```

No agent, runtime, deployment, or experiment may cross boundaries without a valid transition decision.

## Run Tests

```bash
cd KCN-SINGULARITY-MASTER/KCN-CPL-001_CONTROL_PLANE
python -m unittest discover -s tests -v
```
