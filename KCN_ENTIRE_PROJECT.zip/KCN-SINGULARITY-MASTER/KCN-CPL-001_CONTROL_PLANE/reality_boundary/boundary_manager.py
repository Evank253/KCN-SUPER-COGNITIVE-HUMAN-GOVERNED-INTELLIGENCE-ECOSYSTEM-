from __future__ import annotations
from dataclasses import dataclass

BOUNDARIES = ["SIMULATION", "TEST", "PREVIEW", "PRODUCTION"]

@dataclass(frozen=True)
class BoundaryDecision:
    from_boundary: str
    to_boundary: str
    allowed: bool
    reason: str

class RealityBoundaryManager:
    def transition_allowed(self, *, from_boundary: str, to_boundary: str, validated: bool, human_approved: bool) -> BoundaryDecision:
        if from_boundary not in BOUNDARIES or to_boundary not in BOUNDARIES:
            return BoundaryDecision(from_boundary, to_boundary, False, "unknown boundary")
        if BOUNDARIES.index(to_boundary) < BOUNDARIES.index(from_boundary):
            return BoundaryDecision(from_boundary, to_boundary, True, "rollback or downgrade allowed")
        if to_boundary == "PRODUCTION" and not human_approved:
            return BoundaryDecision(from_boundary, to_boundary, False, "production requires human approval")
        if BOUNDARIES.index(to_boundary) > BOUNDARIES.index(from_boundary) and not validated:
            return BoundaryDecision(from_boundary, to_boundary, False, "forward transition requires validation")
        return BoundaryDecision(from_boundary, to_boundary, True, "transition allowed")
