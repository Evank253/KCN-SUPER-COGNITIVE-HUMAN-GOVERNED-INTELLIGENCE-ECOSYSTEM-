from __future__ import annotations
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class ApprovalRequest:
    action: str
    subject_id: str
    reason: str
    request_id: str = field(default_factory=lambda: f"KCN-CPL-APPROVAL-{uuid4().hex[:12].upper()}")
    status: str = "PENDING"

@dataclass(frozen=True)
class ApprovalDecision:
    request_id: str
    approved: bool
    approver_id: str
    rationale: str

class ApprovalManager:
    def __init__(self):
        self.requests: dict[str, ApprovalRequest] = {}
        self.decisions: dict[str, ApprovalDecision] = {}
    def request(self, *, action: str, subject_id: str, reason: str) -> ApprovalRequest:
        req = ApprovalRequest(action, subject_id, reason)
        self.requests[req.request_id] = req
        return req
    def decide(self, *, request_id: str, approved: bool, approver_id: str, rationale: str) -> ApprovalDecision:
        if request_id not in self.requests:
            raise KeyError("unknown approval request")
        dec = ApprovalDecision(request_id, approved, approver_id, rationale)
        self.decisions[request_id] = dec
        return dec
    def is_approved(self, request_id: str) -> bool:
        return bool(self.decisions.get(request_id) and self.decisions[request_id].approved)
