from __future__ import annotations
import hashlib, json
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class EvidenceLink:
    subject_id: str
    evidence_type: str
    uri: str
    evidence_hash: str
    link_id: str = field(default_factory=lambda: f"KCN-CPL-EVIDENCE-{uuid4().hex[:12].upper()}")

class EvidenceBridge:
    def link(self, *, subject_id: str, evidence_type: str, uri: str, payload: dict) -> EvidenceLink:
        h = "sha256:" + hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()
        return EvidenceLink(subject_id, evidence_type, uri, h)
