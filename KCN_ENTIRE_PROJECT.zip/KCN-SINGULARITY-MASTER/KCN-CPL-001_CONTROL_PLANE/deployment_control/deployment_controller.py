from __future__ import annotations
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class DeploymentDecision:
    build_id: str
    environment: str
    allowed: bool
    reason: str
    decision_id: str = field(default_factory=lambda: f"KCN-CPL-DEPLOY-{uuid4().hex[:12].upper()}")

class DeploymentController:
    def decide(self, *, build_id: str, environment: str, tests_passed: bool, security_score: float, human_approved: bool) -> DeploymentDecision:
        if environment == "production" and not human_approved:
            return DeploymentDecision(build_id, environment, False, "production requires human approval")
        if not tests_passed:
            return DeploymentDecision(build_id, environment, False, "tests failed")
        if security_score < 0.8:
            return DeploymentDecision(build_id, environment, False, "security score below threshold")
        return DeploymentDecision(build_id, environment, True, "deployment allowed")
