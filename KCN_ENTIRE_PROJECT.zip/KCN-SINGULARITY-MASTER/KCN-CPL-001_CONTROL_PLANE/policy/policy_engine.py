from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable
from uuid import uuid4

PolicyFn = Callable[[dict], bool]

@dataclass(frozen=True)
class PolicyRule:
    name: str
    description: str
    evaluator: PolicyFn
    severity: str = "MEDIUM"
    rule_id: str = field(default_factory=lambda: f"KCN-CPL-POLICY-{uuid4().hex[:12].upper()}")

@dataclass(frozen=True)
class PolicyDecision:
    action: str
    allowed: bool
    reasons: list[str]
    matched_rules: list[str]

class PolicyEngine:
    def __init__(self):
        self._rules: list[PolicyRule] = []
    def add_rule(self, *, name: str, description: str, evaluator: PolicyFn, severity: str = "MEDIUM") -> PolicyRule:
        rule = PolicyRule(name=name, description=description, evaluator=evaluator, severity=severity)
        self._rules.append(rule)
        return rule
    def evaluate(self, *, action: str, context: dict) -> PolicyDecision:
        allowed = True
        reasons=[]
        matched=[]
        for rule in self._rules:
            ok = bool(rule.evaluator({**context, "action": action}))
            if not ok:
                allowed = False
                matched.append(rule.name)
                reasons.append(rule.description)
        if allowed:
            reasons.append("all policy checks passed")
        return PolicyDecision(action, allowed, reasons, matched)
