from __future__ import annotations
import hashlib, json, time
from dataclasses import dataclass, asdict, field
from uuid import uuid4

@dataclass(frozen=True)
class AuditEvent:
    event_type: str
    actor_id: str
    payload: dict
    timestamp: float = field(default_factory=time.time)
    event_id: str = field(default_factory=lambda: f"KCN-CPL-AUDIT-{uuid4().hex[:12].upper()}")
    event_hash: str = ""

class AuditLog:
    def __init__(self):
        self.events: list[AuditEvent] = []
    def record(self, *, event_type: str, actor_id: str, payload: dict) -> AuditEvent:
        base = AuditEvent(event_type=event_type, actor_id=actor_id, payload=payload)
        data = asdict(base); data["event_hash"] = ""
        h = "sha256:" + hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()
        event = AuditEvent(**{**data, "event_hash": h})
        self.events.append(event)
        return event
    def verify(self) -> bool:
        for event in self.events:
            data = asdict(event); expected = data.pop("event_hash")
            data["event_hash"] = ""
            if expected != "sha256:" + hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest():
                return False
        return True
