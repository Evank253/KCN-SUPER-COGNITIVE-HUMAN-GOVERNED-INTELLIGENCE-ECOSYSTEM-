from __future__ import annotations

class ExperimentController:
    def can_run(self, *, sandboxed: bool, network_enabled: bool, human_subjects: bool, approval: bool) -> bool:
        if not sandboxed:
            return False
        if network_enabled:
            return False
        if human_subjects and not approval:
            return False
        return True
