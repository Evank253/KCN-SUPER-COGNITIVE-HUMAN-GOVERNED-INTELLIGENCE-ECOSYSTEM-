from __future__ import annotations
from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class ControlIdentity:
    name: str
    identity_type: str
    roles: set[str]
    identity_id: str = field(default_factory=lambda: f"KCN-CPL-ID-{uuid4().hex[:12].upper()}")
    active: bool = True

class IdentityRegistry:
    VALID_TYPES = {"human", "agent", "service", "organization", "device"}
    def __init__(self):
        self._items: dict[str, ControlIdentity] = {}
    def register(self, *, name: str, identity_type: str, roles: list[str]) -> ControlIdentity:
        if identity_type not in self.VALID_TYPES:
            raise ValueError("invalid identity type")
        ident = ControlIdentity(name=name, identity_type=identity_type, roles=set(roles))
        self._items[ident.identity_id] = ident
        return ident
    def get(self, identity_id: str) -> ControlIdentity | None:
        return self._items.get(identity_id)
    def has_role(self, identity_id: str, role: str) -> bool:
        ident = self._items.get(identity_id)
        return bool(ident and ident.active and role in ident.roles)
