from __future__ import annotations

class SystemStateManager:
    VALID = {"IDLE", "PLANNING", "RUNNING", "PAUSED", "BLOCKED", "APPROVED", "DEPLOYED", "FAILED"}
    def __init__(self):
        self.states: dict[str, str] = {}
    def set_state(self, system_id: str, state: str) -> str:
        if state not in self.VALID:
            raise ValueError("invalid system state")
        self.states[system_id] = state
        return state
    def get_state(self, system_id: str) -> str:
        return self.states.get(system_id, "IDLE")
