import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from control_plane import ControlPlane

class TestControlPlane(unittest.TestCase):
    def test_identity_policy_audit(self):
        cp=ControlPlane()
        human=cp.identity.register(name='Operator', identity_type='human', roles=['admin'])
        cp.policy.add_rule(name='block_external_spend', description='external spend blocked', evaluator=lambda ctx: ctx['action']!='external_spend')
        ok=cp.authorize_action(actor_id=human.identity_id, action='research', context={})
        no=cp.authorize_action(actor_id=human.identity_id, action='external_spend', context={})
        self.assertTrue(ok['allowed'])
        self.assertFalse(no['allowed'])
        self.assertTrue(cp.audit.verify())
    def test_approval_boundary_deployment_experiment_evidence(self):
        cp=ControlPlane()
        req=cp.approvals.request(action='deploy', subject_id='agent1', reason='production release')
        self.assertFalse(cp.approvals.is_approved(req.request_id))
        cp.approvals.decide(request_id=req.request_id, approved=True, approver_id='human1', rationale='ok')
        self.assertTrue(cp.approvals.is_approved(req.request_id))
        blocked=cp.boundary.transition_allowed(from_boundary='PREVIEW', to_boundary='PRODUCTION', validated=True, human_approved=False)
        allowed=cp.boundary.transition_allowed(from_boundary='PREVIEW', to_boundary='PRODUCTION', validated=True, human_approved=True)
        self.assertFalse(blocked.allowed)
        self.assertTrue(allowed.allowed)
        dep=cp.deployment.decide(build_id='b1', environment='production', tests_passed=True, security_score=.9, human_approved=True)
        self.assertTrue(dep.allowed)
        self.assertTrue(cp.experiments.can_run(sandboxed=True, network_enabled=False, human_subjects=True, approval=True))
        ev=cp.evidence.link(subject_id='b1', evidence_type='test_report', uri='memory://report', payload={'passed':True})
        self.assertTrue(ev.evidence_hash.startswith('sha256:'))
if __name__=='__main__': unittest.main()
