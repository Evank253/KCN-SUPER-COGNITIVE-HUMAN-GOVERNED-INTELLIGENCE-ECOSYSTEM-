# KCN Control Plane Architecture

## Position

The Control Plane sits above runtime, research, simulation, deployment, and evaluation modules.

```text
Human Authority
  ↓
Control Plane
  ├─ Identity
  ├─ Policy
  ├─ Approval
  ├─ Audit
  ├─ State
  ├─ Reality Boundary
  └─ Evidence Bridge
  ↓
Intelligence / Agents / Deployment / Evaluation
```

## Design Principle

Separate intelligence from authority.

- Intelligence proposes.
- Control plane authorizes.
- Evaluation verifies.
- Humans retain final authority for high-impact actions.
