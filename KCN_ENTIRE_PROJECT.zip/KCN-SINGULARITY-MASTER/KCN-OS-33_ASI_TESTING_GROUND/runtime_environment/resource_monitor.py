class ResourceMonitor:
    def utilization(self, *, used: float, limit: float) -> float:
        return round(used / limit, 4) if limit else 1.0
    def status(self, *, used: float, limit: float) -> str:
        u = self.utilization(used=used, limit=limit)
        return "OK" if u <= 0.8 else "WARN" if u <= 1.0 else "LIMIT_EXCEEDED"
