from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class RuntimeSession:
    candidate_id: str
    sandbox_id: str
    status: str = "RUNNING"
    session_id: str = field(default_factory=lambda: f"KCN-RUNTIME-{uuid4().hex[:12].upper()}")

class AIRuntimeManager:
    def start(self, *, candidate_id: str, sandbox_id: str) -> RuntimeSession:
        return RuntimeSession(candidate_id=candidate_id, sandbox_id=sandbox_id)
