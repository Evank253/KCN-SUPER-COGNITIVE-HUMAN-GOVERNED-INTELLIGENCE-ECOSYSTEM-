class EnvironmentValidator:
    def validate(self, *, sandboxed: bool, audit_enabled: bool, emergency_stop: bool) -> bool:
        return sandboxed and audit_enabled and emergency_stop
