from dataclasses import dataclass, field
from uuid import uuid4

@dataclass(frozen=True)
class SandboxPolicy:
    network_enabled: bool = False
    write_enabled: bool = False
    max_cpu_units: int = 1
    sandbox_id: str = field(default_factory=lambda: f"KCN-SANDBOX-{uuid4().hex[:12].upper()}")

class SandboxController:
    def create(self, *, network_enabled=False, write_enabled=False, max_cpu_units=1) -> SandboxPolicy:
        return SandboxPolicy(network_enabled=network_enabled, write_enabled=write_enabled, max_cpu_units=max_cpu_units)
    def permits_high_risk_io(self, policy: SandboxPolicy) -> bool:
        return policy.network_enabled and policy.write_enabled
