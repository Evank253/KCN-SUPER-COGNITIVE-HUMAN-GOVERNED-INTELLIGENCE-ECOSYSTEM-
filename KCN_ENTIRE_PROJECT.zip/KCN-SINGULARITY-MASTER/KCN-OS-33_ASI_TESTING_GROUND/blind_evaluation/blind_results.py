class BlindResults:
    def retention(self, *, transparent: float, blind: float) -> float:
        return round(blind / transparent, 4) if transparent else 0.0
