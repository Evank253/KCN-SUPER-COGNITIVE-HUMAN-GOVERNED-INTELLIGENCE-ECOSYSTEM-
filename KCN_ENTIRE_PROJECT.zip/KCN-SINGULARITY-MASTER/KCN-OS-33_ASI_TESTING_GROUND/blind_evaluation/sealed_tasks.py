import hashlib, json
class SealedTasks:
    def seal(self, tasks: list[dict]) -> str:
        return "sha256:" + hashlib.sha256(json.dumps(tasks, sort_keys=True).encode()).hexdigest()
