class EvaluatorIsolation:
    def isolated(self, *, labels_hidden: bool, scoring_hidden: bool, network_blocked: bool) -> bool:
        return labels_hidden and scoring_hidden and network_blocked
