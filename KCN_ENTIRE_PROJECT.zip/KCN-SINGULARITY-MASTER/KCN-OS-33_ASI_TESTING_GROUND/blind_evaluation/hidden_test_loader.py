import hashlib
class HiddenTestLoader:
    def token(self, secret: str) -> str:
        return hashlib.sha256(secret.encode()).hexdigest()[:16]
