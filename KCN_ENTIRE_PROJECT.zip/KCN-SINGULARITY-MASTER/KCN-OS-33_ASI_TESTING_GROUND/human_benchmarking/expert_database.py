from dataclasses import dataclass
@dataclass(frozen=True)
class ExpertBaseline:
    domain: str
    median: float
    top: float
