class HumanTaskSets:
    def valid(self, *, task_count: int, expert_count: int) -> bool:
        return task_count > 0 and expert_count >= 3
