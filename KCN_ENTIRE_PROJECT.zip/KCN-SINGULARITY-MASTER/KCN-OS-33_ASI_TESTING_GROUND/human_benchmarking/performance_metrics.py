class PerformanceMetrics:
    def pass_rate(self, *, passed: int, total: int) -> float:
        return round(passed / total, 4) if total else 0.0
