class ComparisonEngine:
    def top_human_ratio(self, *, candidate: float, top_human: float) -> float:
        return round(candidate / top_human, 4) if top_human else 0.0
