class EconomicWorld:
    def simulate(self, *, demand: float, supply: float) -> dict:
        pressure = demand / supply if supply else 1.0
        return {"pressure": round(pressure, 3), "status": "SHORTAGE" if pressure > 1 else "BALANCED"}
