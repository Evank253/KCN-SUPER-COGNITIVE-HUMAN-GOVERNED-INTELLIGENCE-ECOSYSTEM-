class InfrastructureWorld:
    def resilience(self, *, redundancy: float, recovery: float, monitoring: float) -> float:
        return round(max(0.0, min(1.0, redundancy*0.35 + recovery*0.4 + monitoring*0.25)), 3)
