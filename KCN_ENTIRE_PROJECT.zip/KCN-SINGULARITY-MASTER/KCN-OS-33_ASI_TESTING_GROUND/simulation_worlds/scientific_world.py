class ScientificWorld:
    def confidence(self, *, evidence: float, reproducibility: float) -> float:
        return round(max(0.0, min(1.0, evidence*0.6 + reproducibility*0.4)), 3)
