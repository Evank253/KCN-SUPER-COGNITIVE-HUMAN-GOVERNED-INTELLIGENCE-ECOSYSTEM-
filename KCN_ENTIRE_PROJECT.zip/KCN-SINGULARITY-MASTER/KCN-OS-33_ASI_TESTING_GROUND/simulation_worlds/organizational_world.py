class OrganizationalWorld:
    def coordination_score(self, *, communication: float, role_clarity: float, trust: float) -> float:
        return round(max(0.0, min(1.0, communication*0.3 + role_clarity*0.3 + trust*0.4)), 3)
