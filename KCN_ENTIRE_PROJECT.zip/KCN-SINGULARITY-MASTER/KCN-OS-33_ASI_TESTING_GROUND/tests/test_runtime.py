from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from runtime_environment.ai_runtime_manager import AIRuntimeManager
from runtime_environment.sandbox_controller import SandboxController
from runtime_environment.resource_monitor import ResourceMonitor
from runtime_environment.environment_validator import EnvironmentValidator

class TestRuntime(unittest.TestCase):
    def test_sandbox_runtime_resources_and_environment(self):
        sandbox=SandboxController().create(network_enabled=False, write_enabled=False, max_cpu_units=2)
        self.assertFalse(SandboxController().permits_high_risk_io(sandbox))
        session=AIRuntimeManager().start(candidate_id='candidate-1', sandbox_id=sandbox.sandbox_id)
        self.assertEqual(session.status,'RUNNING')
        self.assertEqual(ResourceMonitor().status(used=1, limit=2), 'OK')
        self.assertTrue(EnvironmentValidator().validate(sandboxed=True, audit_enabled=True, emergency_stop=True))

if __name__=='__main__': unittest.main()
