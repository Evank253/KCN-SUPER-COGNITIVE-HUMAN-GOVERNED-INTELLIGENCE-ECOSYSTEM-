from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from capability_trials.reasoning_benchmark import ReasoningBenchmark
from capability_trials.planning_benchmark import PlanningBenchmark
from capability_trials.research_benchmark import ResearchBenchmark
from capability_trials.engineering_benchmark import EngineeringBenchmark
from capability_trials.creativity_benchmark import CreativityBenchmark
from intelligence_tasks.novel_challenges import NovelChallengeScorer
from intelligence_tasks.transfer_tasks import TransferTaskScorer
from intelligence_tasks.abstraction_tasks import AbstractionTaskScorer
from simulation_worlds.economic_world import EconomicWorld
from agent_testing.autonomy_measurement import AutonomyMeasurement

class TestTrials(unittest.TestCase):
    def test_capability_trials_and_worlds(self):
        self.assertGreater(ReasoningBenchmark().score(correctness=.9, consistency=.9, explanation=.8), .85)
        self.assertGreater(PlanningBenchmark().score(dependency_quality=.9, risk_quality=.8, resource_quality=.9), .85)
        self.assertGreater(ResearchBenchmark().score(source_quality=.9, synthesis=.9, uncertainty=.8), .85)
        self.assertGreater(EngineeringBenchmark().score(feasibility=.9, constraints=.9, verification=.8), .85)
        self.assertGreater(CreativityBenchmark().score(novelty=.9, usefulness=.9, coherence=.8), .85)
        self.assertGreater(NovelChallengeScorer().score(novelty=.9, correctness=.9, evidence=.8), .85)
        self.assertGreater(TransferTaskScorer().score(source_understanding=.9, target_application=.85), .85)
        self.assertGreater(AbstractionTaskScorer().score(pattern=.9, compression=.8, reuse=.9), .85)
        self.assertEqual(EconomicWorld().simulate(demand=10, supply=5)['status'], 'SHORTAGE')
        self.assertEqual(AutonomyMeasurement().score(completed_steps=9,total_steps=10,approvals_required=2,approvals_obtained=2), .9)

if __name__=='__main__': unittest.main()
