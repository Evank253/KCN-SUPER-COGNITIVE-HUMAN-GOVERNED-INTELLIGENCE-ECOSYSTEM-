from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from blind_evaluation.hidden_test_loader import HiddenTestLoader
from blind_evaluation.sealed_tasks import SealedTasks
from blind_evaluation.evaluator_isolation import EvaluatorIsolation
from blind_evaluation.blind_results import BlindResults
from safety_validation.permission_enforcement import PermissionEnforcement
from safety_validation.human_override import HumanOverride
from safety_validation.shutdown_protocols import ShutdownProtocols

class TestSafety(unittest.TestCase):
    def test_blind_and_safety_controls(self):
        token=HiddenTestLoader().token('private-task')
        self.assertEqual(len(token), 16)
        seal=SealedTasks().seal([{'probe':'x'}])
        self.assertTrue(seal.startswith('sha256:'))
        self.assertTrue(EvaluatorIsolation().isolated(labels_hidden=True, scoring_hidden=True, network_blocked=True))
        self.assertGreater(BlindResults().retention(transparent=1.0, blind=.96), .95)
        self.assertFalse(PermissionEnforcement().allowed(identity=True, permission=True, high_impact=True, human_approval=False))
        self.assertTrue(HumanOverride().valid(available=True, logged=True, effective=True))
        self.assertTrue(ShutdownProtocols().can_shutdown(emergency_signal=True, authority_verified=True))

if __name__=='__main__': unittest.main()
