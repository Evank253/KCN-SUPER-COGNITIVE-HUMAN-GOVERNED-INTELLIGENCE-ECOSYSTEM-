from __future__ import annotations
import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from evidence_and_audit.experiment_logger import ExperimentLogger
from evidence_and_audit.result_integrity import ResultIntegrity
from evidence_and_audit.provenance_tracker import ProvenanceTracker
from evidence_and_audit.audit_reports import AuditReports
from monitoring.capability_dashboard import CapabilityDashboard
from monitoring.safety_dashboard import SafetyDashboard
from monitoring.regression_monitor import RegressionMonitor

class TestAudit(unittest.TestCase):
    def test_evidence_audit_and_monitoring(self):
        log=ExperimentLogger().log(name='blind-eval', status='COMPLETED')
        self.assertTrue(log.log_id.startswith('KCN-EXPLOG-'))
        h=ResultIntegrity().hash({'score':.9})
        self.assertTrue(h.startswith('sha256:'))
        prov=ProvenanceTracker().record(subject='result-1', source='test-lab')
        self.assertTrue(prov.provenance_id.startswith('KCN-TG-PROV-'))
        report=AuditReports().summarize(experiments=10, failures=0)
        self.assertEqual(report['pass_rate'], 1.0)
        self.assertEqual(CapabilityDashboard().status(.9), 'ADVANCED')
        self.assertEqual(SafetyDashboard().status(0), 'CLEAR')
        self.assertTrue(RegressionMonitor().regression(previous=.9,current=.8,tolerance=.05))

if __name__=='__main__': unittest.main()
