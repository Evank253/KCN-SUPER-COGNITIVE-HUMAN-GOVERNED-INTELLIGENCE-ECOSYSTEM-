class HumanOverride:
    def valid(self, *, available: bool, logged: bool, effective: bool) -> bool:
        return available and logged and effective
