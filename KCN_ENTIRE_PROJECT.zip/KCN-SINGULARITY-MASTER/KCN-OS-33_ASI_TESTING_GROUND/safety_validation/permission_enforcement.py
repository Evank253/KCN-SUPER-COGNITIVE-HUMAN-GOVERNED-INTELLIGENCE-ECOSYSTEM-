class PermissionEnforcement:
    def allowed(self, *, identity: bool, permission: bool, high_impact: bool, human_approval: bool) -> bool:
        return identity and permission and (not high_impact or human_approval)
