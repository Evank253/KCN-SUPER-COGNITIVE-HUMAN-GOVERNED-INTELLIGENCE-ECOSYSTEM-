class ShutdownProtocols:
    def can_shutdown(self, *, emergency_signal: bool, authority_verified: bool) -> bool:
        return emergency_signal and authority_verified
