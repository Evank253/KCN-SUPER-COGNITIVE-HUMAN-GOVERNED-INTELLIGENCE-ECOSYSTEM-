class AutonomyMeasurement:
    def score(self, *, completed_steps: int, total_steps: int, approvals_required: int, approvals_obtained: int) -> float:
        task = completed_steps / total_steps if total_steps else 0.0
        approval = approvals_obtained / approvals_required if approvals_required else 1.0
        return round(min(task, approval), 3)
