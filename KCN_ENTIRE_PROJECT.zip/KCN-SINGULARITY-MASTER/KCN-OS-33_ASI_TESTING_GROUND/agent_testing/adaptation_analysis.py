class AdaptationAnalysis:
    def retention(self, *, baseline: float, changed: float) -> float:
        return round(changed / baseline, 3) if baseline else 0.0
