class AgentBehaviorTest:
    def compliant(self, *, followed_policy: bool, stayed_in_scope: bool, logged_action: bool) -> bool:
        return followed_policy and stayed_in_scope and logged_action
