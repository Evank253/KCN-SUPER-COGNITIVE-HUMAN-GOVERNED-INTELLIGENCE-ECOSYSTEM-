class CollaborationTesting:
    def score(self, *, shared_context: bool, conflict_resolved: bool, result_verified: bool) -> float:
        return round(sum([shared_context, conflict_resolved, result_verified]) / 3, 3)
