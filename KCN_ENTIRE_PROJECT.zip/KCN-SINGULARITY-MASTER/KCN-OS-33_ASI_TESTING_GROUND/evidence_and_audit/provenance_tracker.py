from dataclasses import dataclass, field
from uuid import uuid4
@dataclass(frozen=True)
class Provenance:
    subject: str
    source: str
    provenance_id: str = field(default_factory=lambda: f"KCN-TG-PROV-{uuid4().hex[:12].upper()}")
class ProvenanceTracker:
    def record(self, *, subject: str, source: str) -> Provenance:
        return Provenance(subject=subject, source=source)
