import hashlib, json
class ResultIntegrity:
    def hash(self, result: dict) -> str:
        return "sha256:" + hashlib.sha256(json.dumps(result, sort_keys=True).encode()).hexdigest()
