class AuditReports:
    def summarize(self, *, experiments: int, failures: int) -> dict:
        return {"experiments": experiments, "failures": failures, "pass_rate": round((experiments-failures)/experiments, 4) if experiments else 0.0}
