from dataclasses import dataclass, field
from uuid import uuid4
@dataclass(frozen=True)
class ExperimentLog:
    name: str
    status: str
    log_id: str = field(default_factory=lambda: f"KCN-EXPLOG-{uuid4().hex[:12].upper()}")
class ExperimentLogger:
    def log(self, *, name: str, status: str) -> ExperimentLog:
        return ExperimentLog(name=name, status=status)
