class TransferTaskScorer:
    def score(self, *, source_understanding: float, target_application: float) -> float:
        return round(max(0.0, min(1.0, source_understanding*0.4 + target_application*0.6)), 3)
