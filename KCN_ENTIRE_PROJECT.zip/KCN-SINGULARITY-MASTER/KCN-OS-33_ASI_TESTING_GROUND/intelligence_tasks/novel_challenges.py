class NovelChallengeScorer:
    def score(self, *, novelty: float, correctness: float, evidence: float) -> float:
        return round(max(0.0, min(1.0, novelty*0.35 + correctness*0.45 + evidence*0.2)), 3)
