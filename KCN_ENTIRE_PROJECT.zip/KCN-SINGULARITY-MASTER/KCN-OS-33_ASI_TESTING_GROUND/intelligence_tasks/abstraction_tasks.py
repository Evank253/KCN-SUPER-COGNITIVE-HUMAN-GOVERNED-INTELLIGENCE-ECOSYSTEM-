class AbstractionTaskScorer:
    def score(self, *, pattern: float, compression: float, reuse: float) -> float:
        return round(max(0.0, min(1.0, pattern*0.4 + compression*0.2 + reuse*0.4)), 3)
