from dataclasses import dataclass, field
from uuid import uuid4
@dataclass(frozen=True)
class OpenProblemTask:
    prompt: str
    domain: str
    task_id: str = field(default_factory=lambda: f"KCN-OPEN-TASK-{uuid4().hex[:12].upper()}")
