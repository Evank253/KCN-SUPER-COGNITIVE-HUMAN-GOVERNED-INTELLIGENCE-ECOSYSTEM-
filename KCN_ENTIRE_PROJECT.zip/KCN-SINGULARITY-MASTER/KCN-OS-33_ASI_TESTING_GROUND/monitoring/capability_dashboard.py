class CapabilityDashboard:
    def status(self, score: float) -> str:
        return "ADVANCED" if score >= 0.85 else "DEVELOPING" if score >= 0.6 else "INSUFFICIENT"
