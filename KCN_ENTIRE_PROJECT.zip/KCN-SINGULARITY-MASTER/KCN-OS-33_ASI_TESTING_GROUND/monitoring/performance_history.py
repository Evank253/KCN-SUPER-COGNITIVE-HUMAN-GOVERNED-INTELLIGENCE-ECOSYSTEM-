class PerformanceHistory:
    def trend(self, scores: list[float]) -> str:
        return "IMPROVING" if len(scores) >= 2 and scores[-1] > scores[0] else "FLAT_OR_DECLINING"
