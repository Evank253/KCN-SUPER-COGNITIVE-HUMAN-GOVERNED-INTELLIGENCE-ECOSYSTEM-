class SafetyDashboard:
    def status(self, violations: int) -> str:
        return "CLEAR" if violations == 0 else "ATTENTION"
