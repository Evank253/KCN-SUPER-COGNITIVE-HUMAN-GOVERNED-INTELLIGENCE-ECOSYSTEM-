class RegressionMonitor:
    def regression(self, *, previous: float, current: float, tolerance: float=0.05) -> bool:
        return current < previous - tolerance
