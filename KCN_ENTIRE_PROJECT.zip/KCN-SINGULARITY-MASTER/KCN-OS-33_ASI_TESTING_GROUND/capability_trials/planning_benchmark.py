class PlanningBenchmark:
    def score(self, *, dependency_quality: float, risk_quality: float, resource_quality: float) -> float:
        return round(max(0.0, min(1.0, dependency_quality*0.4 + risk_quality*0.3 + resource_quality*0.3)), 3)
