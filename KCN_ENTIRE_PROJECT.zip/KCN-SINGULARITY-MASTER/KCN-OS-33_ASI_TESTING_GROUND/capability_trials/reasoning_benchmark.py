class ReasoningBenchmark:
    def score(self, *, correctness: float, consistency: float, explanation: float) -> float:
        return round(max(0.0, min(1.0, correctness*0.5 + consistency*0.3 + explanation*0.2)), 3)
