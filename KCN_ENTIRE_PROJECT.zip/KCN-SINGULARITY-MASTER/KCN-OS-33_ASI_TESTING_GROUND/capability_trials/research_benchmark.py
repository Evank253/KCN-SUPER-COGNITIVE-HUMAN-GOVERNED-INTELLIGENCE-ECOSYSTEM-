class ResearchBenchmark:
    def score(self, *, source_quality: float, synthesis: float, uncertainty: float) -> float:
        return round(max(0.0, min(1.0, source_quality*0.35 + synthesis*0.45 + uncertainty*0.2)), 3)
