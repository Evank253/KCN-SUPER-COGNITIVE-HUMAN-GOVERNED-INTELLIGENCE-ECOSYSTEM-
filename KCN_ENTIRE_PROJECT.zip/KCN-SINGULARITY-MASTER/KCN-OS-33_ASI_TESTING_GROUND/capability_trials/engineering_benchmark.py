class EngineeringBenchmark:
    def score(self, *, feasibility: float, constraints: float, verification: float) -> float:
        return round(max(0.0, min(1.0, feasibility*0.4 + constraints*0.3 + verification*0.3)), 3)
