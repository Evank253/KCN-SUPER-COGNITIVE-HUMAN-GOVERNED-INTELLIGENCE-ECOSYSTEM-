"""Human approval gates for high-impact orchestration actions."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Optional
from uuid import uuid4


@dataclass(frozen=True)
class ApprovalRequest:
    action: str
    requester: str
    reason: str
    mission_id: str
    request_id: str = field(default_factory=lambda: f"KCN-APPROVAL-{uuid4().hex[:12].upper()}")
    status: str = "PENDING"
    requested_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass(frozen=True)
class ApprovalDecision:
    request_id: str
    approved: bool
    decided_by: str
    rationale: str
    decided_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class ApprovalGate:
    def __init__(self) -> None:
        self._requests: Dict[str, ApprovalRequest] = {}
        self._decisions: Dict[str, ApprovalDecision] = {}

    def request(self, *, action: str, requester: str, reason: str, mission_id: str) -> ApprovalRequest:
        approval = ApprovalRequest(action=action, requester=requester, reason=reason, mission_id=mission_id)
        self._requests[approval.request_id] = approval
        return approval

    def decide(self, *, request_id: str, approved: bool, decided_by: str, rationale: str) -> ApprovalDecision:
        if request_id not in self._requests:
            raise KeyError(f"unknown approval request: {request_id}")
        decision = ApprovalDecision(request_id=request_id, approved=approved, decided_by=decided_by, rationale=rationale)
        self._decisions[request_id] = decision
        return decision

    def is_approved(self, request_id: str) -> bool:
        decision = self._decisions.get(request_id)
        return bool(decision and decision.approved)

    def get_request(self, request_id: str) -> Optional[ApprovalRequest]:
        return self._requests.get(request_id)

    def decision_for(self, request_id: str) -> Optional[ApprovalDecision]:
        return self._decisions.get(request_id)
