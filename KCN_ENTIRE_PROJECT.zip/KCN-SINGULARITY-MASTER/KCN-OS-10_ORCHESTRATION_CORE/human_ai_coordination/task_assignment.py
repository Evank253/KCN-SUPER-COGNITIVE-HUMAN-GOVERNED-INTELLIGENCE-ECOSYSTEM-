"""Task assignment manager for humans and AI workers."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class TaskAssignment:
    mission_id: str
    task_id: str
    assignee: str
    assignee_type: str
    status: str = "ASSIGNED"
    assignment_id: str = field(default_factory=lambda: f"KCN-TASKASSIGN-{uuid4().hex[:12].upper()}")
    assigned_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class TaskAssignmentManager:
    def __init__(self) -> None:
        self._assignments: Dict[str, TaskAssignment] = {}

    def assign(self, *, mission_id: str, task_id: str, assignee: str, assignee_type: str) -> TaskAssignment:
        if assignee_type not in {"human", "ai_agent", "service"}:
            raise ValueError("assignee_type must be human, ai_agent, or service")
        assignment = TaskAssignment(mission_id=mission_id, task_id=task_id, assignee=assignee, assignee_type=assignee_type)
        self._assignments[assignment.assignment_id] = assignment
        return assignment

    def list_for_mission(self, mission_id: str) -> List[TaskAssignment]:
        return [assignment for assignment in self._assignments.values() if assignment.mission_id == mission_id]
