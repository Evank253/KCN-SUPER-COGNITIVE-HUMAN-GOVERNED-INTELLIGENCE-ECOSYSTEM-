"""AI worker registration and dispatch."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Set
from uuid import uuid4


@dataclass(frozen=True)
class AgentWorker:
    name: str
    capabilities: Set[str]
    worker_id: str = field(default_factory=lambda: f"KCN-WORKER-{uuid4().hex[:12].upper()}")
    active: bool = True
    workload: int = 0


class AgentDispatcher:
    def __init__(self) -> None:
        self._workers: Dict[str, AgentWorker] = {}

    def register(self, *, name: str, capabilities: Iterable[str]) -> AgentWorker:
        if name in self._workers:
            raise ValueError(f"agent already registered: {name}")
        worker = AgentWorker(name=name, capabilities=set(capabilities))
        self._workers[name] = worker
        return worker

    def dispatch(self, capability: str) -> AgentWorker:
        candidates = [worker for worker in self._workers.values() if worker.active and capability in worker.capabilities]
        if not candidates:
            raise LookupError(f"no agent worker for capability: {capability}")
        return sorted(candidates, key=lambda worker: (worker.workload, worker.name))[0]

    def form_team(self, capabilities: Iterable[str]) -> List[AgentWorker]:
        team: List[AgentWorker] = []
        seen = set()
        for capability in capabilities:
            worker = self.dispatch(capability)
            if worker.worker_id not in seen:
                team.append(worker)
                seen.add(worker.worker_id)
        return team

    def list_workers(self) -> List[AgentWorker]:
        return sorted(self._workers.values(), key=lambda worker: worker.name)
