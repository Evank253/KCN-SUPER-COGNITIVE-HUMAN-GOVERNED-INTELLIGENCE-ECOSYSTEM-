"""Diagnostic findings for orchestration health."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List
from uuid import uuid4

from .health_monitor import HealthMonitor


@dataclass(frozen=True)
class DiagnosticFinding:
    subsystem: str
    severity: str
    finding: str
    recommendation: str
    finding_id: str = field(default_factory=lambda: f"KCN-DIAG-{uuid4().hex[:12].upper()}")
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class DiagnosticEngine:
    def __init__(self, health_monitor: HealthMonitor) -> None:
        self.health_monitor = health_monitor

    def run_diagnostics(self) -> List[DiagnosticFinding]:
        findings: List[DiagnosticFinding] = []
        for health in self.health_monitor.all():
            if health.status == "UNHEALTHY":
                findings.append(
                    DiagnosticFinding(
                        subsystem=health.subsystem,
                        severity="HIGH",
                        finding=f"Subsystem is unhealthy: {health.detail}",
                        recommendation="Open incident, pause dependent workflows, and trigger recovery plan.",
                    )
                )
            elif health.status in {"DEGRADED", "UNKNOWN", "FROZEN"}:
                findings.append(
                    DiagnosticFinding(
                        subsystem=health.subsystem,
                        severity="MEDIUM",
                        finding=f"Subsystem status requires attention: {health.status}",
                        recommendation="Review health detail and reduce workload until status improves.",
                    )
                )
        return findings
