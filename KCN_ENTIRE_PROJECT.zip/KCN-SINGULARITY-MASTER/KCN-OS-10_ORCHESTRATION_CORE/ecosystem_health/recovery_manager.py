"""Recovery planning for degraded KCN-OS subsystems."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List
from uuid import uuid4


@dataclass(frozen=True)
class RecoveryPlan:
    subsystem: str
    actions: List[str]
    priority: str
    plan_id: str = field(default_factory=lambda: f"KCN-RECOVERY-{uuid4().hex[:12].upper()}")
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class RecoveryManager:
    def __init__(self) -> None:
        self._plans: Dict[str, RecoveryPlan] = {}

    def create_plan(self, *, subsystem: str, status: str) -> RecoveryPlan:
        if status == "UNHEALTHY":
            actions = [
                "freeze dependent high-impact workflows",
                "restart subsystem adapter",
                "validate latest integrity checkpoint",
                "notify operator",
            ]
            priority = "HIGH"
        elif status == "FROZEN":
            actions = ["await operator review", "preserve event history", "keep read-only services available"]
            priority = "MEDIUM"
        else:
            actions = ["reduce routing weight", "run diagnostics", "monitor for recovery"]
            priority = "MEDIUM"
        plan = RecoveryPlan(subsystem=subsystem, actions=actions, priority=priority)
        self._plans[plan.plan_id] = plan
        return plan

    def list_plans(self) -> List[RecoveryPlan]:
        return sorted(self._plans.values(), key=lambda item: item.created_at)
