"""Health monitoring for orchestrated KCN-OS subsystems."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional


@dataclass(frozen=True)
class HealthStatus:
    subsystem: str
    status: str
    detail: str = ""
    checked_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    latency_ms: Optional[float] = None


class HealthMonitor:
    VALID_STATUS = {"HEALTHY", "DEGRADED", "UNHEALTHY", "UNKNOWN", "FROZEN"}

    def __init__(self) -> None:
        self._statuses: Dict[str, HealthStatus] = {}

    def report(self, subsystem: str, *, status: str, detail: str = "", latency_ms: Optional[float] = None) -> HealthStatus:
        if status not in self.VALID_STATUS:
            raise ValueError(f"invalid health status: {status}")
        health = HealthStatus(subsystem=subsystem, status=status, detail=detail, latency_ms=latency_ms)
        self._statuses[subsystem] = health
        return health

    def get(self, subsystem: str) -> HealthStatus:
        return self._statuses.get(subsystem, HealthStatus(subsystem=subsystem, status="UNKNOWN", detail="no report"))

    def all(self) -> List[HealthStatus]:
        return sorted(self._statuses.values(), key=lambda item: item.subsystem)

    def ecosystem_status(self) -> str:
        if not self._statuses:
            return "UNKNOWN"
        statuses = {item.status for item in self._statuses.values()}
        if "UNHEALTHY" in statuses:
            return "UNHEALTHY"
        if "DEGRADED" in statuses or "UNKNOWN" in statuses or "FROZEN" in statuses:
            return "DEGRADED"
        return "HEALTHY"
