"""Query layer for orchestration event history."""

from __future__ import annotations

from collections import Counter
from typing import Dict, List, Optional

from .ecosystem_event_bus import EcosystemEvent, EcosystemEventBus


class EventHistory:
    def __init__(self, event_bus: EcosystemEventBus) -> None:
        self.event_bus = event_bus

    def mission_timeline(self, mission_id: str) -> List[EcosystemEvent]:
        return self.event_bus.events(mission_id=mission_id)

    def count_by_type(self, *, mission_id: Optional[str] = None) -> Dict[str, int]:
        return dict(Counter(event.event_type for event in self.event_bus.events(mission_id=mission_id)))

    def severity_summary(self) -> Dict[str, int]:
        return dict(Counter(event.severity for event in self.event_bus.events()))

    def approval_events(self, mission_id: str) -> List[EcosystemEvent]:
        return [event for event in self.mission_timeline(mission_id) if event.approval_status != "NOT_REQUIRED"]
