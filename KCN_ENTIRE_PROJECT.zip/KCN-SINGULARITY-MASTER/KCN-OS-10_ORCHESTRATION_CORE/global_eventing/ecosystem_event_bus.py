"""Global event bus for the KCN-OS orchestration core."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Iterable, List, Optional

Subscriber = Callable[["EcosystemEvent"], None]


@dataclass(frozen=True)
class EcosystemEvent:
    event_id: str
    event_type: str
    actor: str
    payload: Dict[str, Any]
    timestamp: str
    mission_id: Optional[str] = None
    severity: str = "INFO"
    approval_status: str = "NOT_REQUIRED"
    previous_hash: Optional[str] = None
    event_hash: str = ""
    tags: List[str] = field(default_factory=list)


class EcosystemEventBus:
    """Append-only, hash-chained event stream for orchestration events."""

    def __init__(self, prefix: str = "KCN-OS-EVENT") -> None:
        self.prefix = prefix
        self._events: List[EcosystemEvent] = []
        self._subscribers: Dict[str, List[Subscriber]] = {}
        self._global_subscribers: List[Subscriber] = []

    def publish(
        self,
        *,
        event_type: str,
        actor: str,
        payload: Optional[Dict[str, Any]] = None,
        mission_id: Optional[str] = None,
        severity: str = "INFO",
        approval_status: str = "NOT_REQUIRED",
        tags: Optional[Iterable[str]] = None,
    ) -> EcosystemEvent:
        event_id = f"{self.prefix}-{len(self._events) + 1:06d}"
        previous_hash = self._events[-1].event_hash if self._events else None
        event = EcosystemEvent(
            event_id=event_id,
            event_type=event_type,
            actor=actor,
            payload=payload or {},
            timestamp=datetime.now(timezone.utc).isoformat(),
            mission_id=mission_id,
            severity=severity,
            approval_status=approval_status,
            previous_hash=previous_hash,
            tags=list(tags or []),
        )
        event_hash = self._hash_event(event)
        sealed = EcosystemEvent(**{**asdict(event), "event_hash": event_hash})
        self._events.append(sealed)
        self._fanout(sealed)
        return sealed

    def subscribe(self, event_type: str, callback: Subscriber) -> None:
        self._subscribers.setdefault(event_type, []).append(callback)

    def subscribe_all(self, callback: Subscriber) -> None:
        self._global_subscribers.append(callback)

    def events(self, *, mission_id: Optional[str] = None, event_type: Optional[str] = None) -> List[EcosystemEvent]:
        events = list(self._events)
        if mission_id:
            events = [event for event in events if event.mission_id == mission_id]
        if event_type:
            events = [event for event in events if event.event_type == event_type]
        return events

    def latest(self) -> Optional[EcosystemEvent]:
        return self._events[-1] if self._events else None

    def verify_integrity(self) -> bool:
        previous_hash = None
        for event in self._events:
            if event.previous_hash != previous_hash:
                return False
            expected = self._hash_event(EcosystemEvent(**{**asdict(event), "event_hash": ""}))
            if event.event_hash != expected:
                return False
            previous_hash = event.event_hash
        return True

    def to_jsonl(self) -> str:
        return "\n".join(json.dumps(asdict(event), sort_keys=True) for event in self._events)

    def _fanout(self, event: EcosystemEvent) -> None:
        for subscriber in self._global_subscribers:
            subscriber(event)
        for subscriber in self._subscribers.get(event.event_type, []):
            subscriber(event)

    @staticmethod
    def _hash_event(event: EcosystemEvent) -> str:
        payload = asdict(event)
        payload["event_hash"] = ""
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()
