"""Notification routing for important orchestration events."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Set
from uuid import uuid4

from .ecosystem_event_bus import EcosystemEvent


@dataclass(frozen=True)
class Notification:
    channel: str
    recipient: str
    subject: str
    body: str
    notification_id: str = field(default_factory=lambda: f"KCN-NOTIFY-{uuid4().hex[:12].upper()}")
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    event_id: str = ""


class NotificationRouter:
    """Routes notifications to logical channels.

    This scaffold stores notifications in memory. Production adapters can send
    email, websocket, queue, Slack/Teams, or mobile push notifications.
    """

    def __init__(self) -> None:
        self._subscriptions: Dict[str, Set[str]] = {}
        self._notifications: List[Notification] = []

    def subscribe(self, event_type: str, recipient: str) -> None:
        self._subscriptions.setdefault(event_type, set()).add(recipient)

    def route_event(self, event: EcosystemEvent, *, channel: str = "in_app") -> List[Notification]:
        notifications: List[Notification] = []
        recipients = sorted(self._subscriptions.get(event.event_type, set()) | self._subscriptions.get("*", set()))
        for recipient in recipients:
            notification = Notification(
                channel=channel,
                recipient=recipient,
                subject=f"KCN event: {event.event_type}",
                body=f"{event.actor} emitted {event.event_type} for mission {event.mission_id or 'n/a'}.",
                event_id=event.event_id,
            )
            self._notifications.append(notification)
            notifications.append(notification)
        return notifications

    def list_notifications(self, *, recipient: str | None = None) -> List[Notification]:
        notifications = list(self._notifications)
        if recipient:
            notifications = [item for item in notifications if item.recipient == recipient]
        return notifications
