from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from command_center import EcosystemDashboard, MissionControl, PriorityManager, PriorityProfile, SystemStateMonitor
from ecosystem_health import DiagnosticEngine, HealthMonitor, RecoveryManager
from global_eventing import EcosystemEventBus, EventHistory, NotificationRouter
from governance_controls import EmergencyControls, PolicyCoordinator
from human_ai_coordination import AgentDispatcher, ApprovalGate, TaskAssignmentManager
from workflow_orchestration import DependencyResolver, ExecutionPlanner, SubsystemCoordinator, WorkflowOrchestrator


class TestKCNOS10OrchestrationCore(unittest.TestCase):
    def setUp(self) -> None:
        self.event_bus = EcosystemEventBus()
        self.event_history = EventHistory(self.event_bus)
        self.health = HealthMonitor()
        self.diagnostics = DiagnosticEngine(self.health)
        self.recovery = RecoveryManager()
        self.subsystems = SubsystemCoordinator()
        self.policy = PolicyCoordinator()
        self.approvals = ApprovalGate()
        self.emergency = EmergencyControls()
        self.agents = AgentDispatcher()
        self.assignments = TaskAssignmentManager()

        self._register_subsystems()
        self._register_agents()
        for subsystem in self.subsystems.list_subsystems():
            self.health.report(subsystem.name, status="HEALTHY", detail="test heartbeat")

        self.policy.register_rule(
            name="require_mission_context",
            description="Every orchestrated action must include a mission_id.",
            evaluator=lambda ctx: bool(ctx.get("mission_id")),
        )
        self.policy.register_rule(
            name="block_unapproved_external_spend",
            description="External spending is blocked in this package scaffold.",
            evaluator=lambda ctx: ctx.get("action") != "external_spend",
            severity="HIGH",
        )

        self.orchestrator = WorkflowOrchestrator(
            subsystem_coordinator=self.subsystems,
            event_bus=self.event_bus,
            policy_coordinator=self.policy,
            approval_gate=self.approvals,
            emergency_controls=self.emergency,
        )
        self.mission_control = MissionControl(
            event_bus=self.event_bus,
            priority_manager=PriorityManager(),
            execution_planner=ExecutionPlanner(),
            workflow_orchestrator=self.orchestrator,
            agent_dispatcher=self.agents,
            task_assignments=self.assignments,
        )

    def test_autonomous_greenhouse_mission_is_planned_executed_and_tracked(self) -> None:
        mission = self.mission_control.create_mission(
            objective="Create an autonomous greenhouse business.",
            requester="creator:kcn-test",
            priority=PriorityProfile(urgency=4, impact=5, risk=3, strategic_value=5),
        )
        self.assertEqual(mission.priority_label, "CRITICAL")

        plan = self.mission_control.plan_mission(
            mission_id=mission.mission_id,
            capability_sequence=[
                "research",
                "ai_planning",
                "design_creation",
                "security_review",
                "marketplace_listing",
                "economic_tracking",
            ],
            high_impact_capabilities=["marketplace_listing", "economic_tracking"],
        )
        self.assertEqual(len(plan.steps), 6)
        self.assertEqual(len(self.assignments.list_for_mission(mission.mission_id)), 6)

        run = self.mission_control.execute_mission(mission_id=mission.mission_id, auto_approve=True)
        self.assertEqual(run.status, "COMPLETED")
        self.assertEqual(len(run.steps), 6)
        self.assertTrue(self.event_bus.verify_integrity())

        completed = self.mission_control.require_mission(mission.mission_id)
        self.assertEqual(completed.status, "COMPLETED")
        self.assertIsNotNone(completed.run_id)

        timeline = self.event_history.mission_timeline(mission.mission_id)
        event_types = [event.event_type for event in timeline]
        self.assertIn("MISSION_CREATED", event_types)
        self.assertIn("MISSION_PLANNED", event_types)
        self.assertIn("TASK_ASSIGNED", event_types)
        self.assertIn("WORKFLOW_COMPLETED", event_types)
        self.assertIn("MISSION_COMPLETED", event_types)

    def test_dashboard_health_diagnostics_and_recovery(self) -> None:
        self.health.report("KCN-OS-06_SECURITY_DEFENSE", status="DEGRADED", detail="dependency audit delayed")
        dashboard = EcosystemDashboard(
            health_monitor=self.health,
            event_history=self.event_history,
            diagnostic_engine=self.diagnostics,
        )
        snapshot = dashboard.snapshot(active_missions=2)
        self.assertEqual(snapshot.ecosystem_status, "DEGRADED")
        self.assertGreaterEqual(len(snapshot.diagnostics), 1)

        finding = self.diagnostics.run_diagnostics()[0]
        recovery_plan = self.recovery.create_plan(subsystem=finding.subsystem, status="DEGRADED")
        self.assertIn("run diagnostics", recovery_plan.actions)

        state_monitor = SystemStateMonitor(self.health)
        state = state_monitor.snapshot(active_missions=2, total_events=len(self.event_bus.events()))
        self.assertEqual(state.active_missions, 2)
        self.assertIn("KCN-OS-06_SECURITY_DEFENSE", state.subsystem_status)

    def test_policy_and_emergency_controls_block_high_impact_work(self) -> None:
        mission = self.mission_control.create_mission(
            objective="Attempt a blocked economic action.",
            requester="creator:kcn-test",
        )
        plan = self.mission_control.plan_mission(
            mission_id=mission.mission_id,
            capability_sequence=["external_spend"],
            high_impact_capabilities=["external_spend"],
        )
        with self.assertRaises(PermissionError):
            self.orchestrator.execute(plan, auto_approve=True)

        self.emergency.enter_restricted_mode("operator initiated restricted mode")
        mission2 = self.mission_control.create_mission(
            objective="Prepare marketplace package during restricted mode.",
            requester="creator:kcn-test",
        )
        plan2 = self.mission_control.plan_mission(
            mission_id=mission2.mission_id,
            capability_sequence=["marketplace_listing"],
            high_impact_capabilities=["marketplace_listing"],
        )
        with self.assertRaises(PermissionError):
            self.orchestrator.execute(plan2, auto_approve=True)

    def test_dependency_resolver_and_notifications(self) -> None:
        order = DependencyResolver().resolve({"build": ["plan"], "plan": [], "verify": ["build"]})
        self.assertEqual(order, ["plan", "build", "verify"])

        notifications = NotificationRouter()
        notifications.subscribe("MISSION_CREATED", "operator:kcn")
        self.event_bus.subscribe("MISSION_CREATED", notifications.route_event)
        self.mission_control.create_mission(objective="Notify operator test", requester="creator:kcn-test")
        self.assertEqual(len(notifications.list_notifications(recipient="operator:kcn")), 1)

    def _register_subsystems(self) -> None:
        handler = lambda payload: {"ok": True, "payload": payload}
        self.subsystems.register(
            name="KCN-OS-07_KNOWLEDGE_LEARNING",
            package="KCN-OS-07",
            capabilities=["research"],
            handler=handler,
        )
        self.subsystems.register(
            name="KCN-OS-02_AI_RUNTIME",
            package="KCN-OS-02",
            capabilities=["ai_planning"],
            handler=handler,
        )
        self.subsystems.register(
            name="KCN-OS-03_CREATOR_STUDIO",
            package="KCN-OS-03",
            capabilities=["design_creation"],
            handler=handler,
        )
        self.subsystems.register(
            name="KCN-OS-06_SECURITY_DEFENSE",
            package="KCN-OS-06",
            capabilities=["security_review"],
            handler=handler,
        )
        self.subsystems.register(
            name="KCN-OS-05_MARKETPLACE_PLATFORM",
            package="KCN-OS-05",
            capabilities=["marketplace_listing"],
            handler=handler,
        )
        self.subsystems.register(
            name="KCN-OS-09_ECONOMIC_TREASURY",
            package="KCN-OS-09",
            capabilities=["economic_tracking", "external_spend"],
            handler=handler,
        )

    def _register_agents(self) -> None:
        self.agents.register(name="ResearchAgent", capabilities=["research"])
        self.agents.register(name="PlannerAgent", capabilities=["ai_planning"])
        self.agents.register(name="CreatorAgent", capabilities=["design_creation"])
        self.agents.register(name="SecurityAgent", capabilities=["security_review"])
        self.agents.register(name="MarketplaceAgent", capabilities=["marketplace_listing"])
        self.agents.register(name="EconomicAgent", capabilities=["economic_tracking", "external_spend"])


if __name__ == "__main__":
    unittest.main()
