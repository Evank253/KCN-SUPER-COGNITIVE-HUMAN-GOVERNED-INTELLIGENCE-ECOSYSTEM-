"""Connectors for KCN-OS orchestration."""

from .subsystem_connector import ConnectorResult, SubsystemConnector

__all__ = ["ConnectorResult", "SubsystemConnector"]
