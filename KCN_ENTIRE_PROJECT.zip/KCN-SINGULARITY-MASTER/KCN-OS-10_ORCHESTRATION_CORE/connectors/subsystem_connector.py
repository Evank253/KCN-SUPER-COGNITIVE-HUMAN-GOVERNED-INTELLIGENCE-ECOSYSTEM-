"""Generic subsystem connector interface for KCN-OS orchestration."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Dict, Optional
from uuid import uuid4


@dataclass(frozen=True)
class ConnectorResult:
    connector: str
    operation: str
    accepted: bool
    payload: dict
    result_id: str = field(default_factory=lambda: f"KCN-CONNECT-{uuid4().hex[:12].upper()}")
    completed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class SubsystemConnector:
    """Adapter wrapper around package-specific subsystem calls."""

    def __init__(self, name: str, call: Optional[Callable[[str, dict], dict]] = None) -> None:
        self.name = name
        self._call = call
        self._history: Dict[str, ConnectorResult] = {}

    def execute(self, operation: str, payload: dict) -> ConnectorResult:
        if self._call is None:
            result_payload = {"message": "no adapter configured", "input": payload}
            accepted = False
        else:
            result_payload = self._call(operation, payload)
            accepted = True
        result = ConnectorResult(connector=self.name, operation=operation, accepted=accepted, payload=result_payload)
        self._history[result.result_id] = result
        return result

    def history(self) -> list[ConnectorResult]:
        return sorted(self._history.values(), key=lambda item: item.completed_at)
