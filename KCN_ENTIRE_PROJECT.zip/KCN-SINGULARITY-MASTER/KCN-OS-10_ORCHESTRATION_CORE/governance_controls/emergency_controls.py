"""Emergency controls for KCN-OS orchestration."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Optional, Set


@dataclass(frozen=True)
class EmergencyState:
    restricted_mode: bool = False
    frozen_subsystems: Set[str] = field(default_factory=set)
    reason: Optional[str] = None
    updated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class EmergencyControls:
    def __init__(self) -> None:
        self._restricted_mode = False
        self._frozen_subsystems: Set[str] = set()
        self._reason: Optional[str] = None

    def enter_restricted_mode(self, reason: str) -> EmergencyState:
        self._restricted_mode = True
        self._reason = reason
        return self.state()

    def exit_restricted_mode(self, reason: str) -> EmergencyState:
        self._restricted_mode = False
        self._reason = reason
        return self.state()

    def freeze_subsystem(self, subsystem: str, reason: str) -> EmergencyState:
        self._frozen_subsystems.add(subsystem)
        self._reason = reason
        return self.state()

    def unfreeze_subsystem(self, subsystem: str, reason: str) -> EmergencyState:
        self._frozen_subsystems.discard(subsystem)
        self._reason = reason
        return self.state()

    def can_execute(self, *, subsystem: str, high_impact: bool = False) -> bool:
        if subsystem in self._frozen_subsystems:
            return False
        if self._restricted_mode and high_impact:
            return False
        return True

    def state(self) -> EmergencyState:
        return EmergencyState(
            restricted_mode=self._restricted_mode,
            frozen_subsystems=set(self._frozen_subsystems),
            reason=self._reason,
        )
