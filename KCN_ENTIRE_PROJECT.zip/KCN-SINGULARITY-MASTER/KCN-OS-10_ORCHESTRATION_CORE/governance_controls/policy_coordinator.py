"""Global policy coordination for orchestration actions."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List
from uuid import uuid4

PolicyFn = Callable[[dict], bool]


@dataclass(frozen=True)
class PolicyRule:
    name: str
    description: str
    evaluator: PolicyFn
    rule_id: str = field(default_factory=lambda: f"KCN-POLICY-{uuid4().hex[:12].upper()}")
    severity: str = "MEDIUM"


@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    action: str
    reasons: List[str]
    matched_rules: List[str]


class PolicyCoordinator:
    def __init__(self) -> None:
        self._rules: Dict[str, PolicyRule] = {}

    def register_rule(self, *, name: str, description: str, evaluator: PolicyFn, severity: str = "MEDIUM") -> PolicyRule:
        if name in self._rules:
            raise ValueError(f"policy rule already exists: {name}")
        rule = PolicyRule(name=name, description=description, evaluator=evaluator, severity=severity)
        self._rules[name] = rule
        return rule

    def evaluate(self, *, action: str, context: dict) -> PolicyDecision:
        reasons: List[str] = []
        matched: List[str] = []
        allowed = True
        for rule in self._rules.values():
            try:
                rule_allowed = bool(rule.evaluator({**context, "action": action}))
            except Exception as exc:  # pragma: no cover - defensive path
                rule_allowed = False
                reasons.append(f"{rule.name} raised {exc.__class__.__name__}")
            if not rule_allowed:
                allowed = False
                matched.append(rule.name)
                reasons.append(rule.description)
        if allowed:
            reasons.append("all policy checks passed")
        return PolicyDecision(allowed=allowed, action=action, reasons=reasons, matched_rules=matched)
