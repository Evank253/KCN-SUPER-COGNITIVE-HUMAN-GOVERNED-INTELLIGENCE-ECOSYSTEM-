"""Workflow orchestrator for KCN-OS mission execution."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set
from uuid import uuid4

from global_eventing.ecosystem_event_bus import EcosystemEventBus
from governance_controls.emergency_controls import EmergencyControls
from governance_controls.policy_coordinator import PolicyCoordinator
from human_ai_coordination.human_approval_gate import ApprovalGate

from .execution_planner import ExecutionPlan, PlanStep
from .subsystem_coordinator import SubsystemCoordinator


@dataclass(frozen=True)
class WorkflowStep:
    step_id: str
    capability: str
    status: str
    output: dict
    completed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass(frozen=True)
class WorkflowRun:
    mission_id: str
    plan_id: str
    status: str
    steps: List[WorkflowStep]
    run_id: str = field(default_factory=lambda: f"KCN-WORKFLOW-{uuid4().hex[:12].upper()}")
    completed_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class WorkflowOrchestrator:
    def __init__(
        self,
        *,
        subsystem_coordinator: SubsystemCoordinator,
        event_bus: EcosystemEventBus,
        policy_coordinator: Optional[PolicyCoordinator] = None,
        approval_gate: Optional[ApprovalGate] = None,
        emergency_controls: Optional[EmergencyControls] = None,
    ) -> None:
        self.subsystem_coordinator = subsystem_coordinator
        self.event_bus = event_bus
        self.policy_coordinator = policy_coordinator or PolicyCoordinator()
        self.approval_gate = approval_gate or ApprovalGate()
        self.emergency_controls = emergency_controls or EmergencyControls()

    def execute(self, plan: ExecutionPlan, *, actor: str = "MissionControl", auto_approve: bool = False) -> WorkflowRun:
        completed: Set[str] = set()
        executed_steps: List[WorkflowStep] = []
        steps_by_id: Dict[str, PlanStep] = {step.step_id: step for step in plan.steps}

        while len(completed) < len(plan.steps):
            ready = [
                step
                for step in plan.steps
                if step.step_id not in completed and set(step.depends_on).issubset(completed)
            ]
            if not ready:
                raise RuntimeError("workflow cannot progress; dependency cycle detected")

            for step in ready:
                target = self.subsystem_coordinator.resolve(step.capability)
                if not self.emergency_controls.can_execute(subsystem=target.name, high_impact=step.high_impact):
                    self.event_bus.publish(
                        event_type="WORKFLOW_STEP_BLOCKED",
                        actor="EmergencyControls",
                        mission_id=plan.mission_id,
                        payload={"step_id": step.step_id, "subsystem": target.name, "reason": "emergency controls blocked execution"},
                        severity="HIGH",
                        approval_status="BLOCKED",
                    )
                    raise PermissionError(f"emergency controls blocked {step.step_id}")

                policy_decision = self.policy_coordinator.evaluate(
                    action=step.capability,
                    context={"mission_id": plan.mission_id, "step_id": step.step_id, "high_impact": step.high_impact},
                )
                if not policy_decision.allowed:
                    self.event_bus.publish(
                        event_type="WORKFLOW_STEP_POLICY_REJECTED",
                        actor="PolicyCoordinator",
                        mission_id=plan.mission_id,
                        payload={"step_id": step.step_id, "reasons": policy_decision.reasons},
                        severity="HIGH",
                        approval_status="REJECTED",
                    )
                    raise PermissionError(f"policy rejected {step.step_id}: {policy_decision.reasons}")

                approval_status = "NOT_REQUIRED"
                if step.requires_approval:
                    request = self.approval_gate.request(
                        action=step.capability,
                        requester=actor,
                        reason=f"High-impact orchestration step {step.step_id} requires review.",
                        mission_id=plan.mission_id,
                    )
                    if auto_approve:
                        self.approval_gate.decide(
                            request_id=request.request_id,
                            approved=True,
                            decided_by="test-operator",
                            rationale="Auto-approved for controlled integration test.",
                        )
                    if not self.approval_gate.is_approved(request.request_id):
                        approval_status = "PENDING"
                        self.event_bus.publish(
                            event_type="HUMAN_APPROVAL_REQUIRED",
                            actor="ApprovalGate",
                            mission_id=plan.mission_id,
                            payload={"step_id": step.step_id, "request_id": request.request_id, "action": step.capability},
                            severity="MEDIUM",
                            approval_status=approval_status,
                        )
                        raise PermissionError(f"approval required for {step.step_id}: {request.request_id}")
                    approval_status = "APPROVED"

                self.event_bus.publish(
                    event_type="WORKFLOW_STEP_STARTED",
                    actor=actor,
                    mission_id=plan.mission_id,
                    payload={"step_id": step.step_id, "capability": step.capability, "subsystem": target.name},
                    approval_status=approval_status,
                )
                dispatch_result = self.subsystem_coordinator.dispatch(
                    capability=step.capability,
                    payload={"mission_id": plan.mission_id, "plan_id": plan.plan_id, "step_id": step.step_id, "objective": plan.objective},
                )
                status = "COMPLETED" if dispatch_result.get("accepted") else "DISPATCHED"
                workflow_step = WorkflowStep(step_id=step.step_id, capability=step.capability, status=status, output=dispatch_result)
                executed_steps.append(workflow_step)
                completed.add(step.step_id)
                self.event_bus.publish(
                    event_type="WORKFLOW_STEP_COMPLETED",
                    actor=target.name,
                    mission_id=plan.mission_id,
                    payload={"step_id": step.step_id, "capability": step.capability, "status": status},
                    approval_status=approval_status,
                )

        run = WorkflowRun(mission_id=plan.mission_id, plan_id=plan.plan_id, status="COMPLETED", steps=executed_steps)
        self.event_bus.publish(
            event_type="WORKFLOW_COMPLETED",
            actor="WorkflowOrchestrator",
            mission_id=plan.mission_id,
            payload={"run_id": run.run_id, "steps": len(run.steps)},
            approval_status="VERIFIED",
        )
        return run
