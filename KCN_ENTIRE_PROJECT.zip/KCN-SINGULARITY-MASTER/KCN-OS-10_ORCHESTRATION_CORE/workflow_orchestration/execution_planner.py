"""Mission-to-workflow execution planning."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Iterable, List
from uuid import uuid4

from .dependency_resolver import DependencyResolver


@dataclass(frozen=True)
class PlanStep:
    step_id: str
    name: str
    capability: str
    depends_on: List[str] = field(default_factory=list)
    requires_approval: bool = False
    high_impact: bool = False


@dataclass(frozen=True)
class ExecutionPlan:
    mission_id: str
    objective: str
    steps: List[PlanStep]
    plan_id: str = field(default_factory=lambda: f"KCN-PLAN-{uuid4().hex[:12].upper()}")


class ExecutionPlanner:
    """Builds a deterministic mission plan from required capabilities."""

    def __init__(self, dependency_resolver: DependencyResolver | None = None) -> None:
        self.dependency_resolver = dependency_resolver or DependencyResolver()

    def build_plan(
        self,
        *,
        mission_id: str,
        objective: str,
        capability_sequence: Iterable[str],
        high_impact_capabilities: Iterable[str] | None = None,
    ) -> ExecutionPlan:
        high_impact = set(high_impact_capabilities or [])
        capabilities = list(capability_sequence)
        dependencies: Dict[str, List[str]] = {}
        previous_step = None
        for index, capability in enumerate(capabilities, start=1):
            step_id = f"STEP-{index:02d}-{capability.upper().replace(' ', '_')}"
            dependencies[step_id] = [previous_step] if previous_step else []
            previous_step = step_id
        order = self.dependency_resolver.resolve(dependencies)
        capability_by_step = {step_id: capability for step_id, capability in zip(dependencies.keys(), capabilities)}
        steps = [
            PlanStep(
                step_id=step_id,
                name=capability_by_step[step_id].replace("_", " ").title(),
                capability=capability_by_step[step_id],
                depends_on=list(dependencies[step_id]),
                requires_approval=capability_by_step[step_id] in high_impact,
                high_impact=capability_by_step[step_id] in high_impact,
            )
            for step_id in order
            if step_id in capability_by_step
        ]
        return ExecutionPlan(mission_id=mission_id, objective=objective, steps=steps)
