"""Subsystem coordinator for routing KCN-OS tasks."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, List, Optional, Set
from uuid import uuid4

Handler = Callable[[dict], dict]


@dataclass(frozen=True)
class SubsystemEndpoint:
    name: str
    capabilities: Set[str]
    endpoint: str = "memory://subsystem"
    subsystem_id: str = field(default_factory=lambda: f"KCN-OS-SUBSYS-{uuid4().hex[:12].upper()}")
    package: str = "unknown"
    active: bool = True


class SubsystemCoordinator:
    def __init__(self) -> None:
        self._subsystems: Dict[str, SubsystemEndpoint] = {}
        self._handlers: Dict[str, Handler] = {}

    def register(
        self,
        *,
        name: str,
        capabilities: Iterable[str],
        endpoint: str = "memory://subsystem",
        package: str = "unknown",
        handler: Optional[Handler] = None,
    ) -> SubsystemEndpoint:
        if name in self._subsystems:
            raise ValueError(f"subsystem already registered: {name}")
        endpoint_record = SubsystemEndpoint(name=name, capabilities=set(capabilities), endpoint=endpoint, package=package)
        self._subsystems[name] = endpoint_record
        if handler:
            self._handlers[name] = handler
        return endpoint_record

    def list_subsystems(self) -> List[SubsystemEndpoint]:
        return sorted(self._subsystems.values(), key=lambda item: item.name)

    def find_by_capability(self, capability: str) -> List[SubsystemEndpoint]:
        return [item for item in self.list_subsystems() if item.active and capability in item.capabilities]

    def resolve(self, capability: str) -> SubsystemEndpoint:
        matches = self.find_by_capability(capability)
        if not matches:
            raise LookupError(f"no subsystem available for capability: {capability}")
        return matches[0]

    def dispatch(self, *, capability: str, payload: dict) -> dict:
        subsystem = self.resolve(capability)
        handler = self._handlers.get(subsystem.name)
        if handler is None:
            return {
                "accepted": False,
                "subsystem": subsystem.name,
                "endpoint": subsystem.endpoint,
                "reason": "no local handler registered",
            }
        response = handler(payload)
        return {"accepted": True, "subsystem": subsystem.name, "response": response}
