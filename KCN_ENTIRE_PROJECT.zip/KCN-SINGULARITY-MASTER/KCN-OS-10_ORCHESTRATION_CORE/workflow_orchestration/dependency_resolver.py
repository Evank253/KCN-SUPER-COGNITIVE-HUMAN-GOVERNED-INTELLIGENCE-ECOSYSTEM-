"""Dependency resolver for KCN-OS orchestration plans."""

from __future__ import annotations

from typing import Dict, Iterable, List, Set


class DependencyResolver:
    """Topologically resolves named workflow dependencies."""

    def resolve(self, dependencies: Dict[str, Iterable[str]]) -> List[str]:
        remaining: Dict[str, Set[str]] = {node: set(deps) for node, deps in dependencies.items()}
        for deps in dependencies.values():
            for dep in deps:
                remaining.setdefault(dep, set())
        resolved: List[str] = []

        while remaining:
            ready = sorted(node for node, deps in remaining.items() if not deps)
            if not ready:
                raise RuntimeError(f"cyclic or unresolved dependencies: {sorted(remaining)}")
            for node in ready:
                resolved.append(node)
                remaining.pop(node)
            for deps in remaining.values():
                deps.difference_update(ready)
        return resolved
