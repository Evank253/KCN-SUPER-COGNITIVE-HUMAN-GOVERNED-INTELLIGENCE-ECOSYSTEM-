"""Mission control for the KCN-OS orchestration core."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, Iterable, List, Optional
from uuid import uuid4

from global_eventing.ecosystem_event_bus import EcosystemEventBus
from human_ai_coordination.agent_dispatcher import AgentDispatcher
from human_ai_coordination.task_assignment import TaskAssignmentManager
from workflow_orchestration.execution_planner import ExecutionPlan, ExecutionPlanner
from workflow_orchestration.workflow_orchestrator import WorkflowOrchestrator, WorkflowRun

from .priority_manager import PriorityManager, PriorityProfile


@dataclass(frozen=True)
class Mission:
    objective: str
    requester: str
    mission_id: str = field(default_factory=lambda: f"KCN-MISSION-{uuid4().hex[:12].upper()}")
    status: str = "CREATED"
    priority_label: str = "NORMAL"
    priority_score: int = 0
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    plan_id: Optional[str] = None
    run_id: Optional[str] = None


class MissionControl:
    """Creates, plans, and executes ecosystem missions."""

    def __init__(
        self,
        *,
        event_bus: EcosystemEventBus,
        priority_manager: PriorityManager,
        execution_planner: ExecutionPlanner,
        workflow_orchestrator: WorkflowOrchestrator,
        agent_dispatcher: Optional[AgentDispatcher] = None,
        task_assignments: Optional[TaskAssignmentManager] = None,
    ) -> None:
        self.event_bus = event_bus
        self.priority_manager = priority_manager
        self.execution_planner = execution_planner
        self.workflow_orchestrator = workflow_orchestrator
        self.agent_dispatcher = agent_dispatcher or AgentDispatcher()
        self.task_assignments = task_assignments or TaskAssignmentManager()
        self._missions: Dict[str, Mission] = {}
        self._plans: Dict[str, ExecutionPlan] = {}
        self._runs: Dict[str, WorkflowRun] = {}

    def create_mission(self, *, objective: str, requester: str, priority: Optional[PriorityProfile] = None) -> Mission:
        profile = priority or PriorityProfile()
        mission = Mission(
            objective=objective,
            requester=requester,
            priority_label=self.priority_manager.label(profile),
            priority_score=self.priority_manager.score(profile),
        )
        self._missions[mission.mission_id] = mission
        self.event_bus.publish(
            event_type="MISSION_CREATED",
            actor=requester,
            mission_id=mission.mission_id,
            payload={"objective": objective, "priority": mission.priority_label, "score": mission.priority_score},
            approval_status="VERIFIED",
            tags=["mission"],
        )
        return mission

    def plan_mission(
        self,
        *,
        mission_id: str,
        capability_sequence: Iterable[str],
        high_impact_capabilities: Iterable[str] | None = None,
    ) -> ExecutionPlan:
        mission = self.require_mission(mission_id)
        plan = self.execution_planner.build_plan(
            mission_id=mission.mission_id,
            objective=mission.objective,
            capability_sequence=capability_sequence,
            high_impact_capabilities=high_impact_capabilities,
        )
        self._plans[plan.plan_id] = plan
        self._missions[mission_id] = Mission(**{**mission.__dict__, "status": "PLANNED", "plan_id": plan.plan_id})
        self.event_bus.publish(
            event_type="MISSION_PLANNED",
            actor="MissionControl",
            mission_id=mission_id,
            payload={"plan_id": plan.plan_id, "steps": [step.capability for step in plan.steps]},
            approval_status="VERIFIED",
        )
        self._assign_agents(mission_id=mission_id, plan=plan)
        return plan

    def execute_mission(self, *, mission_id: str, auto_approve: bool = False) -> WorkflowRun:
        mission = self.require_mission(mission_id)
        if not mission.plan_id:
            raise RuntimeError("mission must be planned before execution")
        plan = self._plans[mission.plan_id]
        self.event_bus.publish(
            event_type="MISSION_EXECUTION_STARTED",
            actor="MissionControl",
            mission_id=mission_id,
            payload={"plan_id": plan.plan_id},
            approval_status="VERIFIED",
        )
        run = self.workflow_orchestrator.execute(plan, auto_approve=auto_approve)
        self._runs[run.run_id] = run
        self._missions[mission_id] = Mission(**{**self.require_mission(mission_id).__dict__, "status": "COMPLETED", "run_id": run.run_id})
        self.event_bus.publish(
            event_type="MISSION_COMPLETED",
            actor="MissionControl",
            mission_id=mission_id,
            payload={"run_id": run.run_id, "completed_steps": len(run.steps)},
            approval_status="VERIFIED",
        )
        return run

    def require_mission(self, mission_id: str) -> Mission:
        mission = self._missions.get(mission_id)
        if mission is None:
            raise KeyError(f"unknown mission: {mission_id}")
        return mission

    def list_missions(self, *, status: Optional[str] = None) -> List[Mission]:
        missions = list(self._missions.values())
        if status:
            missions = [mission for mission in missions if mission.status == status]
        return sorted(missions, key=lambda mission: (-mission.priority_score, mission.created_at))

    def active_count(self) -> int:
        return len([mission for mission in self._missions.values() if mission.status not in {"COMPLETED", "CANCELLED"}])

    def _assign_agents(self, *, mission_id: str, plan: ExecutionPlan) -> None:
        for step in plan.steps:
            try:
                worker = self.agent_dispatcher.dispatch(step.capability)
            except LookupError:
                continue
            assignment = self.task_assignments.assign(
                mission_id=mission_id,
                task_id=step.step_id,
                assignee=worker.name,
                assignee_type="ai_agent",
            )
            self.event_bus.publish(
                event_type="TASK_ASSIGNED",
                actor="MissionControl",
                mission_id=mission_id,
                payload={"task_id": step.step_id, "assignee": worker.name, "assignment_id": assignment.assignment_id},
                approval_status="VERIFIED",
            )
