"""Dashboard snapshots for KCN-OS orchestration."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List

from ecosystem_health.diagnostic_engine import DiagnosticEngine
from ecosystem_health.health_monitor import HealthMonitor
from global_eventing.event_history import EventHistory


@dataclass(frozen=True)
class DashboardSnapshot:
    ecosystem_status: str
    active_missions: int
    event_counts: Dict[str, int]
    health: Dict[str, str]
    diagnostics: List[str]
    generated_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class EcosystemDashboard:
    def __init__(self, *, health_monitor: HealthMonitor, event_history: EventHistory, diagnostic_engine: DiagnosticEngine) -> None:
        self.health_monitor = health_monitor
        self.event_history = event_history
        self.diagnostic_engine = diagnostic_engine

    def snapshot(self, *, active_missions: int = 0) -> DashboardSnapshot:
        diagnostics = self.diagnostic_engine.run_diagnostics()
        return DashboardSnapshot(
            ecosystem_status=self.health_monitor.ecosystem_status(),
            active_missions=active_missions,
            event_counts=self.event_history.count_by_type(),
            health={status.subsystem: status.status for status in self.health_monitor.all()},
            diagnostics=[f"{finding.severity}: {finding.subsystem}: {finding.finding}" for finding in diagnostics],
        )
