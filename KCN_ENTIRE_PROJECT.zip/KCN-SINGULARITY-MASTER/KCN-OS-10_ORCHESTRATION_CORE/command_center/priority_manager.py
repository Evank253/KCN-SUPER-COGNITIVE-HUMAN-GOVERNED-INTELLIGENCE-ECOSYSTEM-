"""Mission priority scoring for KCN-OS orchestration."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PriorityProfile:
    urgency: int = 3
    impact: int = 3
    risk: int = 3
    strategic_value: int = 3

    def normalized(self) -> "PriorityProfile":
        def clamp(value: int) -> int:
            return max(1, min(5, int(value)))

        return PriorityProfile(
            urgency=clamp(self.urgency),
            impact=clamp(self.impact),
            risk=clamp(self.risk),
            strategic_value=clamp(self.strategic_value),
        )


class PriorityManager:
    """Scores missions. Higher scores run first."""

    def score(self, profile: PriorityProfile) -> int:
        p = profile.normalized()
        # Risk reduces priority unless urgency and impact justify acceleration.
        return (p.urgency * 3) + (p.impact * 3) + (p.strategic_value * 2) - p.risk

    def label(self, profile: PriorityProfile) -> str:
        score = self.score(profile)
        if score >= 28:
            return "CRITICAL"
        if score >= 20:
            return "HIGH"
        if score >= 12:
            return "NORMAL"
        return "LOW"
