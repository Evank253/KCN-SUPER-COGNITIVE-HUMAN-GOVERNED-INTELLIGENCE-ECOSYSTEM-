"""System state snapshots for the orchestration command center."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict

from ecosystem_health.health_monitor import HealthMonitor


@dataclass(frozen=True)
class SystemStateSnapshot:
    ecosystem_status: str
    subsystem_status: Dict[str, str]
    active_missions: int
    total_events: int
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class SystemStateMonitor:
    def __init__(self, health_monitor: HealthMonitor) -> None:
        self.health_monitor = health_monitor

    def snapshot(self, *, active_missions: int = 0, total_events: int = 0) -> SystemStateSnapshot:
        return SystemStateSnapshot(
            ecosystem_status=self.health_monitor.ecosystem_status(),
            subsystem_status={item.subsystem: item.status for item in self.health_monitor.all()},
            active_missions=active_missions,
            total_events=total_events,
        )
