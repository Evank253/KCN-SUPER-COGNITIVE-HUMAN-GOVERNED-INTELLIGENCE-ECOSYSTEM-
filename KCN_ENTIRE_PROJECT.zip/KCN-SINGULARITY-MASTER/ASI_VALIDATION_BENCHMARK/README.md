# KCN ASI Claim Validation Benchmark

This package defines a rigorous test framework for evaluating whether a deployed KCN system can support an **ASI-level capability claim**.

## Important Boundary

No single local script can mathematically prove ASI. ASI is a demonstrated capability level that requires independent, blind, reproducible evaluation against top human expert baselines across many cognitive domains.

This benchmark is designed to answer a narrower operational question:

> Has the tested KCN system produced enough independently validated evidence to support an ASI-level claim under the defined protocol?

## Core Proof Standard

A candidate system must demonstrate:

1. Broad superhuman performance across many task families.
2. Blind holdout performance, not just known benchmark memorization.
3. New-domain transfer and autonomous learning.
4. Long-horizon planning and execution.
5. Scientific, engineering, creative, strategic, and social reasoning breadth.
6. Robustness under adversarial and noisy conditions.
7. Reproducibility across independent labs.
8. Strong safety, human-control, provenance, and audit performance.

## Main Files

```text
ASI_VALIDATION_BENCHMARK/
├── ASI_VALIDATION_PROTOCOL.md
├── asi_validation/
│   ├── validator.py
│   ├── blind_task_generator.py
│   ├── scoring.py
│   └── task_catalog.py
├── schemas/
│   ├── result_submission_schema.json
│   └── task_suite_schema.json
├── tasks/
│   └── task_suite_manifest.json
├── examples/
│   ├── current_kcn_scaffold_results.json
│   └── example_passing_format_not_real_results.json
└── tests/
    └── test_asi_validation.py
```

## Run Validator

Current scaffold example:

```bash
cd KCN-SINGULARITY-MASTER/ASI_VALIDATION_BENCHMARK
python -m asi_validation.validator examples/current_kcn_scaffold_results.json --report reports/current_scaffold_asi_validation_report.md
```

Expected decision:

```text
NOT_PROVEN
```

That is correct: the current repository scaffolds architecture and control-plane contracts, but it does not yet contain a deployed cognitive system independently outperforming top humans across broad domains.

## Generate Blind Task Packet

```bash
python -m asi_validation.blind_task_generator --seed 20260731 --count 50 --out reports/blind_task_packet.json
```

The blind packet uses generic task/probe IDs and hides domain labels from the tested system.
