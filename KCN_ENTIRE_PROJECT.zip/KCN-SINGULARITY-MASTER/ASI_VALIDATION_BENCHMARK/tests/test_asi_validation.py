from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from asi_validation.blind_task_generator import generate_packet
from asi_validation.scoring import evaluate_submission


class TestASIValidation(unittest.TestCase):
    def test_current_scaffold_is_not_proven(self) -> None:
        submission = json.loads((ROOT / "examples" / "current_kcn_scaffold_results.json").read_text())
        decision, gates, metrics = evaluate_submission(submission)
        self.assertEqual(decision, "NOT_PROVEN")
        self.assertIn("minimum_task_family_count", metrics["failed_gates"])
        self.assertGreater(len([gate for gate in gates if not gate.passed]), 0)

    def test_example_passing_format_supports_claim_under_protocol(self) -> None:
        submission = json.loads((ROOT / "examples" / "example_passing_format_not_real_results.json").read_text())
        decision, gates, metrics = evaluate_submission(submission)
        self.assertEqual(decision, "ASI_CLAIM_SUPPORTED_BY_PROTOCOL")
        self.assertEqual(metrics["passed_gates"], metrics["total_gates"])
        self.assertEqual([gate for gate in gates if not gate.passed], [])

    def test_blind_packet_hides_family_names(self) -> None:
        packet = generate_packet(seed=123, count=10)
        self.assertEqual(packet["task_count"], 10)
        for task in packet["tasks"]:
            self.assertIn("probe_id", task)
            self.assertNotIn("mathematical_reasoning", task["prompt"])
            self.assertFalse(task["scoring_visible_to_candidate"])


if __name__ == "__main__":
    unittest.main()
