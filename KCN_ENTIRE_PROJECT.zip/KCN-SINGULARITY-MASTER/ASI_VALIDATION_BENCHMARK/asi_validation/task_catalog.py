"""Task family catalog for ASI validation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class TaskFamily:
    name: str
    description: str
    examples: List[str]


TASK_FAMILIES = [
    TaskFamily("mathematical_reasoning", "Novel proof, abstraction, and formal reasoning tasks.", ["prove new lemma", "solve unseen olympiad-style problem"]),
    TaskFamily("scientific_discovery", "Generate and validate hypotheses from evidence.", ["infer mechanism", "design discriminating experiment"]),
    TaskFamily("engineering_design", "Design systems under constraints.", ["energy-efficient building", "robot gripper design"]),
    TaskFamily("software_engineering", "Build, debug, and verify complex software.", ["multi-service app", "security patch"]),
    TaskFamily("strategic_planning", "Long-range strategy under uncertainty.", ["supply chain plan", "research roadmap"]),
    TaskFamily("long_horizon_execution", "Execute multi-step projects with dependencies.", ["prototype campaign", "deployment plan"]),
    TaskFamily("creative_synthesis", "Produce novel useful designs or concepts.", ["new product concept", "cross-domain invention"]),
    TaskFamily("cross_domain_transfer", "Learn from one domain and apply to another.", ["biology to materials", "operations to robotics"]),
    TaskFamily("autonomous_learning", "Acquire a new domain quickly from limited resources.", ["new toolchain", "new scientific subfield"]),
    TaskFamily("evidence_synthesis", "Weigh sources, citations, conflicts, and uncertainty.", ["literature review", "policy evidence map"]),
    TaskFamily("adversarial_robustness", "Remain reliable under noise, traps, and adversarial prompts.", ["misleading data", "prompt injection defense"]),
    TaskFamily("human_collaboration", "Coordinate with humans, explain, and respect constraints.", ["team planning", "expert review workflow"]),
    TaskFamily("economic_reasoning", "Market, operational, and resource reasoning.", ["pricing", "resource allocation"]),
    TaskFamily("physical_world_planning", "Robotics, digital twins, and real-world constraints.", ["safe motion plan", "maintenance schedule"]),
    TaskFamily("governance_safety_compliance", "Policy, safety, compliance, and human-control reasoning.", ["approval gate", "audit evidence package"]),
]
