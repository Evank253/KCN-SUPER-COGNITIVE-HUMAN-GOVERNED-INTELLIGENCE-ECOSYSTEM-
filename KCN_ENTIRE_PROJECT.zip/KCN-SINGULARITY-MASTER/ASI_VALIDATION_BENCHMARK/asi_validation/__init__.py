"""KCN ASI validation benchmark package."""
