"""CLI validator for ASI claim submissions."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path

from .scoring import evaluate_submission


def build_report(submission: dict, decision: str, gates: list, metrics: dict) -> str:
    report = f"""# ASI Claim Validation Report

## Decision

**{decision}**

Generated: `{datetime.now(timezone.utc).isoformat()}`

## System Under Test

- Name: `{submission.get('system_name', 'unknown')}`
- Version: `{submission.get('system_version', 'unknown')}`
- Evaluation ID: `{submission.get('evaluation_id', 'unknown')}`

## Summary Metrics

| Metric | Value |
|---|---:|
"""
    for key, value in metrics.items():
        if key != "failed_gates":
            report += f"| {key} | {value} |\n"

    report += "\n## Gate Results\n\n| Gate | Result | Observed | Required |\n|---|---|---:|---|\n"
    for gate in gates:
        result = "PASS" if gate.passed else "FAIL"
        report += f"| {gate.name} | {result} | `{gate.observed}` | `{gate.required}` |\n"

    if metrics.get("failed_gates"):
        report += "\n## Failed Gates\n\n"
        for gate in metrics["failed_gates"]:
            report += f"- `{gate}`\n"

    report += """
## Interpretation

This protocol can support an ASI-level claim only when all gates pass under independent, blind, reproducible evaluation.

A failure does not mean the system is useless; it means ASI has not been demonstrated under this protocol.
"""
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate an ASI claim evidence submission.")
    parser.add_argument("submission", help="Path to result submission JSON")
    parser.add_argument("--report", help="Path to write markdown report")
    parser.add_argument("--json-out", help="Path to write machine-readable validation output")
    args = parser.parse_args()

    submission_path = Path(args.submission)
    submission = json.loads(submission_path.read_text())
    decision, gates, metrics = evaluate_submission(submission)

    output = {
        "decision": decision,
        "metrics": metrics,
        "gates": [asdict(gate) for gate in gates],
    }
    if args.json_out:
        Path(args.json_out).write_text(json.dumps(output, indent=2, sort_keys=True))
    if args.report:
        Path(args.report).write_text(build_report(submission, decision, gates, metrics))

    print(json.dumps(output, indent=2, sort_keys=True))
    return 0 if decision == "ASI_CLAIM_SUPPORTED_BY_PROTOCOL" else 1


if __name__ == "__main__":
    raise SystemExit(main())
