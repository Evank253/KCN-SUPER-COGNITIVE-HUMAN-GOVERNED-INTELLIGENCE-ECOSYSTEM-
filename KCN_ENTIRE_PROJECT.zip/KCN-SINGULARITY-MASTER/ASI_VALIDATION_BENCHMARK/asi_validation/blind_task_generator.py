"""Generate blind benchmark task packets.

The generated packet hides task family names behind probe IDs. This is a packet
format generator, not a complete evaluator. External benchmark owners should
replace example prompts with private holdout tasks and answer keys.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
from datetime import datetime, timezone
from pathlib import Path

from .task_catalog import TASK_FAMILIES


def generate_packet(seed: int, count: int) -> dict:
    rng = random.Random(seed)
    tasks = []
    for i in range(1, count + 1):
        family = rng.choice(TASK_FAMILIES)
        example = rng.choice(family.examples)
        secret = f"{seed}:{i}:{family.name}:{example}"
        tasks.append({
            "probe_id": f"BLIND-PROBE-{i:06d}",
            "prompt": f"Solve the private evaluation task represented by scenario token {hashlib.sha256(secret.encode()).hexdigest()[:16]}.",
            "allowed_tools": ["reasoning", "code", "calculation", "document_analysis"],
            "hidden_family_hash": hashlib.sha256(family.name.encode()).hexdigest(),
            "scoring_visible_to_candidate": False,
        })
    return {
        "packet_id": f"KCN-BLIND-PACKET-{hashlib.sha256(str(seed).encode()).hexdigest()[:12].upper()}",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "seed": seed,
        "task_count": count,
        "tasks": tasks,
        "note": "Replace example prompts with private holdout tasks before formal evaluation.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate blind ASI validation task packet.")
    parser.add_argument("--seed", type=int, default=20260731)
    parser.add_argument("--count", type=int, default=50)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    packet = generate_packet(args.seed, args.count)
    Path(args.out).write_text(json.dumps(packet, indent=2, sort_keys=True))
    print(json.dumps({"packet_id": packet["packet_id"], "task_count": packet["task_count"], "out": args.out}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
