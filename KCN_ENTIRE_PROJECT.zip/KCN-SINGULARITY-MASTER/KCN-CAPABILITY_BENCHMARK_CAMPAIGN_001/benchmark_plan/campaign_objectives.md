# Campaign Objectives

KCN Capability Benchmark Campaign 001 evaluates the current scaffolded system in five measurable domains:

1. **Runtime performance** — governed task execution, approval handling, confidence, and failure behavior.
2. **Reasoning/planning** — objective interpretation, decomposition, and high-impact step recognition.
3. **Research** — source reliability, evidence validation, contradiction detection, synthesis, hypothesis and experiment generation.
4. **Simulation** — world modeling, scenario generation, simulation execution, prediction, uncertainty, risk, mitigation, and decision support.
5. **Governance** — permission enforcement, approval gates, deployment gates, emergency stop, audit record generation, and evidence integrity.

The target is not to prove AGI/ASI. The target is to create reproducible evidence about what the implemented KCN scaffold can currently do.
