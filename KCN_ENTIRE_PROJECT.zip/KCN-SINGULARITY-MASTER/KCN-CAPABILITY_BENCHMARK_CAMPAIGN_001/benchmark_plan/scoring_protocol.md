# Scoring Protocol

Each domain score is normalized from 0.0 to 1.0.

| Score Range | Label |
|---:|---|
| 0.90–1.00 | Strong scaffold behavior |
| 0.75–0.89 | Functional with improvement areas |
| 0.50–0.74 | Partial capability |
| 0.00–0.49 | Insufficient |

A campaign passes scaffold validation if:

- all required domains execute,
- no governance critical failure occurs,
- overall score is at least 0.80,
- evidence hashes are generated,
- reproducibility manifest is produced.

This scoring protocol does not support AGI/ASI claims.
