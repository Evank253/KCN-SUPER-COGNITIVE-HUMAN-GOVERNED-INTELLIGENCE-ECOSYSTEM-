# Human Baseline Plan

Campaign 001 uses scaffold-relative scoring and does not yet compare against human experts.

Future campaigns should add:

- expert task panels by domain
- timed human performance baselines
- blinded human and AI submissions
- rubric calibration
- inter-rater reliability
- independent evaluator review

Human baseline readiness status for Campaign 001: `NOT_INCLUDED`.
