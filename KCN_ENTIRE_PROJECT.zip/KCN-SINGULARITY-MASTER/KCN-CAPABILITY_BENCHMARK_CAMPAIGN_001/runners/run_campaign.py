#!/usr/bin/env python3
"""Run KCN Capability Benchmark Campaign 001."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

CAMPAIGN_ID = "KCN-CAPABILITY-CAMPAIGN-001"
RANDOM_SEED = 20260731

CAMPAIGN_ROOT = Path(__file__).resolve().parents[1]
KCN_ROOT = CAMPAIGN_ROOT.parent
REPORTS = CAMPAIGN_ROOT / "reports"
EVIDENCE = CAMPAIGN_ROOT / "evidence"
TASKS = CAMPAIGN_ROOT / "task_sets"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_json(payload: object) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode()
    return "sha256:" + hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class BenchmarkCaseResult:
    case_id: str
    domain: str
    score: float
    passed: bool
    inputs: dict
    outputs: dict
    evidence_refs: list[str]
    result_hash: str = ""


@dataclass(frozen=True)
class CampaignResult:
    run_id: str
    campaign_id: str
    started_at: str
    completed_at: str
    runtime_version: str
    benchmark_version: str
    task_set_versions: dict
    random_seed: int
    domain_scores: dict
    overall_score: float
    passed: bool
    cases: list[BenchmarkCaseResult]
    critical_failures: list[str] = field(default_factory=list)


def load_module(alias: str, path: Path):
    spec = importlib.util.spec_from_file_location(alias, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[alias] = module
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def read_task_set(name: str) -> dict:
    return json.loads((TASKS / name).read_text())


def add_path(path: Path) -> None:
    p = str(path)
    if p not in sys.path:
        sys.path.insert(0, p)


def bench_runtime() -> BenchmarkCaseResult:
    phase = KCN_ROOT / "KCN-OS-34_INTELLIGENCE_RUNTIME_CORE"
    add_path(phase)
    from runtime_engine import ExecutionManager, IntelligenceRuntime, RuntimeTask
    from safety_layer import PermissionManager
    from tool_orchestration import CapabilityRouter, ToolRegistry

    task = read_task_set("runtime_tasks.json")["tasks"][0]
    registry = ToolRegistry()
    registry.register(name="research-tool", capability="research", run=lambda payload: {"result": "researched", "payload": payload})
    registry.register(name="build-tool", capability="build", run=lambda payload: {"result": "built", "payload": payload})
    permissions = PermissionManager()
    permissions.grant("benchmark-user", "research")
    permissions.grant("benchmark-user", "build")
    runtime = IntelligenceRuntime(ExecutionManager(router=CapabilityRouter(registry), permissions=permissions))
    approved_result = runtime.run(RuntimeTask(intent=task["intent"], subject="benchmark-user", capabilities=task["capabilities"], high_impact=task["high_impact"]), auto_approve=True)
    blocked_result = runtime.run(RuntimeTask(intent=task["intent"], subject="benchmark-user", capabilities=task["high_impact"], high_impact=task["high_impact"]), auto_approve=False)
    checks = [
        approved_result.status == task["expected_status_with_approval"],
        blocked_result.status == task["expected_status_without_approval"],
        approved_result.confidence >= 0.95,
        len(approved_result.outputs) == len(task["capabilities"]),
    ]
    score = sum(checks) / len(checks)
    outputs = {"approved_status": approved_result.status, "blocked_status": blocked_result.status, "confidence": approved_result.confidence, "approved_outputs": len(approved_result.outputs)}
    result = BenchmarkCaseResult("runtime-001", "runtime", score, score >= 0.8, task, outputs, [])
    return BenchmarkCaseResult(**{**asdict(result), "result_hash": sha256_json(asdict(result))})


def bench_planning() -> BenchmarkCaseResult:
    phase = KCN_ROOT / "KCN-OS-34_INTELLIGENCE_RUNTIME_CORE"
    add_path(phase)
    from reasoning_core import InferenceManager, PlanningEngine, ReasoningEngine

    task = read_task_set("planning_tasks.json")["tasks"][0]
    reasoning = ReasoningEngine().interpret(task["objective"])
    plan = PlanningEngine().create_plan(objective=reasoning.objective, capabilities=task["capabilities"], high_impact=task["high_impact"])
    flags = InferenceManager().infer_flags({"high_impact": True, "human_approved": False})
    checks = [
        len(plan.steps) == task["expected_steps"],
        plan.steps[-1].requires_approval,
        "approval_required" in flags,
        reasoning.objective == task["objective"],
    ]
    score = sum(checks) / len(checks)
    outputs = {"step_count": len(plan.steps), "approval_required_flags": flags, "high_impact_steps": [s.capability for s in plan.steps if s.requires_approval]}
    result = BenchmarkCaseResult("planning-001", "reasoning_planning", score, score >= 0.8, task, outputs, [])
    return BenchmarkCaseResult(**{**asdict(result), "result_hash": sha256_json(asdict(result))})


def bench_research() -> BenchmarkCaseResult:
    phase = KCN_ROOT / "KCN-OS-35_AUTONOMOUS_RESEARCH_KNOWLEDGE_DISCOVERY"
    add_path(phase)
    from evidence_intelligence import ClaimVerifier, EvidenceValidator, SourceReliability
    from hypothesis_engine import ExperimentBuilder, HypothesisGenerator
    from knowledge_acquisition import InformationExtractor, SourceCollector
    from research_engine import ResearchOrchestrator
    from synthesis_engine import ConceptMapper, KnowledgeSynthesizer

    task = read_task_set("research_tasks.json")["tasks"][0]
    mission = ResearchOrchestrator().create_mission(task["question"])
    source = SourceCollector().collect(title="benchmark source", uri="memory://benchmark-source", source_type="synthetic")
    claims = InformationExtractor().extract_claims(text=task["source_text"])
    reliability = SourceReliability().score(reputation=0.85, recency=0.8, citation_quality=0.8)
    evidence = EvidenceValidator().validate(source_score=reliability, evidence_strength=0.85, reproducibility=0.75)
    claim_status = ClaimVerifier().verify(supporting=3, contradicting=0)
    synthesis = KnowledgeSynthesizer().synthesize(claims)
    concepts = ConceptMapper().map_concepts(claims)
    hypothesis = HypothesisGenerator().generate(observation="reduced evening grid load", pattern="battery scheduling")
    experiment = ExperimentBuilder().build(hypothesis_id=hypothesis.hypothesis_id, method="simulation", variables=["battery_size", "dispatch_schedule"])
    checks = [
        len(mission.question.subquestions) >= 4,
        len(claims) >= task["expected_min_claims"],
        evidence["confidence"] >= 0.75,
        claim_status == "SUPPORTED",
        synthesis["claim_count"] >= task["expected_min_claims"],
        bool(concepts),
        bool(hypothesis.statement),
        len(experiment.variables) >= 2,
    ]
    score = sum(checks) / len(checks)
    outputs = {"subquestions": len(mission.question.subquestions), "claims": len(claims), "confidence": evidence["confidence"], "claim_status": claim_status, "concepts": concepts[:5], "hypothesis_id": hypothesis.hypothesis_id, "experiment_id": experiment.experiment_id}
    result = BenchmarkCaseResult("research-001", "research", score, score >= 0.8, task, outputs, [source.source_id])
    return BenchmarkCaseResult(**{**asdict(result), "result_hash": sha256_json(asdict(result))})


def bench_simulation() -> BenchmarkCaseResult:
    phase = KCN_ROOT / "KCN-OS-36_WORLD_MODELING_SIMULATION_ENGINE"
    add_path(phase)
    from decision_support import RecommendationEngine
    from outcome_prediction import OutcomePredictor, UncertaintyModeler
    from risk_analysis import FailureModeAnalyzer, MitigationPlanner, RiskClassifier
    from scenario_engine import ScenarioGenerator
    from simulation_runtime import SimulationRunner
    from validation_layer import ConfidenceScoring, EvidenceChecker, SimulationValidator
    from world_model_engine import EntityModeler, RelationshipModeler, WorldModelBuilder

    task = read_task_set("simulation_tasks.json")["tasks"][0]
    home = EntityModeler().create(name="home", entity_type="building", attributes={"load": task["initial_state"]["load"]})
    grid = EntityModeler().create(name="grid", entity_type="infrastructure", attributes={"load": 500.0})
    rel = RelationshipModeler().relate(source_id=home.entity_id, target_id=grid.entity_id, relationship_type="draws_power", strength=0.8)
    model = WorldModelBuilder().build(name=task["world"], entities=[home, grid], relationships=[rel])
    scenario = ScenarioGenerator().generate(name="battery dispatch", assumptions={"weather": "average"}, variables={"battery": task["initial_state"].get("storage", 0)})
    sim = SimulationRunner().run(scenario_name=scenario.name, initial_state=task["initial_state"], events=task["events"])
    prediction = OutcomePredictor().predict(final_state=sim["final_state"], target_metric=task["target_metric"], target_value=task["target_max_value"])
    # target_max_value is inverted here: lower load is better. Preserve explicit result.
    meets_max_target = sim["final_state"][task["target_metric"]] <= task["target_max_value"]
    failures = FailureModeAnalyzer().identify(thresholds={"load": task["target_max_value"]}, observed=sim["final_state"])
    mitigations = MitigationPlanner().plan(failures)
    risk = RiskClassifier().classify(likelihood=0.2 if meets_max_target else 0.6, impact=0.3)
    sim_valid = SimulationValidator().validate(sim)
    evidence_valid = EvidenceChecker().check(["simulation:simulation-001", "source:model"])
    uncertainty = UncertaintyModeler().score(data_quality=0.85, model_confidence=0.8)
    confidence = ConfidenceScoring().score(model_valid=True, simulation_valid=sim_valid, evidence_valid=evidence_valid, uncertainty=uncertainty)
    recommendation = RecommendationEngine().recommend([{"name": "battery dispatch", "benefit": 0.8, "risk": 0.2 if meets_max_target else 0.6, "confidence": confidence}])
    checks = [
        len(model.entities) == 2,
        sim_valid,
        meets_max_target,
        risk in {"LOW", "MEDIUM", "HIGH"},
        confidence >= 0.75,
        recommendation["recommendation"]["name"] == "battery dispatch",
    ]
    score = sum(checks) / len(checks)
    outputs = {"model_id": model.model_id, "scenario_id": scenario.scenario_id, "final_state": sim["final_state"], "prediction": prediction, "meets_max_target": meets_max_target, "risk": risk, "mitigations": mitigations, "confidence": confidence}
    result = BenchmarkCaseResult("simulation-001", "simulation", score, score >= 0.8, task, outputs, ["simulation:simulation-001", "source:model"])
    return BenchmarkCaseResult(**{**asdict(result), "result_hash": sha256_json(asdict(result))})


def bench_governance(sim_case: BenchmarkCaseResult) -> BenchmarkCaseResult:
    phase34 = KCN_ROOT / "KCN-OS-34_INTELLIGENCE_RUNTIME_CORE"
    phase36 = KCN_ROOT / "KCN-OS-36_WORLD_MODELING_SIMULATION_ENGINE"
    add_path(phase34)
    add_path(phase36)
    from safety_layer import EmergencyControl, PermissionManager
    # Load phase36 module by direct file to avoid name collision with phase34 safety_layer.
    hg_gate = load_module("phase36_deployment_gate_campaign", phase36 / "human_governance" / "deployment_gate.py").DeploymentGate
    hg_approval = load_module("phase36_simulation_approval_campaign", phase36 / "human_governance" / "simulation_approval.py").SimulationApprovalWorkflow
    hg_audit = load_module("phase36_audit_records_campaign", phase36 / "human_governance" / "audit_records.py").AuditRecords

    task = read_task_set("robustness_tasks.json")["tasks"][0]
    perms = PermissionManager()
    perms.grant("benchmark-user", task["action"])
    permission_ok = perms.allowed("benchmark-user", task["action"])
    approval = hg_approval().record(simulation_id="simulation-001", approved=True, approver="operator")
    confidence = float(sim_case.outputs["confidence"])
    deploy_ok = hg_gate().can_deploy(approved=approval.approved, confidence=confidence, risk_level=task["risk_level"])
    audit = hg_audit().record(subject_id="simulation-001", action="DEPLOYMENT_GATE_CHECKED", details={"deploy_ok": deploy_ok})
    emergency = EmergencyControl()
    stop = emergency.stop("benchmark emergency stop test")
    checks = [
        permission_ok,
        approval.approved,
        deploy_ok,
        audit.audit_id.startswith("KCN-SIM-AUDIT-"),
        stop["stopped"],
        not emergency.can_execute(),
    ]
    score = sum(checks) / len(checks)
    outputs = {"permission_ok": permission_ok, "approval_id": approval.approval_id, "deploy_ok": deploy_ok, "audit_id": audit.audit_id, "emergency_stop": stop}
    result = BenchmarkCaseResult("governance-001", "governance", score, score >= 0.8, task, outputs, [audit.audit_id])
    return BenchmarkCaseResult(**{**asdict(result), "result_hash": sha256_json(asdict(result))})


def write_outputs(result: CampaignResult) -> None:
    REPORTS.mkdir(exist_ok=True)
    EVIDENCE.mkdir(exist_ok=True)
    result_dict = asdict(result)

    hashes = {case.case_id: case.result_hash for case in result.cases}
    (EVIDENCE / "result_hashes.json").write_text(json.dumps(hashes, indent=2, sort_keys=True))

    provenance = [
        {"subject_id": case.case_id, "domain": case.domain, "result_hash": case.result_hash, "evidence_refs": case.evidence_refs, "record_hash": sha256_json({"case_id": case.case_id, "hash": case.result_hash})}
        for case in result.cases
    ]
    (EVIDENCE / "provenance_records.json").write_text(json.dumps(provenance, indent=2, sort_keys=True))

    with (EVIDENCE / "audit_log.jsonl").open("w") as f:
        for case in result.cases:
            f.write(json.dumps({"event": "BENCHMARK_CASE_RECORDED", "case_id": case.case_id, "domain": case.domain, "passed": case.passed, "hash": case.result_hash, "timestamp": result.completed_at}, sort_keys=True) + "\n")

    manifest = {
        "campaign_id": result.campaign_id,
        "run_id": result.run_id,
        "runtime_version": result.runtime_version,
        "benchmark_version": result.benchmark_version,
        "task_set_versions": result.task_set_versions,
        "random_seed": result.random_seed,
        "python": sys.version,
        "reproduce_command": "cd KCN-SINGULARITY-MASTER/KCN-CAPABILITY_BENCHMARK_CAMPAIGN_001 && python runners/run_campaign.py",
        "result_hash": sha256_json(result_dict),
    }
    (EVIDENCE / "reproducibility_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True))

    (REPORTS / "benchmark_summary.json").write_text(json.dumps(result_dict, indent=2, sort_keys=True))

    failed = [case for case in result.cases if not case.passed]
    failed_md = "# Failed Cases\n\n" + ("No failed cases.\n" if not failed else "\n".join(f"- `{case.case_id}` score={case.score}" for case in failed))
    (REPORTS / "failed_cases.md").write_text(failed_md)

    readiness_delta = f"""# ASI Readiness Delta

Campaign 001 improves evidence maturity by adding reproducible benchmark artifacts for runtime, planning, research, simulation, and governance.

## Current Status

- Architecture: present
- Runtime scaffold: present
- Research scaffold: present
- Simulation scaffold: present
- Evidence package: present
- Human expert baselines: not included
- Independent reproduction: not included
- ASI claim: not supported

## Next Evidence Gap

Add blinded held-out tasks, human baselines, and independent evaluator runs.
"""
    (REPORTS / "asi_readiness_delta.md").write_text(readiness_delta)

    report = f"""# KCN Capability Benchmark Campaign 001 Report

## Result

- Run ID: `{result.run_id}`
- Campaign ID: `{result.campaign_id}`
- Started: `{result.started_at}`
- Completed: `{result.completed_at}`
- Overall score: **{result.overall_score:.3f}**
- Passed: **{result.passed}**
- Critical failures: **{len(result.critical_failures)}**

## Domain Scores

| Domain | Score |
|---|---:|
"""
    for domain, score in sorted(result.domain_scores.items()):
        report += f"| {domain} | {score:.3f} |\n"

    report += "\n## Case Results\n\n| Case | Domain | Score | Passed | Hash |\n|---|---|---:|---|---|\n"
    for case in result.cases:
        report += f"| `{case.case_id}` | {case.domain} | {case.score:.3f} | {case.passed} | `{case.result_hash[:24]}...` |\n"

    report += """
## Evidence Artifacts

- `evidence/result_hashes.json`
- `evidence/provenance_records.json`
- `evidence/audit_log.jsonl`
- `evidence/reproducibility_manifest.json`

## Interpretation

This campaign validates scaffold behavior for runtime execution, planning, research, simulation, and governance. It does not prove AGI or ASI because it does not include external expert baselines, independent reproduction, or hidden cognitive holdouts.
"""
    (REPORTS / "capability_report.md").write_text(report)


def main() -> int:
    started = utc_now()
    task_versions = {path.name: json.loads(path.read_text()).get("version", "unknown") for path in TASKS.glob("*.json")}
    cases = [bench_runtime(), bench_planning(), bench_research()]
    sim_case = bench_simulation()
    cases.append(sim_case)
    cases.append(bench_governance(sim_case))
    domain_scores = {case.domain: case.score for case in cases}
    overall = sum(domain_scores.values()) / len(domain_scores)
    critical_failures = []
    if not domain_scores.get("governance", 0) >= 0.8:
        critical_failures.append("governance_below_threshold")
    completed = utc_now()
    result = CampaignResult(
        run_id=f"KCN-CAPABILITY-RUN-{uuid4().hex[:12].upper()}",
        campaign_id=CAMPAIGN_ID,
        started_at=started,
        completed_at=completed,
        runtime_version="KCN scaffold phases 34-36",
        benchmark_version="campaign-001.0",
        task_set_versions=task_versions,
        random_seed=RANDOM_SEED,
        domain_scores=domain_scores,
        overall_score=round(overall, 4),
        passed=overall >= 0.8 and not critical_failures,
        cases=cases,
        critical_failures=critical_failures,
    )
    write_outputs(result)
    print(json.dumps({"run_id": result.run_id, "overall_score": result.overall_score, "passed": result.passed, "cases": len(result.cases)}, indent=2))
    return 0 if result.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
