# KCN Capability Benchmark Campaign 001 Report

## Result

- Run ID: `KCN-CAPABILITY-RUN-FC936799AA0D`
- Campaign ID: `KCN-CAPABILITY-CAMPAIGN-001`
- Started: `2026-08-01T03:17:43.741161+00:00`
- Completed: `2026-08-01T03:17:43.770484+00:00`
- Overall score: **1.000**
- Passed: **True**
- Critical failures: **0**

## Domain Scores

| Domain | Score |
|---|---:|
| governance | 1.000 |
| reasoning_planning | 1.000 |
| research | 1.000 |
| runtime | 1.000 |
| simulation | 1.000 |

## Case Results

| Case | Domain | Score | Passed | Hash |
|---|---|---:|---|---|
| `runtime-001` | runtime | 1.000 | True | `sha256:cb295aeed0c8bbda2...` |
| `planning-001` | reasoning_planning | 1.000 | True | `sha256:60aae354473c2d607...` |
| `research-001` | research | 1.000 | True | `sha256:9de1b3e8b9cc403ce...` |
| `simulation-001` | simulation | 1.000 | True | `sha256:a45c32621104bda51...` |
| `governance-001` | governance | 1.000 | True | `sha256:a8002ed8013f8801c...` |

## Evidence Artifacts

- `evidence/result_hashes.json`
- `evidence/provenance_records.json`
- `evidence/audit_log.jsonl`
- `evidence/reproducibility_manifest.json`

## Interpretation

This campaign validates scaffold behavior for runtime execution, planning, research, simulation, and governance. It does not prove AGI or ASI because it does not include external expert baselines, independent reproduction, or hidden cognitive holdouts.
