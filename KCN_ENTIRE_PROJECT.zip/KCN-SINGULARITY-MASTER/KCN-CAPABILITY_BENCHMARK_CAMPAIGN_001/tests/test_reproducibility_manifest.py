from __future__ import annotations

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class TestReproducibilityManifest(unittest.TestCase):
    def test_manifest_contains_reproduction_metadata(self) -> None:
        manifest = json.loads((ROOT / "evidence" / "reproducibility_manifest.json").read_text())
        self.assertEqual(manifest["campaign_id"], "KCN-CAPABILITY-CAMPAIGN-001")
        self.assertEqual(manifest["random_seed"], 20260731)
        self.assertIn("python runners/run_campaign.py", manifest["reproduce_command"])
        self.assertTrue(manifest["result_hash"].startswith("sha256:"))


if __name__ == "__main__":
    unittest.main()
