from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class TestBenchmarkIntegrity(unittest.TestCase):
    def test_campaign_outputs_exist_and_hashes_match_cases(self) -> None:
        subprocess.run([sys.executable, "runners/run_campaign.py"], cwd=ROOT, check=True, capture_output=True, text=True)
        summary = json.loads((ROOT / "reports" / "benchmark_summary.json").read_text())
        hashes = json.loads((ROOT / "evidence" / "result_hashes.json").read_text())
        self.assertTrue(summary["passed"])
        self.assertEqual(len(summary["cases"]), 5)
        self.assertEqual(set(hashes), {case["case_id"] for case in summary["cases"]})
        for case in summary["cases"]:
            self.assertEqual(hashes[case["case_id"]], case["result_hash"])
            self.assertTrue(case["result_hash"].startswith("sha256:"))


if __name__ == "__main__":
    unittest.main()
