from __future__ import annotations

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class TestScoringProtocol(unittest.TestCase):
    def test_domains_and_threshold_are_defined(self) -> None:
        domains = json.loads((ROOT / "benchmark_plan" / "benchmark_domains.json").read_text())
        self.assertEqual(domains["minimum_overall_score"], 0.8)
        self.assertFalse(domains["asi_claim_supported_by_this_campaign"])
        self.assertEqual(set(domains["domains"]), {"runtime", "reasoning_planning", "research", "simulation", "governance"})


if __name__ == "__main__":
    unittest.main()
