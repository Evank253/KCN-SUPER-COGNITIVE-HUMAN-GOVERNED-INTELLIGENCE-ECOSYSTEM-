# KCN Capability Benchmark Campaign 001

This campaign shifts KCN evaluation from architecture completeness toward measurable behavior.

## Purpose

Answer concrete questions:

1. Does the runtime execute governed multi-step workflows?
2. Does the research layer evaluate evidence and synthesize knowledge?
3. Does planning decompose objectives and handle approval gates?
4. Does simulation produce consistent, auditable decision-support outputs?
5. Do governance controls enforce permissions, approvals, audit, and emergency behavior?

## Principle

```text
Run → Measure → Hash Evidence → Report → Reproduce
```

## What This Campaign Is Not

This is not an ASI proof. It is a reproducible scaffold benchmark campaign for the implemented KCN modules.

## Run Campaign

```bash
cd KCN-SINGULARITY-MASTER/KCN-CAPABILITY_BENCHMARK_CAMPAIGN_001
python runners/run_campaign.py
```

Outputs:

- `reports/capability_report.md`
- `reports/benchmark_summary.json`
- `reports/failed_cases.md`
- `reports/asi_readiness_delta.md`
- `evidence/result_hashes.json`
- `evidence/provenance_records.json`
- `evidence/audit_log.jsonl`
- `evidence/reproducibility_manifest.json`

## Run Tests

```bash
python -m unittest discover -s tests -v
```
